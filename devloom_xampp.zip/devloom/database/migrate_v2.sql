-- ============================================================
--  DEVLOOM — Migration v2
--  Run this to apply new features:
--   1. review_photo column in reviews table
--   2. password_updated_at column in users table
-- ============================================================

ALTER TABLE reviews
  ADD COLUMN IF NOT EXISTS review_photo VARCHAR(300) DEFAULT '' AFTER description;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS password_updated_at DATETIME DEFAULT NULL AFTER security_answer;
