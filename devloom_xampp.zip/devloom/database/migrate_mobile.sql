-- ============================================================
--  Mobile app support — devices + auth tokens
--  (Optional: mobile_api/bootstrap.php already creates these
--   automatically on first request, same auto-migration style
--   used elsewhere in this project. Run this manually only if
--   you'd rather set them up ahead of time.)
-- ============================================================
USE devloom;

CREATE TABLE IF NOT EXISTS mobile_tokens (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    user_id            INT NOT NULL,
    access_token       VARCHAR(64) NOT NULL UNIQUE,
    refresh_token      VARCHAR(64) NOT NULL UNIQUE,
    access_expires_at  DATETIME NOT NULL,
    refresh_expires_at DATETIME NOT NULL,
    created_at         DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS device_tokens (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    push_token  VARCHAR(255) NOT NULL,
    platform    VARCHAR(20) DEFAULT '',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_token (user_id, push_token),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
