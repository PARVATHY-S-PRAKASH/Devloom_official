-- ============================================================
--  Migration: User Management Enhancements
--  Run in phpMyAdmin → SQL tab, or via mysql CLI.
--  Safe to run multiple times (uses IF NOT EXISTS / IGNORE).
-- ============================================================

USE devloom;

-- 1. Add new columns to users (skip any that already exist)
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS username          VARCHAR(60)   NULL            AFTER name,
  ADD COLUMN IF NOT EXISTS phone             VARCHAR(30)   DEFAULT ''      AFTER email,
  ADD COLUMN IF NOT EXISTS bio               TEXT                          AFTER phone,
  ADD COLUMN IF NOT EXISTS profile_photo     VARCHAR(300)  DEFAULT ''      AFTER bio,
  ADD COLUMN IF NOT EXISTS security_question VARCHAR(200)  DEFAULT ''      AFTER profile_photo,
  ADD COLUMN IF NOT EXISTS security_answer   VARCHAR(255)  DEFAULT ''      AFTER security_question,
  ADD COLUMN IF NOT EXISTS updated_at        DATETIME      DEFAULT CURRENT_TIMESTAMP
                                             ON UPDATE CURRENT_TIMESTAMP   AFTER created_at;

-- 2. Back-fill usernames from email prefix + id for existing rows
UPDATE users
SET username = CONCAT(SUBSTRING_INDEX(email,'@',1), '_', id)
WHERE (username IS NULL OR username = '') AND email IS NOT NULL AND email != '';

-- 3. Any remaining rows (no email) get user_{id}
UPDATE users SET username = CONCAT('user_', id)
WHERE username IS NULL OR username = '';

-- 4. Enforce NOT NULL + UNIQUE
ALTER TABLE users MODIFY COLUMN username VARCHAR(60) NOT NULL;
ALTER TABLE users ADD UNIQUE IF NOT EXISTS KEY uq_username (username);

-- 5. Update sample user usernames to clean values
UPDATE users SET username = 'arjun' WHERE email = 'arjun@email.com';
UPDATE users SET username = 'priya' WHERE email = 'priya@email.com';

-- 6. Drop the old email-based password reset table
DROP TABLE IF EXISTS password_resets;

SELECT 'Migration complete!' AS status;
