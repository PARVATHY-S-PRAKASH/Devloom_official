-- ============================================================
--  DEVLOOM Migration — run this on your existing database
--  in phpMyAdmin: Import this file, or paste in SQL tab
-- ============================================================
USE devloom;

-- 1. Add missing columns to screenshots table
ALTER TABLE screenshots
  ADD COLUMN IF NOT EXISTS original_name VARCHAR(300) DEFAULT '' AFTER filename,
  ADD COLUMN IF NOT EXISTS file_type ENUM('screenshot','project_file') DEFAULT 'screenshot' AFTER original_name;

-- 2. Create password_resets table (if not exists)
CREATE TABLE IF NOT EXISTS password_resets (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT           NOT NULL,
    token       VARCHAR(64)   NOT NULL UNIQUE,
    expires_at  DATETIME      NOT NULL,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. Create reviews table (for contact-page ratings)
CREATE TABLE IF NOT EXISTS reviews (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT           NOT NULL,
    project_id  INT           DEFAULT NULL,
    rating      TINYINT(1)    NOT NULL DEFAULT 5,
    description TEXT          NOT NULL,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)    REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
);

-- 4. Create message_attachments table (for chat file uploads)
CREATE TABLE IF NOT EXISTS message_attachments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    message_id    INT          NOT NULL,
    filename      VARCHAR(300) NOT NULL,
    original_name VARCHAR(300) NOT NULL DEFAULT '',
    file_size     INT          DEFAULT 0,
    mime_type     VARCHAR(120) DEFAULT '',
    uploaded_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES user_messages(id) ON DELETE CASCADE
);

-- Migration: Add Payment QR table (run if upgrading from earlier schema)
CREATE TABLE IF NOT EXISTS payment_qr (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    project_id  INT           NOT NULL UNIQUE,
    filename    VARCHAR(300)  NOT NULL,
    amount      DECIMAL(10,2) DEFAULT NULL,
    note        VARCHAR(500)  DEFAULT '',
    used        TINYINT(1)    DEFAULT 0,
    uploaded_at DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Migration: Add qr_requested flag to projects
ALTER TABLE projects ADD COLUMN IF NOT EXISTS qr_requested TINYINT(1) DEFAULT 0;
