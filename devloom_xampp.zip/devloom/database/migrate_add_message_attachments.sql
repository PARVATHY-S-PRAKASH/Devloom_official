-- ============================================================
--  MIGRATION: Add message_attachments table
--  Run this ONCE in phpMyAdmin if you get the error:
--  "Table 'devloom.message_attachments' doesn't exist"
-- ============================================================
USE devloom;

CREATE TABLE IF NOT EXISTS message_attachments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    message_id    INT          NOT NULL,
    filename      VARCHAR(300) NOT NULL,
    original_name VARCHAR(300) NOT NULL DEFAULT '',
    file_size     INT          DEFAULT 0,
    mime_type     VARCHAR(120) DEFAULT '',
    uploaded_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES user_messages(id) ON DELETE CASCADE
);

-- Also ensure the edited column exists on user_messages (added in a later version)
ALTER TABLE user_messages ADD COLUMN IF NOT EXISTS edited TINYINT(1) DEFAULT 0;
