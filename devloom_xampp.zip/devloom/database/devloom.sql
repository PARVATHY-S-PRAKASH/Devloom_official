-- ============================================================
--  DEVLOOM — Database Schema (Updated)
--  Import this in phpMyAdmin: http://localhost/phpmyadmin
-- ============================================================

CREATE DATABASE IF NOT EXISTS devloom CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE devloom;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(120)  NOT NULL,
    username          VARCHAR(60)   NOT NULL UNIQUE,
    email             VARCHAR(180)  UNIQUE,
    password          VARCHAR(255)  NOT NULL,
    avatar            VARCHAR(10)   DEFAULT '',
    phone             VARCHAR(30)   DEFAULT '',
    bio               TEXT,
    profile_photo     VARCHAR(300)  DEFAULT '',
    security_question VARCHAR(200)  DEFAULT '',
    security_answer   VARCHAR(255)  DEFAULT '',
    created_at        DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT           NOT NULL,
    title           VARCHAR(200)  NOT NULL,
    description     TEXT          NOT NULL,
    tech_stack      VARCHAR(250)  DEFAULT '',
    status          ENUM('pending','in-progress','review','completed') DEFAULT 'pending',
    payment         DECIMAL(10,2) DEFAULT NULL,
    duration        VARCHAR(80)   DEFAULT NULL,
    paid            TINYINT(1)    DEFAULT 0,
    code_note       TEXT          DEFAULT NULL,
    note_ready      TINYINT(1)    DEFAULT 0,
    requested_note  TINYINT(1)    DEFAULT 0,
    qr_requested    TINYINT(1)    DEFAULT 0,
    created_at      DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Project files table (screenshots + project files)
CREATE TABLE IF NOT EXISTS screenshots (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    project_id  INT           NOT NULL,
    filename    VARCHAR(300)  NOT NULL,
    original_name VARCHAR(300) DEFAULT '',
    file_type   ENUM('screenshot','project_file') DEFAULT 'screenshot',
    uploaded_at DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Contact messages
CREATE TABLE IF NOT EXISTS contacts (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(120)  NOT NULL,
    email       VARCHAR(180)  DEFAULT '',
    subject     VARCHAR(200)  DEFAULT '',
    message     TEXT          NOT NULL,
    is_read     TINYINT(1)    DEFAULT 0,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- User ↔ Admin messages (chat)
CREATE TABLE IF NOT EXISTS user_messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT           NOT NULL,
    sender      ENUM('user','admin') NOT NULL DEFAULT 'user',
    subject     VARCHAR(200)  DEFAULT '',
    body        TEXT          NOT NULL,
    is_read     TINYINT(1)    DEFAULT 0,
    edited      TINYINT(1)    DEFAULT 0,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Message attachments (files sent in user ↔ admin chat)
CREATE TABLE IF NOT EXISTS message_attachments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    message_id    INT          NOT NULL,
    filename      VARCHAR(300) NOT NULL,
    original_name VARCHAR(300) NOT NULL DEFAULT '',
    file_size     INT          DEFAULT 0,
    mime_type     VARCHAR(120) DEFAULT '',
    uploaded_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES user_messages(id) ON DELETE CASCADE
);

-- Password reset tokens
CREATE TABLE IF NOT EXISTS password_resets (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT           NOT NULL,
    token       VARCHAR(64)   NOT NULL UNIQUE,
    expires_at  DATETIME      NOT NULL,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── Migration: add columns if upgrading from old schema ──────
-- Run these if you already have an existing devloom DB:
-- ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS original_name VARCHAR(300) DEFAULT '';
-- ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS file_type ENUM('screenshot','project_file') DEFAULT 'screenshot';

-- Sample users (password = "pass123" hashed)
INSERT INTO users (name, username, email, password, avatar) VALUES
('Arjun Sharma',  'arjun',  'arjun@email.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'AS'),
('Priya Nair',    'priya',  'priya@email.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PN');

-- Drop email-based password reset table (not used — no email service)
DROP TABLE IF EXISTS password_resets;

-- Sample projects
INSERT INTO projects (user_id, title, description, tech_stack, status, payment, duration, paid, code_note, note_ready, requested_note) VALUES
(1, 'E-Commerce Platform',  'Full-stack shopping app with cart, checkout and admin panel.', 'React, Node.js, MongoDB',    'completed',   45000.00, '6 weeks', 1, 'This project uses a REST API with JWT authentication. The frontend leverages React hooks for state management, while the backend uses Express middleware for request validation and MongoDB for flexible data storage.', 1, 0),
(1, 'Portfolio Website',    'Personal portfolio with smooth animations and contact form.',  'Next.js, Tailwind, GSAP',    'in-progress', 12000.00, '2 weeks', 0, NULL, 0, 0),
(2, 'CRM Dashboard',        'Customer management system for small businesses.',             'Vue.js, Laravel, MySQL',     'review',      NULL,     NULL,     0, NULL, 0, 1);

-- Reviews table (for rating & feedback from clients)
CREATE TABLE IF NOT EXISTS reviews (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT           NOT NULL,
    project_id  INT           DEFAULT NULL,
    rating      TINYINT(1)    NOT NULL DEFAULT 5,
    description TEXT          NOT NULL,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)    REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
);

-- ── Payment QR Codes table (admin uploads one-time QR per project) ──
CREATE TABLE IF NOT EXISTS payment_qr (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    project_id  INT           NOT NULL UNIQUE,
    filename    VARCHAR(300)  NOT NULL,
    amount      DECIMAL(10,2) DEFAULT NULL,
    note        VARCHAR(500)  DEFAULT '',
    used        TINYINT(1)    DEFAULT 0,
    uploaded_at DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- ── Migration: add review_photo and password_updated_at columns ──
-- Run these ALTER statements if upgrading from an older schema:
-- ALTER TABLE reviews ADD COLUMN IF NOT EXISTS review_photo VARCHAR(300) DEFAULT '';
-- ALTER TABLE users ADD COLUMN IF NOT EXISTS password_updated_at DATETIME DEFAULT NULL;
