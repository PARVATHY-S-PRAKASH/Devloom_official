<?php
require_once __DIR__ . '/config/db.php';
requireUser();

$userId = currentUserId();

// Get project_id from URL
$pid = (int)($_GET['project_id'] ?? 0);

if (!$pid) {
    header('Location: /devloom/dashboard.php');
    exit;
}

// Fetch project — must belong to this user
$stmtP = $pdo->prepare("SELECT p.*, u.name as user_name, u.email as user_email
                         FROM projects p
                         JOIN users u ON u.id = p.user_id
                         WHERE p.id = ? AND p.user_id = ?");
$stmtP->execute([$pid, $userId]);
$project = $stmtP->fetch();

if (!$project) {
    header('Location: /devloom/dashboard.php');
    exit;
}

// Fetch QR code for this project
$qr = null;
try {
    $stmtQ = $pdo->prepare("SELECT * FROM payment_qr WHERE project_id = ?");
    $stmtQ->execute([$pid]);
    $qr = $stmtQ->fetch() ?: null;
} catch (PDOException $e) {
    // Table not yet created — run migrate.sql
}

// Handle POST: client confirms payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'confirm_payment' && $qr && !$qr['used']) {
        try {
            $pdo->prepare("UPDATE payment_qr SET used=1 WHERE project_id=? AND used=0")
                ->execute([$pid]);
            flash('success', '✅ Payment confirmation sent! Admin will verify and mark your project as paid shortly.');
        } catch (PDOException $e) {
            flash('error', 'Something went wrong. Please message admin.');
        }
        header('Location: /devloom/payment.php?project_id=' . $pid);
        exit;
    }
}

// Refresh QR after possible update
try {
    $stmtQ2 = $pdo->prepare("SELECT * FROM payment_qr WHERE project_id = ?");
    $stmtQ2->execute([$pid]);
    $qr = $stmtQ2->fetch() ?: null;
} catch (PDOException $e) { }

$flashOk  = flash('success');
$flashErr = flash('error');

$pageTitle  = 'Payment — ' . $project['title'];
$activePage = 'dashboard';
include __DIR__ . '/includes/header.php';

$amount = $qr['amount'] ?? $project['payment'];
?>

<div class="container" style="padding-top:48px;padding-bottom:80px;max-width:680px;">

  <?php if ($flashOk): ?><div class="alert alert-success"><?= e($flashOk) ?></div><?php endif; ?>
  <?php if ($flashErr): ?><div class="alert alert-error"><?= e($flashErr) ?></div><?php endif; ?>

  <!-- Breadcrumb -->
  <div style="margin-bottom:24px;font-size:13px;color:var(--muted);">
    <a href="/devloom/dashboard.php" style="color:#10b981;text-decoration:none;">← Dashboard</a>
    <span style="margin:0 8px;">›</span>
    <span>Payment</span>
  </div>

  <!-- Page Header -->
  <div style="margin-bottom:32px;">
    <h1 class="heading-lg" style="margin-bottom:8px;">💳 Complete Payment</h1>
    <p class="text-muted">Scan the QR code below using any UPI app to pay and unlock your project.</p>
  </div>

  <!-- Project Summary Card -->
  <div class="card" style="margin-bottom:24px;padding:20px 24px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);">
    <div style="display:flex;align-items:center;gap:14px;">
      <div style="width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,rgba(16,185,129,.2),rgba(20,184,166,.1));border:1px solid rgba(16,185,129,.25);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">📁</div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:16px;font-weight:700;color:#f1f5f9;margin-bottom:4px;"><?= e($project['title']) ?></div>
        <div style="font-size:13px;color:var(--muted);">
          <?php if ($project['tech_stack']): ?><span class="badge badge-blue" style="margin-right:6px;"><?= e($project['tech_stack']) ?></span><?php endif; ?>
          <span class="badge <?= statusClass($project['status']) ?>"><?= statusLabel($project['status']) ?></span>
        </div>
      </div>
      <div style="text-align:right;flex-shrink:0;">
        <?php if ($project['paid']): ?>
        <span class="badge badge-green" style="font-size:13px;padding:6px 14px;">✅ Paid</span>
        <?php else: ?>
        <div style="font-size:22px;font-weight:800;color:#10b981;">₹<?= number_format($amount, 0) ?></div>
        <div style="font-size:11px;color:var(--muted);">Amount Due</div>
        <?php endif; ?>
      </div>
    </div>
    <?php if ($project['duration']): ?>
    <div style="margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.06);font-size:13px;color:var(--muted);">
      ⏱ Timeline: <strong style="color:#e2e8f0;"><?= e($project['duration']) ?></strong>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($project['paid']): ?>
  <!-- Already Paid State -->
  <div class="card" style="text-align:center;padding:56px 40px;border-color:rgba(16,185,129,.3);background:rgba(16,185,129,.05);">
    <div style="font-size:56px;margin-bottom:16px;">🎉</div>
    <h2 class="heading-md" style="color:#10b981;margin-bottom:12px;">Payment Complete!</h2>
    <p class="text-muted" style="font-size:15px;margin-bottom:24px;">Your payment has been confirmed. Your project files are now unlocked.</p>
    <a href="/devloom/dashboard.php" class="btn btn-primary" style="padding:12px 32px;">Go to Dashboard →</a>
  </div>

  <?php elseif (!$qr): ?>
  <!-- No QR uploaded yet -->
  <div class="card" style="text-align:center;padding:56px 40px;">
    <div style="font-size:52px;margin-bottom:16px;">⏳</div>
    <h2 class="heading-md" style="margin-bottom:12px;">Payment QR Not Ready Yet</h2>
    <p class="text-muted" style="font-size:15px;margin-bottom:8px;">Admin hasn't uploaded the payment QR code for this project yet.</p>
    <p class="text-muted" style="font-size:14px;margin-bottom:28px;">You'll be able to scan and pay once it's ready. Message the admin to follow up.</p>
    <div class="flex gap-12" style="justify-content:center;flex-wrap:wrap;">
      <a href="/devloom/messages.php" class="btn btn-primary" style="padding:12px 28px;">💬 Message Admin</a>
      <a href="/devloom/dashboard.php" class="btn btn-ghost" style="padding:12px 28px;">← Dashboard</a>
    </div>
  </div>

  <?php else: ?>
  <!-- QR Payment Section -->

  <?php if ($qr['used']): ?>
  <!-- Already confirmed -->
  <div class="alert" style="background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3);border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
    <span style="font-size:24px;">⚠️</span>
    <div>
      <strong style="color:#fbbf24;display:block;margin-bottom:3px;">Payment Confirmation Sent</strong>
      <span style="font-size:13px;color:#94a3b8;">You've confirmed this payment. Admin is verifying the transaction and will mark it as paid shortly. If there's an issue, message admin below.</span>
    </div>
  </div>
  <?php endif; ?>

  <!-- QR Code Card -->
  <div class="card" style="margin-bottom:24px;text-align:center;padding:32px 24px;background:linear-gradient(135deg,rgba(16,185,129,.05),rgba(20,184,166,.03));border-color:rgba(16,185,129,.2);">

    <div style="margin-bottom:20px;">
      <div style="font-size:32px;font-weight:800;color:#10b981;margin-bottom:4px;">₹<?= number_format($amount, 0) ?></div>
      <div style="font-size:14px;color:#94a3b8;"><?= $qr['note'] ? e($qr['note']) : 'Scan with any UPI payment app to pay' ?></div>
    </div>

    <!-- QR Image -->
    <div style="display:flex;justify-content:center;margin-bottom:24px;">
      <div style="background:#ffffff;border-radius:16px;padding:16px;display:inline-block;box-shadow:0 4px 24px rgba(0,0,0,.3);">
        <img
          src="/devloom/uploads/qr/<?= e($qr['filename']) ?>"
          alt="Payment QR Code"
          style="width:240px;height:240px;object-fit:contain;display:block;"
        >
      </div>
    </div>

    <!-- UPI App Badges -->
    <div style="margin-bottom:24px;">
      <p style="font-size:12px;color:var(--muted);margin-bottom:12px;text-transform:uppercase;letter-spacing:.06em;font-family:var(--font-mono);">Pay using any UPI app</p>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
        <?php foreach ([['📲','GPay'],['📱','PhonePe'],['🪙','Paytm'],['💳','BHIM']] as [$ic,$name]): ?>
        <div style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:7px 14px;font-size:12px;color:#cbd5e1;display:flex;align-items:center;gap:5px;">
          <?= $ic ?> <?= $name ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Step Instructions -->
    <div style="text-align:left;background:rgba(0,0,0,.2);border-radius:12px;padding:18px 20px;margin-bottom:24px;">
      <p style="font-size:12px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px;">How to pay</p>
      <?php foreach ([
        ['1','Open GPay, PhonePe, Paytm, or any UPI app'],
        ['2','Tap "Scan QR" or "Pay" and point camera at the code above'],
        ['3','Confirm the amount: ₹' . number_format($amount, 0)],
        ['4','Complete the payment and note your transaction ID'],
        ['5','Click "I\'ve Completed Payment" below to notify admin'],
      ] as [$n, $step]): ?>
      <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px;<?= $n==='5'?'margin-bottom:0':'' ?>">
        <div style="width:22px;height:22px;border-radius:50%;background:rgba(16,185,129,.2);border:1px solid rgba(16,185,129,.3);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#10b981;flex-shrink:0;margin-top:1px;"><?= $n ?></div>
        <span style="font-size:13px;color:#cbd5e1;line-height:1.6;"><?= $step ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Confirm Payment Button -->
    <?php if (!$qr['used']): ?>
    <form method="POST">
      <input type="hidden" name="action" value="confirm_payment">
      <button type="submit" class="btn btn-primary" style="width:100%;padding:15px;font-size:16px;background:linear-gradient(135deg,#10b981,#059669);border-color:#059669;border-radius:12px;"
        onclick="return confirm('Confirm that you have completed the payment of ₹<?= number_format($amount, 0) ?>?')">
        ✅ I've Completed the Payment
      </button>
    </form>
    <p style="font-size:12px;color:var(--muted);margin-top:10px;">Clicking this notifies admin to verify and unlock your project files.</p>
    <?php else: ?>
    <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:14px;font-size:14px;color:#6ee7b7;">
      ✅ You've confirmed this payment. Waiting for admin verification.
    </div>
    <?php endif; ?>
  </div>

  <!-- Help Section -->
  <div class="card" style="padding:20px 24px;background:rgba(99,102,241,.04);border-color:rgba(99,102,241,.15);">
    <div style="font-size:14px;font-weight:600;color:#a5b4fc;margin-bottom:10px;">🆘 Need Help?</div>
    <p style="font-size:13px;color:#94a3b8;line-height:1.7;margin-bottom:14px;">
      If you're facing any issues with payment — wrong amount, QR not scanning, transaction failed — message admin directly.
    </p>
    <a href="/devloom/messages.php" class="btn btn-ghost btn-sm" style="border-color:rgba(99,102,241,.3);color:#a5b4fc;">
      💬 Message Admin
    </a>
  </div>
  <?php endif; ?>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
