<?php
// ============================================================
//  config/db.php — Database Connection + Session Bootstrap
// ============================================================

date_default_timezone_set('Asia/Kolkata');

// ── DEBUG MODE ──────────────────────────────────────────────────
// Set to false before going live. When true, real error details are
// shown on screen (fine for local XAMPP). When false, users only see
// a generic message and the real error is written to error_log.txt.
define('DEBUG_MODE', true);

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'devloom');

// ── Admin Credentials ─────────────────────────────────────────
// CHANGE THESE before deploying anywhere public. A strong random
// password has been generated for you below — write it down and
// change it again once you've logged in, via the admin profile page.
define('ADMIN_EMAIL',    'admin@devloom.io');
define('ADMIN_PASS',     'iQkcnjUGJbY3Bs');   // admin login password — CHANGE ME
define('ADMIN_USERNAME', 'admin');            // admin login username

// Site info
define('SITE_NAME',   'Devloom');

// ── Anthropic API Key (for AI Viva, Mock Interview features) ──
// Get your key from: https://console.anthropic.com/
define('ANTHROPIC_API_KEY', 'YOUR_API_KEY_HERE');

// Upload paths — supports BOTH old (screenshots/) and new (files/) folders
define('UPLOAD_PATH',          __DIR__ . '/../uploads/files/');
define('UPLOAD_PATH_LEGACY',   __DIR__ . '/../uploads/screenshots/');
define('UPLOAD_PATH_MESSAGES', __DIR__ . '/../uploads/messages/');
define('UPLOAD_PATH_QR',      __DIR__ . '/../uploads/qr/');
define('UPLOAD_URL_QR',       '/devloom/uploads/qr/');
define('UPLOAD_URL',           '/devloom/uploads/files/');
define('UPLOAD_URL_LEGACY',    '/devloom/uploads/screenshots/');

if (session_status() === PHP_SESSION_NONE) {
    // Fix for XAMPP on Windows: ensure session save path is writable
    $sessionPath = session_save_path();
    if (empty($sessionPath) || !is_writable($sessionPath)) {
        $fallback = sys_get_temp_dir();
        if (is_writable($fallback)) session_save_path($fallback);
    }
    session_start();
}

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER, DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    error_log('[Devloom DB Error] ' . $e->getMessage());
    $detail = DEBUG_MODE
        ? '<small>' . htmlspecialchars($e->getMessage()) . '</small>'
        : '<small>Please try again shortly, or contact the site admin if this continues.</small>';
    die('<div style="font-family:sans-serif;padding:40px;background:#0a0f0d;color:#ef4444;text-align:center;">
        <h2>Database Connection Failed</h2>
        <p>Make sure MySQL is running and the <code>devloom</code> database exists.</p>
        ' . $detail . '
    </div>');
}

// ── Auth helpers ──────────────────────────────────────────────
function isLoggedIn(): bool   { return isset($_SESSION['user_id']); }
function isAdmin(): bool      { return isset($_SESSION['is_admin']) && $_SESSION['is_admin']; }
function currentUserId(): int { return (int)($_SESSION['user_id'] ?? 0); }

// ── CSRF protection ─────────────────────────────────────────────
// Call csrf_field() inside any <form> that does something (POST).
// Call csrf_check() at the top of the POST handler for that form.
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}
function csrf_check(): void {
    $sent = $_POST['csrf_token'] ?? '';
    $real = $_SESSION['csrf_token'] ?? '';
    if (!$sent || !$real || !hash_equals($real, $sent)) {
        http_response_code(403);
        exit('Security check failed (invalid or expired form). Please go back, refresh the page, and try again.');
    }
}

// ── Safe file upload validation ──────────────────────────────────
// Returns true if $file (a single entry from $_FILES) is an allowed
// type/size. $allowed is an array of lowercase extensions without the dot.
function isAllowedUpload(array $file, array $allowed, int $maxBytes = 10 * 1024 * 1024): bool {
    if (empty($file['name']) || !is_uploaded_file($file['tmp_name'] ?? '')) return false;
    if (($file['size'] ?? 0) > $maxBytes) return false;
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) return false;
    // Block any extension that could be executed by the server, no matter what list was passed in.
    $blocked = ['php','php3','php4','php5','phtml','phar','cgi','pl','py','sh','exe','asp','aspx','jsp','htaccess'];
    if (in_array($ext, $blocked, true)) return false;
    return true;
}
// Default whitelist used across the app for general attachments/screenshots.
const ALLOWED_UPLOAD_EXTS = ['jpg','jpeg','png','gif','webp','bmp','pdf','doc','docx','xls','xlsx','ppt','pptx','zip','txt','csv','mp4','mp3'];

// ── Auto-Migration: add new columns if they don't exist yet ───
// This runs once per column and is safe to call on every request.
(function() use ($pdo) {
    // Check which columns already exist in `users`
    try {
        $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) { return; }  // table may not exist yet

    $alterParts = [];
    if (!in_array('username', $cols))
        $alterParts[] = "ADD COLUMN username VARCHAR(60) NULL AFTER name";
    if (!in_array('phone', $cols))
        $alterParts[] = "ADD COLUMN phone VARCHAR(30) DEFAULT '' AFTER email";
    if (!in_array('bio', $cols))
        $alterParts[] = "ADD COLUMN bio TEXT AFTER phone";
    if (!in_array('profile_photo', $cols))
        $alterParts[] = "ADD COLUMN profile_photo VARCHAR(300) DEFAULT '' AFTER bio";
    if (!in_array('security_question', $cols))
        $alterParts[] = "ADD COLUMN security_question VARCHAR(200) DEFAULT '' AFTER profile_photo";
    if (!in_array('security_answer', $cols))
        $alterParts[] = "ADD COLUMN security_answer VARCHAR(255) DEFAULT '' AFTER security_question";
    if (!in_array('updated_at', $cols))
        $alterParts[] = "ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at";

    if ($alterParts) {
        $pdo->exec("ALTER TABLE users " . implode(', ', $alterParts));
    }

    // Auto-migrate reviews table: add review_photo column if missing
    try {
        $rCols = $pdo->query("SHOW COLUMNS FROM reviews")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('review_photo', $rCols)) {
            $pdo->exec("ALTER TABLE reviews ADD COLUMN review_photo VARCHAR(300) DEFAULT ''");
        }
    } catch (PDOException $e) { /* reviews table may not exist yet */ }

    // Back-fill usernames from email prefix for any rows that have none
    $pdo->exec("UPDATE users SET username = CONCAT(SUBSTRING_INDEX(email,'@',1),'_',id)
                WHERE (username IS NULL OR username = '') AND email IS NOT NULL AND email != ''");
    // Rows with no email get a numeric username
    $pdo->exec("UPDATE users SET username = CONCAT('user_',id)
                WHERE username IS NULL OR username = ''");

    // Now make the column NOT NULL + UNIQUE if it isn't already
    try {
        $pdo->exec("ALTER TABLE users MODIFY COLUMN username VARCHAR(60) NOT NULL");
    } catch (PDOException $e) { /* already NOT NULL */ }
    try {
        $pdo->exec("ALTER TABLE users ADD UNIQUE KEY uq_username (username)");
    } catch (PDOException $e) { /* unique key already exists */ }

    // Drop old password_resets table (no longer used)
    try {
        $pdo->exec("DROP TABLE IF EXISTS password_resets");
    } catch (PDOException $e) { /* ignore */ }
})();

function requireLogin(): void {
    if (!isLoggedIn()) { header('Location: /devloom/auth.php'); exit; }
}
function requireAdmin(): void {
    if (!isAdmin()) { header('Location: /devloom/index.php'); exit; }
}
function requireUser(): void {
    if (!isLoggedIn() || isAdmin()) { header('Location: /devloom/index.php'); exit; }
}

function flash(string $key, string $msg = ''): string {
    if ($msg) { $_SESSION['flash'][$key] = $msg; return ''; }
    $val = $_SESSION['flash'][$key] ?? '';
    unset($_SESSION['flash'][$key]);
    return $val;
}

function statusLabel(string $s): string {
    return ['pending'=>'Pending','in-progress'=>'In Progress','review'=>'Under Review','completed'=>'Completed'][$s] ?? $s;
}
function statusClass(string $s): string {
    return ['pending'=>'status-pending','in-progress'=>'status-progress','review'=>'status-review','completed'=>'status-done'][$s] ?? '';
}

function e(string $str): string {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// ── File helpers ──────────────────────────────────────────────

/**
 * Returns a URL that reliably serves the file via serve_file.php.
 * Works regardless of which upload folder the file is in.
 */
function filePublicUrl(string $filename): string {
    return '/devloom/serve_file.php?f=' . urlencode($filename);
}

function isImageFile(string $filename): bool {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ['jpg','jpeg','png','gif','webp','bmp','svg']);
}

function fileIcon(string $filename): string {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $icons = [
        'pdf'  => '📄', 'doc'  => '📝', 'docx' => '📝',
        'xls'  => '📊', 'xlsx' => '📊', 'csv'  => '📊',
        'zip'  => '🗜',  'rar'  => '🗜',  '7z'   => '🗜',
        'mp4'  => '🎬', 'avi'  => '🎬', 'mov'  => '🎬',
        'mp3'  => '🎵', 'wav'  => '🎵',
        'ppt'  => '📊', 'pptx' => '📊',
        'txt'  => '📃', 'md'   => '📃',
        'jpg'  => '🖼', 'jpeg' => '🖼', 'png'  => '🖼',
        'gif'  => '🖼', 'webp' => '🖼',
        'sql'  => '🗄', 'php'  => '⚙',  'js'   => '⚙',
    ];
    return $icons[$ext] ?? '📎';
}

/**
 * Safe accessor — returns the display name for a screenshot row,
 * working even if the original_name column doesn't exist yet.
 */
function fileDisplayName(array $ss): string {
    return !empty($ss['original_name']) ? $ss['original_name'] : $ss['filename'];
}
