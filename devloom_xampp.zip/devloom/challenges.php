<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Study Hub';
$activePage = 'features';
include __DIR__ . '/includes/header.php';
?>
<style>
/* ── Layout ─────────────────────────────────────────────────── */
.sh-wrap{max-width:900px;margin:0 auto;padding:36px 0 80px;}
.sh-header{text-align:center;margin-bottom:32px;}
.sh-header h1{font-size:2.1rem;font-weight:900;color:#f1f5f9;margin-bottom:8px;}
.sh-header p{color:#94a3b8;font-size:.95rem;}

/* ── Tabs ───────────────────────────────────────────────────── */
.sh-tabs{display:flex;gap:4px;margin-bottom:28px;background:rgba(255,255,255,.03);border-radius:12px;padding:4px;flex-wrap:wrap;}
.sh-tab{flex:1;min-width:100px;padding:10px 6px;border:none;border-radius:8px;background:transparent;color:#64748b;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;}
.sh-tab.active{background:rgba(99,102,241,.2);color:#a5b4fc;}
.sh-panel{display:none;}
.sh-panel.active{display:block;}

/* ── Buttons ────────────────────────────────────────────────── */
.btn{padding:10px 22px;border-radius:10px;border:none;font-size:13px;font-weight:700;cursor:pointer;transition:all .18s;}
.btn-primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;}
.btn-ghost{background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.1);color:#cbd5e1;}
.btn-sm{padding:7px 14px;font-size:12px;}
.pill{padding:6px 14px;border-radius:16px;border:1.5px solid rgba(255,255,255,.1);background:transparent;color:#94a3b8;font-size:12px;font-weight:600;cursor:pointer;transition:all .18s;}
.pill.sel{background:rgba(99,102,241,.15);border-color:rgba(99,102,241,.5);color:#a5b4fc;}

/* ── Flashcards ─────────────────────────────────────────────── */
.fc-cat-row{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px;justify-content:center;}
.fc-hint{text-align:center;font-size:12px;color:#475569;margin-bottom:14px;}
.fc-scene{perspective:1000px;max-width:540px;margin:0 auto 20px;}
.fc-inner{position:relative;height:200px;transform-style:preserve-3d;transition:transform .55s ease;cursor:pointer;}
.fc-inner.flipped{transform:rotateY(180deg);}
.fc-face{position:absolute;inset:0;border-radius:20px;display:flex;align-items:center;justify-content:center;padding:28px;font-size:1.05rem;font-weight:700;text-align:center;-webkit-backface-visibility:hidden;backface-visibility:hidden;line-height:1.6;}
.fc-front{background:linear-gradient(135deg,rgba(99,102,241,.18),rgba(16,185,129,.12));border:1.5px solid rgba(99,102,241,.35);color:#e2e8f0;}
.fc-back{background:linear-gradient(135deg,rgba(16,185,129,.2),rgba(6,182,212,.14));border:1.5px solid rgba(16,185,129,.35);color:#6ee7b7;transform:rotateY(180deg);}
.fc-nav{display:flex;justify-content:center;align-items:center;gap:16px;margin:14px 0 8px;}
.fc-ctr{font-size:13px;color:#64748b;font-weight:700;min-width:60px;text-align:center;}

/* ── MCQ ────────────────────────────────────────────────────── */
.mcq-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:22px 24px;margin-bottom:14px;}
.mcq-qtxt{font-size:.95rem;font-weight:700;color:#e2e8f0;margin-bottom:14px;}
.mcq-opts{display:flex;flex-direction:column;gap:8px;}
.mcq-opts button{text-align:left;padding:10px 16px;border-radius:8px;border:1.5px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);color:#cbd5e1;font-size:.87rem;cursor:pointer;transition:all .18s;}
.mcq-opts button:hover:not(:disabled){border-color:rgba(99,102,241,.4);background:rgba(99,102,241,.07);}
.mcq-opts button.correct{background:rgba(16,185,129,.15)!important;border-color:#10b981!important;color:#6ee7b7!important;}
.mcq-opts button.wrong{background:rgba(239,68,68,.12)!important;border-color:#ef4444!important;color:#fca5a5!important;}
.mcq-explain{font-size:.84rem;color:#94a3b8;margin-top:8px;padding:8px 12px;background:rgba(0,0,0,.2);border-radius:6px;line-height:1.7;display:none;}
.score-bar{height:8px;background:rgba(255,255,255,.07);border-radius:4px;overflow:hidden;margin:8px 0;}
.score-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,#10b981,#6ee7b7);transition:width 1s ease;}

/* ── Typing ─────────────────────────────────────────────────── */
.tp-wrap{max-width:620px;margin:0 auto;}
.tp-display{font-family:'Fira Code',monospace;font-size:.95rem;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:20px 22px;line-height:2;word-break:break-all;min-height:80px;margin-bottom:14px;user-select:none;}
.tp-display .ch-done{color:#10b981;}
.tp-display .ch-err{color:#ef4444;background:rgba(239,68,68,.15);border-radius:2px;}
.tp-display .ch-cur{color:#f8fafc;background:rgba(99,102,241,.45);border-radius:2px;animation:blink-cur .7s infinite;}
.tp-display .ch-todo{color:#475569;}
@keyframes blink-cur{0%,100%{opacity:1}50%{opacity:.4}}
.tp-input{width:100%;background:rgba(0,0,0,.3);border:1.5px solid rgba(255,255,255,.08);border-radius:10px;color:#e2e8f0;font-size:1rem;padding:13px 16px;font-family:'Fira Code',monospace;outline:none;resize:none;box-sizing:border-box;transition:border-color .2s;}
.tp-input:focus{border-color:rgba(99,102,241,.4);}
.tp-stats{display:flex;gap:16px;flex-wrap:wrap;margin-top:14px;}
.tp-stat{flex:1;min-width:80px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:10px 14px;text-align:center;}
.tp-val{font-size:1.6rem;font-weight:900;color:#a5b4fc;}
.tp-lbl{font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin-top:2px;}
.tp-done-banner{text-align:center;padding:20px;background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.2);border-radius:12px;margin-top:16px;display:none;}

/* ── Pomodoro ───────────────────────────────────────────────── */
.pm-wrap{max-width:380px;margin:0 auto;text-align:center;}
.pm-modes{display:flex;gap:6px;justify-content:center;margin-bottom:24px;flex-wrap:wrap;}
.pm-ring{position:relative;width:210px;height:210px;margin:0 auto 16px;}
.pm-ring svg{position:absolute;inset:0;transform:rotate(-90deg);}
.pm-bg{fill:none;stroke:rgba(255,255,255,.06);stroke-width:14;}
.pm-arc{fill:none;stroke:url(#pomGrad);stroke-width:14;stroke-linecap:round;
  stroke-dasharray:597;stroke-dashoffset:0;transition:stroke-dashoffset .9s linear;}
.pm-center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;}
.pm-clock{font-size:3rem;font-weight:900;color:#f1f5f9;font-variant-numeric:tabular-nums;line-height:1;}
.pm-mode-lbl{font-size:.7rem;color:#64748b;letter-spacing:.12em;text-transform:uppercase;margin-top:6px;}
.pm-btns{display:flex;gap:10px;justify-content:center;margin-top:18px;}
.pm-sessions{font-size:13px;color:#475569;margin-top:14px;}
</style>

<div class="container">
<div class="sh-wrap">
  <div class="sh-header">
    <h1>📚 Study Hub</h1>
    <p>Flashcards · MCQ Practice · Typing Speed · Pomodoro Timer</p>
  </div>

  <div class="sh-tabs">
    <button class="sh-tab active" onclick="shTab(this,'flash')">🃏 Flashcards</button>
    <button class="sh-tab"        onclick="shTab(this,'mcq')">🧠 MCQ Quiz</button>
    <button class="sh-tab"        onclick="shTab(this,'type')">⌨️ Typing</button>
    <button class="sh-tab"        onclick="shTab(this,'pomo')">🍅 Pomodoro</button>
  </div>

  <!-- ════════════════ FLASHCARDS ════════════════ -->
  <div id="sh-flash" class="sh-panel active">
    <div class="fc-cat-row" id="fc-cats"></div>
    <div class="fc-hint">Click the card to reveal the answer</div>
    <div class="fc-scene">
      <div class="fc-inner" id="fc-inner" onclick="fcFlip()">
        <div class="fc-face fc-front" id="fc-q">Loading…</div>
        <div class="fc-face fc-back"  id="fc-a"></div>
      </div>
    </div>
    <div class="fc-nav">
      <button class="btn btn-ghost btn-sm" onclick="fcNav(-1)">← Prev</button>
      <span class="fc-ctr" id="fc-ctr">1 / 1</span>
      <button class="btn btn-ghost btn-sm" onclick="fcNav(1)">Next →</button>
    </div>
    <div style="text-align:center;margin-top:8px;">
      <button class="btn btn-ghost btn-sm" onclick="fcShuffle()">🔀 Shuffle</button>
    </div>
  </div>

  <!-- ════════════════ MCQ QUIZ ════════════════ -->
  <div id="sh-mcq" class="sh-panel">
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:18px;align-items:flex-end;">
      <div style="flex:1;min-width:180px;">
        <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;">Topic</div>
        <select id="mcq-topic" style="width:100%;background:rgba(0,0,0,.3);border:1.5px solid rgba(255,255,255,.08);border-radius:8px;color:#e2e8f0;padding:9px 12px;font-size:13px;outline:none;">
          <option value="ds">Data Structures</option>
          <option value="algo">Algorithms</option>
          <option value="os">Operating Systems</option>
          <option value="dbms">DBMS</option>
          <option value="cn">Computer Networks</option>
          <option value="oop">OOP Concepts</option>
        </select>
      </div>
      <button class="btn btn-primary btn-sm" onclick="mcqLoad()">🔄 New Set</button>
    </div>
    <div id="mcq-area"></div>
    <div id="mcq-result" style="display:none;text-align:center;padding:24px;background:rgba(16,185,129,.05);border:1px solid rgba(16,185,129,.15);border-radius:14px;margin-top:16px;"></div>
  </div>

  <!-- ════════════════ TYPING TEST ════════════════ -->
  <div id="sh-type" class="sh-panel">
    <div class="tp-wrap">
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;justify-content:center;" id="tp-cats"></div>
      <div class="tp-display" id="tp-display"></div>
      <textarea class="tp-input" id="tp-input" rows="3"
        placeholder="Start typing here…"
        oninput="tpInput(event)"
        onpaste="return false;"
        autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"></textarea>
      <div class="tp-stats">
        <div class="tp-stat"><div class="tp-val" id="tp-wpm">0</div><div class="tp-lbl">WPM</div></div>
        <div class="tp-stat"><div class="tp-val" id="tp-acc">—</div><div class="tp-lbl">Accuracy</div></div>
        <div class="tp-stat"><div class="tp-val" id="tp-time">0s</div><div class="tp-lbl">Time</div></div>
        <div class="tp-stat"><div class="tp-val" id="tp-chars">0</div><div class="tp-lbl">Chars</div></div>
      </div>
      <div class="tp-done-banner" id="tp-done">
        <div style="font-size:1.8rem;">🎉</div>
        <div style="font-weight:800;color:#10b981;margin:6px 0;">Complete!</div>
        <div id="tp-done-stats" style="color:#94a3b8;font-size:.9rem;margin-bottom:12px;"></div>
        <button class="btn btn-primary btn-sm" onclick="tpNew()">Try Another →</button>
      </div>
      <div style="text-align:center;margin-top:12px;">
        <button class="btn btn-ghost btn-sm" onclick="tpNew()">🔄 New Text</button>
      </div>
    </div>
  </div>

  <!-- ════════════════ POMODORO ════════════════ -->
  <div id="sh-pomo" class="sh-panel">
    <div class="pm-wrap">
      <div class="pm-modes">
        <button class="pill sel" onclick="pmSetMode('focus',25,this)">🎯 Focus 25m</button>
        <button class="pill"     onclick="pmSetMode('short',5,this)">☕ Short Break 5m</button>
        <button class="pill"     onclick="pmSetMode('long',15,this)">🛋️ Long Break 15m</button>
      </div>
      <div class="pm-ring">
        <svg viewBox="0 0 210 210" width="210" height="210">
          <defs>
            <linearGradient id="pomGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" style="stop-color:#6366f1"/>
              <stop offset="100%" style="stop-color:#10b981"/>
            </linearGradient>
          </defs>
          <circle class="pm-bg" cx="105" cy="105" r="95"/>
          <circle class="pm-arc" id="pm-arc" cx="105" cy="105" r="95"/>
        </svg>
        <div class="pm-center">
          <div class="pm-clock" id="pm-clock">25:00</div>
          <div class="pm-mode-lbl" id="pm-lbl">FOCUS TIME</div>
        </div>
      </div>
      <div class="pm-btns">
        <button class="btn btn-primary" id="pm-btn" onclick="pmToggle()">▶ Start</button>
        <button class="btn btn-ghost"   onclick="pmReset()">↺ Reset</button>
      </div>
      <div class="pm-sessions" id="pm-sess">Sessions completed: <strong>0</strong></div>
    </div>
  </div>

</div><!-- /sh-wrap -->
</div><!-- /container -->

<script>
/* ───────────────────────────────────────────────────────────────
   TAB SWITCHING
───────────────────────────────────────────────────────────────── */
function shTab(btn, id) {
  document.querySelectorAll('.sh-tab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.sh-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('sh-' + id).classList.add('active');
  // Re-initialise panels that need to be visible to render correctly
  if (id === 'type') {
    tpNew();
  } else if (id === 'pomo') {
    pmDraw(pmTotal - pmElapsed);
  } else if (id === 'mcq') {
    if (!document.getElementById('mcq-area').innerHTML.trim()) mcqLoad();
  }
}

/* ───────────────────────────────────────────────────────────────
   FLASHCARDS
───────────────────────────────────────────────────────────────── */
var FC = {
  DS: [
    {q:'What is the time complexity of binary search?',         a:'O(log n) — the search space halves on every step.'},
    {q:'What data structure uses LIFO order?',                  a:'Stack — Last In, First Out.'},
    {q:'What data structure uses FIFO order?',                  a:'Queue — First In, First Out.'},
    {q:'What is a balanced BST?',                               a:'A BST where heights of left and right subtrees differ by at most 1.'},
    {q:'What is the worst-case time for quicksort?',            a:'O(n²) — when the pivot is always the smallest or largest element.'},
    {q:'What is a hash collision?',                             a:'When two different keys map to the same array index.'},
    {q:'What is a min-heap property?',                          a:'Every parent node value is ≤ its children (smallest at root).'},
    {q:'Time complexity of inserting at the head of a linked list?', a:'O(1) — just update the head pointer.'},
    {q:'What is a deque?',                                      a:'A double-ended queue — insertion and deletion at both ends.'},
    {q:'Difference between array and linked list?',             a:'Arrays have O(1) random access; linked lists have O(1) insertion/deletion at known nodes but O(n) access.'},
  ],
  DBMS: [
    {q:'What does ACID stand for?',                             a:'Atomicity, Consistency, Isolation, Durability.'},
    {q:'What is a primary key?',                                a:'A column (or set) that uniquely identifies every row in a table.'},
    {q:'What is a foreign key?',                                a:'A field referencing the primary key of another table — enforces referential integrity.'},
    {q:'What is normalization?',                                a:'Organizing a database to reduce redundancy and improve integrity.'},
    {q:'Difference between DELETE and TRUNCATE?',              a:'DELETE removes specific rows (can be rolled back); TRUNCATE removes all rows faster and is usually not rollable.'},
    {q:'What is a database index?',                             a:'A data structure that speeds up row retrieval — like a book index.'},
    {q:'What does a JOIN do?',                                  a:'Combines rows from two or more tables based on a matching column.'},
    {q:'What is a view?',                                       a:'A virtual table defined by a SQL query — no data is stored separately.'},
    {q:'What is 2NF?',                                          a:'Second Normal Form — in 1NF and every non-key attribute is fully dependent on the whole primary key.'},
    {q:'What is a transaction?',                                a:'A sequence of operations executed as a single unit — all succeed or all are rolled back.'},
  ],
  OS: [
    {q:'What is a process?',                                    a:'A program in execution with its own memory space, registers and state.'},
    {q:'What is a thread?',                                     a:'A lightweight execution unit within a process — shares the same memory space.'},
    {q:'What is deadlock?',                                     a:'When two or more processes are stuck waiting for resources held by each other.'},
    {q:'What is virtual memory?',                               a:'An abstraction letting programs use more memory than physically available, using disk as overflow.'},
    {q:'What is paging?',                                       a:'Dividing memory into fixed-size pages to simplify allocation and eliminate external fragmentation.'},
    {q:'What is a semaphore?',                                  a:'A synchronization primitive — an integer counter for controlling access to shared resources.'},
    {q:'What does a CPU scheduler do?',                         a:'Decides which process/thread runs on the CPU next and for how long.'},
    {q:'What is thrashing?',                                    a:'Excessive page swapping that causes the system to spend more time paging than executing.'},
    {q:'What is a context switch?',                             a:'Saving the state of one process and loading the saved state of another so CPU can switch tasks.'},
    {q:'Difference between preemptive and non-preemptive scheduling?', a:'Preemptive: CPU can be taken mid-task. Non-preemptive: process runs until it voluntarily yields.'},
  ],
  CN: [
    {q:'OSI model layers (top to bottom)?',                     a:'Application, Presentation, Session, Transport, Network, Data Link, Physical.'},
    {q:'Difference between TCP and UDP?',                       a:'TCP: reliable, connection-oriented, ordered. UDP: fast, connectionless, no delivery guarantee.'},
    {q:'What is an IP address?',                                a:'A numerical label assigned to each network device for identification and routing.'},
    {q:'What is DNS?',                                          a:'Domain Name System — translates human-readable domain names to IP addresses.'},
    {q:'What is a subnet mask?',                                a:'A 32-bit number that divides an IP address into network and host portions.'},
    {q:'HTTP vs HTTPS?',                                        a:'HTTPS adds TLS encryption on top of HTTP, securing data in transit.'},
    {q:'What is a MAC address?',                                a:'A hardware identifier (48-bit) assigned to a network interface — unique per device.'},
    {q:'What does a router do?',                                a:'Forwards packets between different networks using IP addresses.'},
    {q:'What is ARP?',                                          a:'Address Resolution Protocol — maps an IP address to its MAC address on a LAN.'},
    {q:'Default ports for HTTP and HTTPS?',                     a:'HTTP: port 80. HTTPS: port 443.'},
  ],
};

var fcDeck = [], fcIdx = 0, fcCat = 'DS';

(function initFC() {
  var cats = Object.keys(FC);
  var row = document.getElementById('fc-cats');
  row.innerHTML = cats.map(function(c) {
    return '<button class="pill' + (c === fcCat ? ' sel' : '') + '" onclick="fcPickCat(this,\'' + c + '\')">' + c + '</button>';
  }).join('');
  fcLoad();
})();

function fcPickCat(btn, cat) {
  fcCat = cat;
  document.querySelectorAll('#fc-cats .pill').forEach(function(b) { b.classList.remove('sel'); });
  btn.classList.add('sel');
  fcLoad();
}
function fcLoad() {
  fcDeck = FC[fcCat].slice();
  fcIdx  = 0;
  document.getElementById('fc-inner').classList.remove('flipped');
  fcShow();
}
function fcShuffle() {
  fcDeck.sort(function() { return Math.random() - .5; });
  fcIdx = 0;
  document.getElementById('fc-inner').classList.remove('flipped');
  fcShow();
}
function fcShow() {
  document.getElementById('fc-q').textContent   = fcDeck[fcIdx].q;
  document.getElementById('fc-a').textContent   = fcDeck[fcIdx].a;
  document.getElementById('fc-ctr').textContent = (fcIdx + 1) + ' / ' + fcDeck.length;
  document.getElementById('fc-inner').classList.remove('flipped');
}
function fcFlip()  { document.getElementById('fc-inner').classList.toggle('flipped'); }
function fcNav(d)  { fcIdx = (fcIdx + d + fcDeck.length) % fcDeck.length; fcShow(); }

/* ───────────────────────────────────────────────────────────────
   MCQ QUIZ
───────────────────────────────────────────────────────────────── */
var MCQ = {
  ds: [
    {q:'Which data structure is used for BFS traversal?',          opts:['Stack','Queue','Heap','Graph'],      ans:1, exp:'BFS processes nodes level by level using a queue (FIFO).'},
    {q:'Height of a complete binary tree with n nodes?',           opts:['O(n)','O(log n)','O(n²)','O(1)'],   ans:1, exp:'A complete binary tree has height ⌊log₂n⌋.'},
    {q:'Best average-case sorting algorithm?',                     opts:['Bubble Sort','Insertion Sort','Merge Sort','Selection Sort'], ans:2, exp:'Merge Sort guarantees O(n log n) in all cases.'},
    {q:'Stack overflow occurs when:',                              opts:['Stack is empty','Stack exceeds capacity','Heap is full','NULL pointer'], ans:1, exp:'Stack overflow = push beyond the allocated stack size.'},
    {q:'Which BST traversal gives sorted output?',                 opts:['Pre-order','Post-order','In-order','Level-order'], ans:2, exp:'In-order (left→root→right) of a BST yields ascending order.'},
  ],
  algo: [
    {q:'Dijkstra\'s algorithm solves:',                            opts:['MST','Shortest Path','Topological Sort','Cycle Detection'], ans:1, exp:'Dijkstra finds shortest paths from a source to all vertices.'},
    {q:'Time complexity of merge sort?',                           opts:['O(n)','O(n²)','O(n log n)','O(log n)'], ans:2, exp:'Divide O(log n) × merge O(n) = O(n log n).'},
    {q:'Dynamic programming primarily uses:',                      opts:['Greedy choice','Memoization','Backtracking','Divide & Conquer'], ans:1, exp:'DP stores subproblem results to avoid redundant computation.'},
    {q:'Binary search requires the input to be:',                  opts:['Sorted','Unique','Even length','Unsorted'], ans:0, exp:'Binary search halves the sorted search space each step.'},
    {q:'Cycle detection in a graph uses:',                         opts:['BFS only','DFS with visited set','Dijkstra','Kruskal'], ans:1, exp:'DFS detects cycles via back edges (already-visited nodes).'},
  ],
  os: [
    {q:'Which scheduling can cause starvation?',                   opts:['Round Robin','FCFS','Priority Scheduling','SRTF'], ans:2, exp:'Low-priority processes may never run if higher-priority ones keep arriving.'},
    {q:'TLB speeds up:',                                           opts:['Disk access','Page table lookups','Context switches','I/O'], ans:1, exp:'TLB caches recent virtual→physical address translations.'},
    {q:'A critical section accesses:',                             opts:['Shared resources','Private stack','Interrupt handlers','ROM'], ans:0, exp:'Critical section = code that reads/writes shared data.'},
    {q:'Which page replacement has Belady\'s anomaly?',            opts:['LRU','Optimal','FIFO','LFU'], ans:2, exp:'FIFO can perform worse with MORE frames — Belady\'s anomaly.'},
    {q:'A process enters "waiting" state when:',                   opts:['CPU assigned','I/O requested','Process created','Process exits'], ans:1, exp:'Process waits when it needs I/O or a resource not yet available.'},
  ],
  dbms: [
    {q:'Which NF eliminates partial dependencies?',                opts:['1NF','2NF','3NF','BCNF'], ans:1, exp:'2NF: every non-key attribute depends on the FULL primary key.'},
    {q:'SELECT DISTINCT does what?',                               opts:['Sorts rows','Removes duplicates','Filters NULLs','Limits rows'], ans:1, exp:'DISTINCT eliminates duplicate rows from the result.'},
    {q:'HAVING filters results after:',                            opts:['WHERE','GROUP BY','ORDER BY','JOIN'], ans:1, exp:'HAVING is applied after GROUP BY to filter groups.'},
    {q:'Which JOIN returns all rows from both tables?',            opts:['INNER JOIN','LEFT JOIN','RIGHT JOIN','FULL OUTER JOIN'], ans:3, exp:'FULL OUTER JOIN includes all rows, NULLs for non-matches.'},
    {q:'ROLLBACK does:',                                           opts:['Saves changes','Undoes changes','Starts a transaction','Drops table'], ans:1, exp:'ROLLBACK reverts all changes since the last COMMIT.'},
  ],
  cn: [
    {q:'OSI layer responsible for routing?',                       opts:['Data Link','Transport','Network','Physical'], ans:2, exp:'Network layer (Layer 3) routes packets across networks.'},
    {q:'Default HTTPS port?',                                      opts:['80','21','443','25'], ans:2, exp:'HTTPS uses port 443; HTTP uses port 80.'},
    {q:'ARP maps:',                                                opts:['Domain→IP','IP→MAC','MAC→IP','URL→IP'], ans:1, exp:'ARP resolves IP addresses to MAC addresses on a local network.'},
    {q:'Protocol used for sending email?',                         opts:['FTP','SMTP','IMAP','HTTP'], ans:1, exp:'SMTP (Simple Mail Transfer Protocol) sends email.'},
    {q:'Maximum TTL value in IP packet?',                          opts:['64','128','255','512'], ans:2, exp:'TTL is an 8-bit field, so max = 255.'},
  ],
  oop: [
    {q:'Which OOP concept hides internal state?',                  opts:['Inheritance','Polymorphism','Encapsulation','Abstraction'], ans:2, exp:'Encapsulation bundles data + methods and restricts direct access.'},
    {q:'A class that cannot be instantiated:',                     opts:['Static class','Abstract class','Final class','Interface'], ans:1, exp:'Abstract classes cannot be instantiated directly.'},
    {q:'Method overloading is:',                                   opts:['Runtime polymorphism','Compile-time polymorphism','Inheritance','Encapsulation'], ans:1, exp:'Overloading is resolved at compile time by method signature.'},
    {q:'"IS-A" relationship in OOP is:',                          opts:['Association','Composition','Inheritance','Aggregation'], ans:2, exp:'Inheritance models IS-A (e.g. Dog IS-A Animal).'},
    {q:'Keyword to prevent subclassing in Java:',                  opts:['static','abstract','final','private'], ans:2, exp:'"final" on a class prevents it from being extended.'},
  ],
};

var mcqAnswered = 0, mcqCorrect = 0, mcqQuestions = [];

function mcqLoad() {
  var topic = document.getElementById('mcq-topic').value;
  mcqQuestions = MCQ[topic].slice().sort(function() { return Math.random() - .5; }).slice(0, 5);
  mcqAnswered  = mcqCorrect = 0;
  document.getElementById('mcq-result').style.display = 'none';

  var html = '';
  mcqQuestions.forEach(function(q, qi) {
    var opts = q.opts.map(function(o, oi) {
      return '<button onclick="mcqAnswer(' + qi + ',' + oi + ',' + q.ans + ')" id="mo-' + qi + '-' + oi + '">' +
             String.fromCharCode(65 + oi) + ') ' + o + '</button>';
    }).join('');
    html += '<div class="mcq-card" id="mc-' + qi + '">' +
            '<div class="mcq-qtxt">Q' + (qi + 1) + '. ' + q.q + '</div>' +
            '<div class="mcq-opts" id="mopts-' + qi + '">' + opts + '</div>' +
            '<div class="mcq-explain" id="mexp-' + qi + '">' + q.exp + '</div>' +
            '</div>';
  });
  document.getElementById('mcq-area').innerHTML = html;
}

function mcqAnswer(qi, chosen, correct) {
  var opts = document.getElementById('mopts-' + qi);
  if (!opts || opts.getAttribute('data-done')) return;
  opts.setAttribute('data-done', '1');
  opts.querySelectorAll('button').forEach(function(btn, i) {
    btn.disabled = true;
    if (i === correct) btn.classList.add('correct');
    else if (i === chosen) btn.classList.add('wrong');
  });
  document.getElementById('mexp-' + qi).style.display = 'block';
  mcqAnswered++;
  if (chosen === correct) mcqCorrect++;

  if (mcqAnswered === mcqQuestions.length) {
    var pct = Math.round(mcqCorrect / mcqQuestions.length * 100);
    var icon = pct >= 80 ? '🏆' : pct >= 50 ? '👍' : '📚';
    var res = document.getElementById('mcq-result');
    res.style.display = 'block';
    res.innerHTML = '<div style="font-size:2rem;margin-bottom:8px;">' + icon + '</div>' +
      '<div style="font-size:1.2rem;font-weight:900;color:#10b981;margin-bottom:6px;">Quiz Complete!</div>' +
      '<div style="color:#94a3b8;margin-bottom:10px;">Score: <strong style="color:#e2e8f0;">' + mcqCorrect + '/' + mcqQuestions.length + '</strong> (' + pct + '%)</div>' +
      '<div class="score-bar"><div class="score-fill" id="msf" style="width:0%"></div></div>' +
      '<button class="btn btn-primary btn-sm" style="margin-top:14px;" onclick="mcqLoad()">🔄 New Quiz</button>';
    setTimeout(function() { var sf = document.getElementById('msf'); if (sf) sf.style.width = pct + '%'; }, 100);
    res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

// Load first MCQ set on page load
mcqLoad();

/* ───────────────────────────────────────────────────────────────
   TYPING TEST
───────────────────────────────────────────────────────────────── */
var TP_CATS = {
  'CS Quotes': [
    'Any fool can write code that a computer can understand.',
    'First solve the problem then write the code.',
    'The best code is no code at all.',
    'Debugging is twice as hard as writing the code in the first place.',
    'Simplicity is the soul of efficiency.',
    'Programs must be written for people to read.',
  ],
  'Python': [
    'def factorial(n): return 1 if n == 0 else n * factorial(n - 1)',
    'result = [x ** 2 for x in range(10) if x % 2 == 0]',
    'data = sorted(items, key=lambda x: x[1], reverse=True)',
    'nums = list(map(int, input().split()))',
    'with open("data.txt", "r") as f: content = f.read()',
  ],
  'SQL': [
    'SELECT name, age FROM students WHERE age > 18 ORDER BY name ASC;',
    'INSERT INTO users (name, email) VALUES ("Alice", "alice@example.com");',
    'SELECT dept, COUNT(*) FROM employees GROUP BY dept HAVING COUNT(*) > 5;',
    'UPDATE orders SET status = "shipped" WHERE order_id = 42;',
    'SELECT * FROM products WHERE price BETWEEN 100 AND 500;',
  ],
  'HTML': [
    '<div class="container"><h1>Hello World</h1></div>',
    '<input type="text" id="name" placeholder="Enter your name" required />',
    '<a href="https://example.com" target="_blank" rel="noopener">Visit Site</a>',
    '<button type="submit" class="btn btn-primary">Submit Form</button>',
  ],
};

var tpCat = 'CS Quotes', tpText = '', tpTyped = '', tpStart = null, tpTimer = null, tpFinished = false;

(function initTP() {
  var row = document.getElementById('tp-cats');
  row.innerHTML = Object.keys(TP_CATS).map(function(c) {
    return '<button class="pill' + (c === tpCat ? ' sel' : '') + '" onclick="tpPickCat(this,\'' + c + '\')">' + c + '</button>';
  }).join('');
  tpNew();
})();

function tpPickCat(btn, cat) {
  tpCat = cat;
  document.querySelectorAll('#tp-cats .pill').forEach(function(b) { b.classList.remove('sel'); });
  btn.classList.add('sel');
  tpNew();
}
function tpNew() {
  clearInterval(tpTimer);
  var arr = TP_CATS[tpCat];
  tpText     = arr[Math.floor(Math.random() * arr.length)];
  tpTyped    = '';
  tpStart    = null;
  tpFinished = false;
  var inp = document.getElementById('tp-input');
  inp.value    = '';
  inp.disabled = false;
  document.getElementById('tp-wpm').textContent  = '0';
  document.getElementById('tp-acc').textContent  = '—';
  document.getElementById('tp-time').textContent = '0s';
  document.getElementById('tp-chars').textContent= '0';
  document.getElementById('tp-done').style.display = 'none';
  tpRender();
  // Only focus if the panel is currently visible
  var panel = document.getElementById('sh-type');
  if (panel && panel.classList.contains('active')) inp.focus();
}
function tpRender() {
  var html = '';
  for (var i = 0; i < tpText.length; i++) {
    var ch = tpText[i] === ' ' ? '&nbsp;' : tpText[i];
    if (i < tpTyped.length) {
      html += '<span class="' + (tpTyped[i] === tpText[i] ? 'ch-done' : 'ch-err') + '">' + ch + '</span>';
    } else if (i === tpTyped.length) {
      html += '<span class="ch-cur">' + ch + '</span>';
    } else {
      html += '<span class="ch-todo">' + ch + '</span>';
    }
  }
  document.getElementById('tp-display').innerHTML = html;
}
function tpInput(e) {
  if (tpFinished) return;
  tpTyped = document.getElementById('tp-input').value;

  if (!tpStart && tpTyped.length > 0) {
    tpStart = Date.now();
    tpTimer = setInterval(tpStats, 300);
  }
  tpRender();
  tpStats();

  if (tpTyped.length >= tpText.length) {
    tpTyped    = tpTyped.slice(0, tpText.length);
    tpFinished = true;
    clearInterval(tpTimer);
    document.getElementById('tp-input').disabled = true;
    tpStats();
    var elapsed = ((Date.now() - tpStart) / 1000).toFixed(1);
    var wpm = document.getElementById('tp-wpm').textContent;
    var acc = document.getElementById('tp-acc').textContent;
    document.getElementById('tp-done-stats').textContent = wpm + ' WPM · ' + acc + ' accuracy · ' + elapsed + 's';
    document.getElementById('tp-done').style.display = 'block';
  }
}
function tpStats() {
  if (!tpStart) return;
  var elapsed = (Date.now() - tpStart) / 1000;
  var words = tpTyped.trim().split(/\s+/).filter(Boolean).length || 0;
  var wpm   = elapsed > 0 ? Math.round((words / elapsed) * 60) : 0;
  var correct = 0;
  for (var i = 0; i < tpTyped.length; i++) if (tpTyped[i] === tpText[i]) correct++;
  var acc = tpTyped.length > 0 ? Math.round((correct / tpTyped.length) * 100) : 100;
  document.getElementById('tp-wpm').textContent   = wpm;
  document.getElementById('tp-acc').textContent   = acc + '%';
  document.getElementById('tp-time').textContent  = Math.round(elapsed) + 's';
  document.getElementById('tp-chars').textContent = tpTyped.length;
}

/* ───────────────────────────────────────────────────────────────
   POMODORO TIMER
───────────────────────────────────────────────────────────────── */
var PM_CIRC   = 2 * Math.PI * 95; // ~596.9
var pmMode    = 'focus';
var pmMins    = 25, pmSecs = 0;
var pmTotal   = 25 * 60;
var pmElapsed = 0;
var pmRunning = false;
var pmTick    = null;
var pmSessions= 0;

var PM_LABELS = { focus: 'FOCUS TIME', short: 'SHORT BREAK', long: 'LONG BREAK' };

function pmSetMode(mode, mins, btn) {
  pmMode = mode; pmMins = mins;
  pmTotal = mins * 60; pmElapsed = 0; pmSecs = 0;
  document.querySelectorAll('.pm-modes .pill').forEach(function(b) { b.classList.remove('sel'); });
  btn.classList.add('sel');
  document.getElementById('pm-lbl').textContent = PM_LABELS[mode];
  pmReset();
}
function pmToggle() {
  if (pmRunning) {
    clearInterval(pmTick); pmRunning = false;
    document.getElementById('pm-btn').textContent = '▶ Resume';
  } else {
    pmRunning = true;
    document.getElementById('pm-btn').textContent = '⏸ Pause';
    pmTick = setInterval(function() {
      pmElapsed++;
      var remaining = pmTotal - pmElapsed;
      if (remaining <= 0) {
        clearInterval(pmTick); pmRunning = false;
        document.getElementById('pm-btn').textContent = '▶ Start';
        if (pmMode === 'focus') {
          pmSessions++;
          document.getElementById('pm-sess').innerHTML = 'Sessions completed: <strong>' + pmSessions + '</strong>';
        }
        pmMins = 0; pmSecs = 0;
        pmDraw(0);
        pmClock(0, 0);
        if (window.Notification && Notification.permission === 'granted') {
          new Notification('Devloom — ' + (pmMode === 'focus' ? 'Focus session done! Take a break.' : 'Break over! Time to focus.'));
        }
        return;
      }
      pmMins = Math.floor(remaining / 60);
      pmSecs = remaining % 60;
      pmClock(pmMins, pmSecs);
      pmDraw(remaining);
    }, 1000);
  }
}
function pmReset() {
  clearInterval(pmTick); pmRunning = false;
  pmElapsed = 0; pmMins = pmTotal / 60; pmSecs = 0;
  document.getElementById('pm-btn').textContent = '▶ Start';
  pmClock(pmMins, 0);
  pmDraw(pmTotal);
}
function pmClock(m, s) {
  document.getElementById('pm-clock').textContent = String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}
function pmDraw(remaining) {
  var pct    = pmTotal > 0 ? remaining / pmTotal : 1;
  var offset = PM_CIRC * (1 - pct);
  document.getElementById('pm-arc').style.strokeDasharray  = PM_CIRC;
  document.getElementById('pm-arc').style.strokeDashoffset = offset;
}

// Init pomodoro display
pmDraw(pmTotal);
if (window.Notification && Notification.permission === 'default') {
  Notification.requestPermission();
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
