<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Smart Flashcards';
$activePage = 'features';
$hasKey = defined('ANTHROPIC_API_KEY') && ANTHROPIC_API_KEY !== 'YOUR_API_KEY_HERE';
include __DIR__ . '/includes/header.php';
?>
<style>
.fc-wrap{max-width:820px;margin:0 auto;padding:36px 0 80px;}
.fc-header{text-align:center;margin-bottom:32px;}
.fc-header h1{font-size:2.1rem;font-weight:900;color:#f1f5f9;margin-bottom:8px;}
.topic-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:10px;margin-bottom:24px;}
.topic-btn{padding:14px 10px;border:1.5px solid rgba(255,255,255,.1);border-radius:12px;background:rgba(255,255,255,.04);color:#cbd5e1;font-size:12px;font-weight:600;cursor:pointer;transition:all .2s;text-align:center;line-height:1.5;}
.topic-btn:hover,.topic-btn.sel{border-color:rgba(99,102,241,.5);background:rgba(99,102,241,.1);color:#a5b4fc;}
.nokey-warn{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);border-radius:12px;padding:16px 20px;margin-bottom:20px;font-size:.9rem;color:#fca5a5;line-height:1.7;}
/* Flashcard */
.card-scene{width:100%;max-width:560px;height:240px;perspective:1000px;margin:0 auto 20px;cursor:pointer;}
.card-3d{width:100%;height:100%;position:relative;transform-style:preserve-3d;transition:transform .55s cubic-bezier(.4,0,.2,1);}
.card-3d.flipped{transform:rotateY(180deg);}
.card-face{position:absolute;inset:0;border-radius:18px;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px;backface-visibility:hidden;text-align:center;}
.card-front{background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.1));border:1.5px solid rgba(99,102,241,.3);}
.card-back{background:linear-gradient(135deg,rgba(16,185,129,.12),rgba(20,184,166,.08));border:1.5px solid rgba(16,185,129,.3);transform:rotateY(180deg);}
.card-label{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;margin-bottom:12px;opacity:.6;}
.card-text{font-size:1.1rem;font-weight:600;color:#e2e8f0;line-height:1.65;}
.fc-controls{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:12px;}
.fc-progress{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:18px;}
.fc-pbox{background:rgba(0,0,0,.2);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:5px 14px;text-align:center;}
.fc-pbox .lbl{font-size:10px;color:#64748b;font-family:monospace;text-transform:uppercase;display:block;}
.fc-pbox .val{font-size:15px;font-weight:800;color:#e2e8f0;}
.deck-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;margin-top:12px;}
.deck-thumb{background:rgba(99,102,241,.07);border:1.5px solid rgba(99,102,241,.2);border-radius:12px;padding:14px 12px;cursor:pointer;transition:all .2s;text-align:center;}
.deck-thumb:hover{border-color:rgba(99,102,241,.5);background:rgba(99,102,241,.12);}
.deck-thumb .dname{font-size:13px;font-weight:700;color:#e2e8f0;margin-bottom:4px;}
.deck-thumb .dcount{font-size:11px;color:#64748b;}
.loading-dots span{display:inline-block;width:6px;height:6px;border-radius:50%;background:#818cf8;margin:0 2px;animation:blink 1.2s infinite;}
.loading-dots span:nth-child(2){animation-delay:.2s;}.loading-dots span:nth-child(3){animation-delay:.4s;}
@keyframes blink{0%,80%,100%{opacity:.2}40%{opacity:1}}
</style>

<div class="container">
<div class="fc-wrap">
  <div class="fc-header">
    <h1>🃏 Smart Flashcards</h1>
    <p style="color:#94a3b8;">AI generates flashcards on any CS topic. Study, flip, track your progress!</p>
  </div>

  <?php if (!$hasKey): ?>
  <div class="nokey-warn" id="apikey-warn">
    ⚠ <strong>API key not set in server config.</strong> Enter your Anthropic API key below to use Smart Flashcards, or add it permanently in <code>config/db.php</code>.
    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <input type="password" id="user-api-key" placeholder="sk-ant-api03-..." style="flex:1;min-width:220px;padding:8px 12px;border-radius:8px;border:1px solid rgba(239,68,68,.4);background:rgba(0,0,0,.3);color:#fca5a5;font-size:13px;font-family:monospace;" oninput="checkApiKey()">
      <button onclick="saveApiKey()" style="padding:8px 16px;border-radius:8px;background:rgba(99,102,241,.2);border:1px solid rgba(99,102,241,.4);color:#a5b4fc;font-size:13px;cursor:pointer;">Save Key</button>
    </div>
    <div id="apikey-status" style="font-size:12px;margin-top:6px;"></div>
  </div>
  <?php endif; ?>

  <div id="setup-panel">
    <div style="font-size:11px;font-family:monospace;color:#64748b;text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px;">1. Choose Topic</div>
    <div class="topic-grid">
      <?php foreach(['Data Structures','Algorithms','DBMS','Operating Systems','Computer Networks','OOP Concepts','Python','Java','C / C++','JavaScript','SQL','System Design','Machine Learning','Web Development','Discrete Math'] as $t): ?>
      <button class="topic-btn" onclick="pickTopic(this,'<?= $t ?>')"><?= $t ?></button>
      <?php endforeach; ?>
    </div>
    <div style="margin-bottom:20px;">
      <div style="font-size:11px;font-family:monospace;color:#64748b;text-transform:uppercase;letter-spacing:.1em;margin-bottom:10px;">2. Number of Cards</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <?php foreach([5,10,15,20] as $n): ?>
        <button class="topic-btn" id="n-<?= $n ?>" onclick="pickN(<?= $n ?>,this)" style="min-width:60px;padding:10px;"><?= $n ?></button>
        <?php endforeach; ?>
      </div>
    </div>
    <div style="margin-bottom:20px;">
      <div style="font-size:11px;font-family:monospace;color:#64748b;text-transform:uppercase;letter-spacing:.1em;margin-bottom:10px;">3. Difficulty</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button class="topic-btn" id="d-Beginner" onclick="pickDiff('Beginner',this)">🌱 Beginner</button>
        <button class="topic-btn" id="d-Intermediate" onclick="pickDiff('Intermediate',this)">🎯 Intermediate</button>
        <button class="topic-btn" id="d-Advanced" onclick="pickDiff('Advanced',this)">🔥 Advanced</button>
      </div>
    </div>
    <button class="btn btn-primary" id="gen-btn" onclick="generateDeck()" disabled style="opacity:.4;cursor:not-allowed;">✨ Generate Flashcards</button>
    <div id="gen-status" style="margin-top:14px;font-size:13px;color:#64748b;"></div>

    <?php if(!empty($_SESSION['fc_decks'])): ?>
    <div style="margin-top:32px;">
      <div style="font-size:11px;font-family:monospace;color:#64748b;text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px;">Saved Decks</div>
      <div class="deck-list" id="saved-decks"></div>
    </div>
    <?php endif; ?>
  </div>

  <div id="study-panel" style="display:none;">
    <button onclick="backToSetup()" style="background:none;border:1px solid rgba(255,255,255,.12);border-radius:20px;color:#94a3b8;font-size:13px;padding:7px 14px;cursor:pointer;margin-bottom:20px;">← Back</button>
    <div class="fc-progress">
      <div class="fc-pbox"><span class="lbl">Card</span><span class="val" id="fc-idx">1/10</span></div>
      <div class="fc-pbox"><span class="lbl">Know It ✅</span><span class="val" id="fc-know" style="color:#10b981;">0</span></div>
      <div class="fc-pbox"><span class="lbl">Review 🔁</span><span class="val" id="fc-rev" style="color:#f59e0b;">0</span></div>
    </div>
    <div id="fc-topic-lbl" style="text-align:center;font-size:12px;color:#64748b;margin-bottom:10px;"></div>
    <div class="card-scene" onclick="flipCard()">
      <div class="card-3d" id="card-3d">
        <div class="card-face card-front">
          <span class="card-label">Question</span>
          <div class="card-text" id="card-q">—</div>
        </div>
        <div class="card-face card-back">
          <span class="card-label">Answer</span>
          <div class="card-text" id="card-a" style="font-size:.97rem;">—</div>
        </div>
      </div>
    </div>
    <p style="text-align:center;font-size:12px;color:#475569;margin-bottom:12px;">👆 Click card to flip</p>
    <div class="fc-controls" id="fc-btns" style="display:none;">
      <button class="btn btn-ghost" onclick="fcMark('review')">🔁 Need Review</button>
      <button class="btn btn-primary" onclick="fcMark('know')">✅ Know It!</button>
    </div>
    <div class="fc-controls">
      <button class="btn btn-ghost btn-sm" onclick="fcPrev()">← Prev</button>
      <button class="btn btn-ghost btn-sm" onclick="fcNext()">Next →</button>
      <button class="btn btn-ghost btn-sm" onclick="fcShuffle()">🔀 Shuffle</button>
    </div>
    <div id="fc-result" style="display:none;text-align:center;padding:28px;background:rgba(16,185,129,.05);border:1px solid rgba(16,185,129,.15);border-radius:16px;margin-top:16px;"></div>
  </div>
</div>
</div>

<script>
var fcTopic='', fcN=10, fcDiff='Beginner', fcCards=[], fcIdx=0, fcFlipped=false;
var fcKnow=0,fcReview=0;
var fcMarked={};

var _userApiKey = sessionStorage.getItem('devloom_api_key') || '';
function checkApiKey(){var k=document.getElementById('user-api-key');if(k&&k.value.startsWith('sk-ant-')){document.getElementById('apikey-status').textContent='✓ Key looks valid';document.getElementById('apikey-status').style.color='#6ee7b7';}else{document.getElementById('apikey-status').textContent='';}}
function saveApiKey(){var k=document.getElementById('user-api-key');if(!k)return;var v=k.value.trim();if(!v.startsWith('sk-ant-')){document.getElementById('apikey-status').textContent='⚠ Key must start with sk-ant-';return;}_userApiKey=v;sessionStorage.setItem('devloom_api_key',v);document.getElementById('apikey-warn').style.display='none';}
function getApiHeaders(){var h={'Content-Type':'application/json'};var k=_userApiKey||sessionStorage.getItem('devloom_api_key')||'';if(k)h['X-Api-Key']=k;return h;}
function pickTopic(btn,t){document.querySelectorAll('.topic-btn').forEach(b=>{if(!b.id.startsWith('n-')&&!b.id.startsWith('d-'))b.classList.remove('sel');});btn.classList.add('sel');fcTopic=t;checkReady();}
function pickN(n,btn){document.querySelectorAll('[id^="n-"]').forEach(b=>b.classList.remove('sel'));btn.classList.add('sel');fcN=n;checkReady();}
function pickDiff(d,btn){document.querySelectorAll('[id^="d-"]').forEach(b=>b.classList.remove('sel'));btn.classList.add('sel');fcDiff=d;checkReady();}
function checkReady(){var ok=fcTopic&&fcN&&fcDiff;var gb=document.getElementById('gen-btn');gb.disabled=!ok;gb.style.opacity=ok?'1':'.4';gb.style.cursor=ok?'pointer':'not-allowed';}

async function generateDeck(){
  var st=document.getElementById('gen-status');
  st.innerHTML='<span class="loading-dots"><span></span><span></span><span></span></span> Generating '+fcN+' flashcards on '+fcTopic+'...';
  document.getElementById('gen-btn').disabled=true;
  var sys='You are an expert CS educator. Generate exactly '+fcN+' flashcard pairs for the topic "'+fcTopic+'" at '+fcDiff+' level. Return ONLY a JSON array, no markdown, no explanation. Format: [{"q":"question text","a":"answer text"}, ...]. Keep answers concise (1-3 sentences).';
  var msgs=[{role:'user',content:'Generate '+fcN+' flashcard pairs for '+fcTopic+' at '+fcDiff+' level. Return only JSON array.'}];
  try{
    var res=await fetch('/devloom/api_proxy.php',{method:'POST',headers:getApiHeaders(),body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:1000,system:sys,messages:msgs})});
    var data=await res.json();
    if(data.error==='api_key_missing'){st.innerHTML='⚠ No API key. <a href="#" onclick="document.getElementById(\'apikey-warn\').style.display=\'block\';return false;" style="color:#a5b4fc;">Enter your key above</a>';document.getElementById('gen-btn').disabled=false;return;}
    if(data.error){st.textContent='⚠ '+(data.message||data.error);document.getElementById('gen-btn').disabled=false;return;}
    var txt=data.content.map(c=>c.text||'').join('');
    var clean=txt.replace(/```json|```/g,'').trim();
    fcCards=JSON.parse(clean);
    if(!Array.isArray(fcCards)||!fcCards[0]?.q){throw new Error('Bad format');}
    fcIdx=0;fcFlipped=false;fcKnow=0;fcReview=0;fcMarked={};
    startStudy();
  }catch(e){st.textContent='⚠ Failed to parse cards. Please try again.';document.getElementById('gen-btn').disabled=false;}
}

function startStudy(){
  document.getElementById('setup-panel').style.display='none';
  document.getElementById('study-panel').style.display='block';
  document.getElementById('fc-topic-lbl').textContent='📚 '+fcTopic+' · '+fcDiff+' · '+fcCards.length+' cards';
  document.getElementById('fc-result').style.display='none';
  renderCard();
}
function backToSetup(){
  document.getElementById('study-panel').style.display='none';
  document.getElementById('setup-panel').style.display='block';
  document.getElementById('gen-status').textContent='';
  document.getElementById('gen-btn').disabled=false;
}
function renderCard(){
  if(!fcCards.length)return;
  var card=fcCards[fcIdx];
  document.getElementById('card-q').textContent=card.q;
  document.getElementById('card-a').textContent=card.a;
  document.getElementById('fc-idx').textContent=(fcIdx+1)+'/'+fcCards.length;
  document.getElementById('fc-know').textContent=fcKnow;
  document.getElementById('fc-rev').textContent=fcReview;
  // Reset flip
  var c3=document.getElementById('card-3d');c3.classList.remove('flipped');fcFlipped=false;
  document.getElementById('fc-btns').style.display='none';
  var m=fcMarked[fcIdx];
  if(m){
    var lbl=m==='know'?'✅ Know It':'🔁 Review';
    var col=m==='know'?'#10b981':'#f59e0b';
    // Show subtle mark
    c3.style.outline=m==='know'?'2px solid rgba(16,185,129,.35)':'2px solid rgba(245,158,11,.35)';
  } else {c3.style.outline='none';}
}
function flipCard(){
  var c3=document.getElementById('card-3d');
  c3.classList.toggle('flipped');
  fcFlipped=!fcFlipped;
  document.getElementById('fc-btns').style.display=fcFlipped?'flex':'none';
}
function fcMark(type){
  var prev=fcMarked[fcIdx];
  if(prev===type){fcMarked[fcIdx]=null;if(type==='know')fcKnow--;else fcReview--;}
  else{if(prev==='know')fcKnow--;else if(prev==='review')fcReview--;fcMarked[fcIdx]=type;if(type==='know')fcKnow++;else fcReview++;}
  fcNext();
}
function fcNext(){
  if(fcIdx<fcCards.length-1){fcIdx++;renderCard();}
  else{showResult();}
}
function fcPrev(){if(fcIdx>0){fcIdx--;renderCard();}}
function fcShuffle(){fcCards.sort(()=>Math.random()-.5);fcIdx=0;fcMarked={};fcKnow=0;fcReview=0;renderCard();}
function showResult(){
  var total=fcCards.length;
  var pct=Math.round(fcKnow/total*100);
  document.getElementById('fc-result').style.display='block';
  document.getElementById('fc-result').innerHTML=
    '<div style="font-size:2.5rem;margin-bottom:10px;">'+(pct>=80?'🏆':pct>=50?'👍':'📚')+'</div>'+
    '<div style="font-size:1.3rem;font-weight:900;color:#10b981;margin-bottom:6px;">Deck Complete!</div>'+
    '<div style="color:#94a3b8;margin-bottom:16px;">You knew <strong style="color:#10b981;">'+fcKnow+'</strong> / '+total+' cards ('+pct+'%)</div>'+
    (fcReview>0?'<div style="color:#f59e0b;font-size:13px;margin-bottom:14px;">'+fcReview+' card(s) marked for review</div>':'')+
    '<button class="btn btn-primary btn-sm" onclick="fcIdx=0;fcKnow=0;fcReview=0;fcMarked={};document.getElementById(\'fc-result\').style.display=\'none\';renderCard();">🔄 Study Again</button> '+
    '<button class="btn btn-ghost btn-sm" onclick="backToSetup()">Choose New Topic</button>';
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
