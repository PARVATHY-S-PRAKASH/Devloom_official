This folder stores uploaded files (screenshots + project deliverables).
The folder was renamed from uploads/screenshots/ to uploads/files/
to support all file types.

If you have existing files in uploads/screenshots/, move them here.
