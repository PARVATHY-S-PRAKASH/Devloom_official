<?php
require_once __DIR__ . '/config/db.php';
requireUser();

$userId = currentUserId();
$error  = flash('error');
$success = flash('success');

// ── Fetch fresh user row ──────────────────────────────────────
function fetchUser(PDO $pdo, int $id): array {
    $s = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $s->execute([$id]);
    return $s->fetch() ?: [];
}
$user = fetchUser($pdo, $userId);

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    // ── UPDATE PROFILE INFO ───────────────────────────────────
    if ($action === 'update_profile') {
        $name     = trim($_POST['name']     ?? '');
        $address  = trim($_POST['address']  ?? '');
        $username = strtolower(trim($_POST['username'] ?? ''));
        $email    = trim($_POST['email']    ?? '');
        $phone    = trim($_POST['phone']    ?? '');
        $bio      = trim($_POST['bio']      ?? '');
        $secQ     = trim($_POST['security_question'] ?? '');
        $secARaw  = trim($_POST['security_answer']   ?? '');

        if (!$name)
            $error = 'Full name is required.';
        elseif (!$username || !preg_match('/^[a-zA-Z0-9_]{3,60}$/', $username))
            $error = 'Username must be 3–60 chars (letters, numbers, underscores).';
        elseif ($email && !filter_var($email, FILTER_VALIDATE_EMAIL))
            $error = 'Enter a valid email address (or leave blank).';
        else {
            // Check username uniqueness (exclude self)
            $chk = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $chk->execute([$username, $userId]);
            if ($chk->fetch()) {
                $error = 'That username is already taken.';
            } else {
                // Recompute avatar initials from name
                $avatar = strtoupper(substr($name, 0, 1));
                $parts  = explode(' ', $name);
                if (isset($parts[1])) $avatar .= strtoupper(substr($parts[1], 0, 1));

                // Build security fields
                $secQSave = $secQ ?: ($user['security_question'] ?? '');
                // Only update answer if a new one was provided
                if ($secARaw !== '') {
                    $secASave = password_hash(strtolower($secARaw), PASSWORD_DEFAULT);
                } else {
                    $secASave = $user['security_answer'] ?? '';
                }

                // Ensure address column exists
                try {
                    $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
                    if (!in_array('address', $cols))
                        $pdo->exec("ALTER TABLE users ADD COLUMN address TEXT DEFAULT ''");
                } catch (PDOException $e) {}

                $pdo->prepare(
                    "UPDATE users SET name=?,username=?,email=?,phone=?,bio=?,avatar=?,address=?,
                                     security_question=?,security_answer=? WHERE id=?"
                )->execute([$name, $username, $email ?: null, $phone, $bio, $avatar, $address,
                             $secQSave, $secASave, $userId]);

                // Update session
                $_SESSION['user_name']   = $name;
                $_SESSION['user_avatar'] = $avatar;

                flash('success', 'Profile updated successfully!');
                header('Location: /devloom/profile.php'); exit;
            }
        }
    }

    // ── UPLOAD PROFILE PHOTO ──────────────────────────────────
    if ($action === 'upload_photo') {
        $avatarDir = __DIR__ . '/uploads/avatars/';
        if (!is_dir($avatarDir)) mkdir($avatarDir, 0755, true);

        if (empty($_FILES['photo']['name'])) {
            $error = 'No file selected.';
        } else {
            $file     = $_FILES['photo'];
            $origName = $file['name'];
            $tmpPath  = $file['tmp_name'];
            $size     = $file['size'];
            $errCode  = $file['error'];

            if ($errCode !== UPLOAD_ERR_OK) {
                $uploadErrors = [
                    UPLOAD_ERR_INI_SIZE   => 'File exceeds server upload limit.',
                    UPLOAD_ERR_FORM_SIZE  => 'File exceeds form size limit.',
                    UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded.',
                    UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
                    UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder.',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                    UPLOAD_ERR_EXTENSION  => 'Upload blocked by server extension.',
                ];
                $error = $uploadErrors[$errCode] ?? 'Unknown upload error.';
            } elseif ($size > 3 * 1024 * 1024) {
                $error = 'Photo must be under 3 MB.';
            } else {
                $ext     = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                $allowed = ['jpg','jpeg','png','gif','webp'];
                if (!in_array($ext, $allowed)) {
                    $error = 'Unsupported format. Allowed: JPG, JPEG, PNG, GIF, WEBP.';
                } else {
                    // Verify it's a real image
                    $imgInfo = @getimagesize($tmpPath);
                    if (!$imgInfo) {
                        $error = 'Uploaded file is not a valid image.';
                    } else {
                        // Delete old photo if exists
                        if (!empty($user['profile_photo'])) {
                            $oldPath = $avatarDir . basename($user['profile_photo']);
                            if (file_exists($oldPath)) @unlink($oldPath);
                        }
                        $newName = 'avatar_' . $userId . '_' . time() . '.' . $ext;
                        if (move_uploaded_file($tmpPath, $avatarDir . $newName)) {
                            $pdo->prepare("UPDATE users SET profile_photo=? WHERE id=?")
                                ->execute([$newName, $userId]);
                            flash('success', 'Profile photo updated!');
                            header('Location: /devloom/profile.php'); exit;
                        } else {
                            $error = 'Failed to save the uploaded file. Check server permissions.';
                        }
                    }
                }
            }
        }
    }

    // ── REMOVE PROFILE PHOTO ─────────────────────────────────
    if ($action === 'remove_photo') {
        if (!empty($user['profile_photo'])) {
            $oldPath = __DIR__ . '/uploads/avatars/' . basename($user['profile_photo']);
            if (file_exists($oldPath)) @unlink($oldPath);
        }
        $pdo->prepare("UPDATE users SET profile_photo='' WHERE id=?")->execute([$userId]);
        flash('success', 'Profile photo removed.');
        header('Location: /devloom/profile.php'); exit;
    }

    // Re-fetch after failed update (non-redirect path)
    $user = fetchUser($pdo, $userId);
}

// ── Helpers ───────────────────────────────────────────────────
$photoUrl = '';
if (!empty($user['profile_photo'])) {
    $photoUrl = '/devloom/uploads/avatars/' . e(basename($user['profile_photo']));
}

$pageTitle  = 'My Profile';
$activePage = 'dashboard';
include __DIR__ . '/includes/header.php';
?>

<div class="container-sm" style="padding-top:40px;padding-bottom:80px;">

  <!-- Header -->
  <div class="page-header" style="margin-bottom:28px;">
    <div>
      <h1 class="heading-md">👤 My Profile</h1>
      <p class="text-muted" style="margin-top:4px;font-size:14px;">Manage your personal information and photo</p>
    </div>
    <a href="/devloom/dashboard.php" class="btn btn-ghost btn-sm">← Dashboard</a>
  </div>

  <?php if ($error):   ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

  <!-- ── Profile Photo Card ───────────────────────────────── -->
  <div class="card" style="margin-bottom:24px;">
    <h2 class="heading-sm" style="margin-bottom:20px;">📸 Profile Photo</h2>

    <div style="display:flex;align-items:center;gap:24px;flex-wrap:wrap;">

      <!-- Avatar display -->
      <div id="avatar-preview" style="width:100px;height:100px;border-radius:50%;overflow:hidden;
           border:3px solid rgba(16,185,129,0.4);flex-shrink:0;position:relative;
           background:linear-gradient(135deg,#10b981,#14b8a6);
           display:flex;align-items:center;justify-content:center;">
        <?php if ($photoUrl): ?>
          <img src="<?= $photoUrl ?>" alt="Profile photo"
               style="width:100%;height:100%;object-fit:cover;" id="current-photo">
        <?php else: ?>
          <span style="font-family:var(--font-head);font-weight:800;font-size:36px;color:#fff;line-height:1;">
            <?= e($user['avatar'] ?? '?') ?>
          </span>
        <?php endif; ?>
      </div>

      <div style="flex:1;min-width:220px;">
        <!-- Upload form -->
        <form method="POST" enctype="multipart/form-data" id="photo-form"><?= csrf_field() ?>
          <input type="hidden" name="action" value="upload_photo">
          <label class="form-label" style="margin-bottom:8px;display:block;">Upload new photo</label>
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <label class="btn btn-outline btn-sm" style="cursor:pointer;margin:0;">
              📂 Choose File
              <input type="file" name="photo" id="photo-input" accept="image/jpeg,image/png,image/gif,image/webp"
                     style="display:none;" onchange="previewPhoto(this)">
            </label>
            <button type="submit" class="btn btn-primary btn-sm" id="upload-btn" style="display:none;">
              ⬆ Upload
            </button>
          </div>
          <p style="font-size:11px;color:var(--muted);margin-top:8px;line-height:1.5;">
            Supported: JPG, PNG, GIF, WEBP · Max 3 MB
          </p>
          <div id="photo-filename" style="font-size:12px;color:var(--green);margin-top:4px;"></div>
        </form>

        <?php if ($photoUrl): ?>
        <form method="POST" style="margin-top:12px;" onsubmit="return confirm('Remove your profile photo?')"><?= csrf_field() ?>
          <input type="hidden" name="action" value="remove_photo">
          <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--red);border-color:rgba(248,113,113,.3);">
            🗑 Remove Photo
          </button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- ── Profile Info Card ────────────────────────────────── -->
  <div class="card">
    <h2 class="heading-sm" style="margin-bottom:20px;">✏️ Personal Information</h2>

    <form method="POST" autocomplete="off"><?= csrf_field() ?>
      <input type="hidden" name="action" value="update_profile">

      <!-- User ID (read-only) -->
      <div class="form-group">
        <label class="form-label">User ID <span style="color:var(--muted);font-size:11px;">(read-only)</span></label>
        <input type="text" value="<?= e((string)($user['id'] ?? '')) ?>" class="form-control"
               readonly disabled
               style="opacity:.5;cursor:not-allowed;background:rgba(255,255,255,.02);">
      </div>

      <!-- Login username info banner -->
      <div style="background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.2);border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:12px;color:var(--muted);">
        🔑 Your current login username is: <strong style="color:#10b981;"><?= e($user['username'] ?? '') ?></strong> — you can change it below (used to sign in)
      </div>

      <div class="form-row">
        <!-- Full Name -->
        <div class="form-group">
          <label class="form-label">Full Name <span style="color:var(--red)">*</span></label>
          <input type="text" name="name" class="form-control"
                 value="<?= e($user['name'] ?? '') ?>"
                 placeholder="Your full name" required autocomplete="off">
        </div>
        <!-- Username -->
        <div class="form-group">
          <label class="form-label">Username <span style="color:var(--red)">*</span></label>
          <input type="text" name="username" class="form-control"
                 value="<?= e($user['username'] ?? '') ?>"
                 placeholder="your_username" required
                 pattern="[a-zA-Z0-9_]{3,60}"
                 title="3–60 chars: letters, numbers, underscores"
                 style="text-transform:lowercase;"
                 oninput="this.value=this.value.toLowerCase()"
                 autocomplete="off">
          <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">
            Used to sign in · 3–60 chars · letters, numbers, underscores
          </small>
        </div>
      </div>

      <div class="form-row">
        <!-- Email -->
        <div class="form-group">
          <label class="form-label">Email Address <span style="color:var(--muted);font-size:11px;">(optional)</span></label>
          <input type="email" name="email" class="form-control"
                 value="<?= e($user['email'] ?? '') ?>"
                 placeholder="you@email.com" autocomplete="off">
        </div>
        <!-- Phone -->
        <div class="form-group">
          <label class="form-label">Phone Number <span style="color:var(--muted);font-size:11px;">(optional)</span></label>
          <input type="tel" name="phone" class="form-control"
                 value="<?= e($user['phone'] ?? '') ?>"
                 placeholder="+91 98765 43210" autocomplete="off">
        </div>
      </div>

      <!-- Bio -->
      <div class="form-group">
        <label class="form-label">Address <span style="color:var(--muted);font-size:11px;">(optional)</span></label>
        <textarea name="address" class="form-control" rows="2"
                  placeholder="Your full address…"><?= e($user['address'] ?? '') ?></textarea>
      </div>

      <!-- Bio -->
      <div class="form-group">
        <label class="form-label">Bio / About <span style="color:var(--muted);font-size:11px;">(optional)</span></label>
        <textarea name="bio" class="form-control" rows="3"
                  placeholder="Tell us a bit about yourself…"><?= e($user['bio'] ?? '') ?></textarea>
      </div>

      <!-- Security Question -->
      <div style="background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.15);border-radius:10px;padding:14px 16px;margin-bottom:18px;">
        <p style="font-size:12px;color:var(--green);font-weight:700;margin-bottom:10px;letter-spacing:.04em;">🔑 ACCOUNT RECOVERY (Forgot Password)</p>
        <div class="form-group" style="margin-bottom:12px;">
          <label class="form-label">Security Question</label>
          <select name="security_question" class="form-control">
            <option value="">— Choose a question —</option>
            <?php
            $questions = [
                'What was the name of your first pet?',
                'What is your mother\'s maiden name?',
                'What city were you born in?',
                'What was the name of your primary school?',
                'What is your favourite movie?',
                'What was your childhood nickname?',
                'What street did you grow up on?',
            ];
            $currentQ = $user['security_question'] ?? '';
            foreach ($questions as $q): ?>
              <option value="<?= e($q) ?>" <?= $currentQ === $q ? 'selected' : '' ?>><?= e($q) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Answer
            <span style="color:var(--muted);font-size:11px;">
              (leave blank to keep existing<?= !empty($user['security_answer']) ? ' ✓' : '' ?>)
            </span>
          </label>
          <input type="text" name="security_answer" class="form-control"
                 placeholder="Your answer (case-insensitive)" autocomplete="off">
          <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">
            This is used to reset your password without email.
          </small>
        </div>
      </div>

      <!-- Member since (read-only info) -->
      <div class="form-group">
        <label class="form-label">Member Since <span style="color:var(--muted);font-size:11px;">(read-only)</span></label>
        <input type="text"
               value="<?= e(date('F j, Y', strtotime($user['created_at'] ?? 'now'))) ?>"
               class="form-control" readonly disabled
               style="opacity:.5;cursor:not-allowed;background:rgba(255,255,255,.02);">
      </div>

      <div style="display:flex;gap:12px;justify-content:flex-end;margin-top:8px;">
        <a href="/devloom/dashboard.php" class="btn btn-ghost">Cancel</a>
        <button type="submit" class="btn btn-primary">💾 Save Changes</button>
      </div>
    </form>
  </div>

  <!-- ── Quick Links ───────────────────────────────────────── -->
  <div style="display:flex;gap:12px;margin-top:20px;flex-wrap:wrap;">
    <a href="/devloom/change_password.php" class="btn btn-outline btn-sm">🔒 Change Password</a>
    <a href="/devloom/dashboard.php"       class="btn btn-ghost  btn-sm">← Back to Dashboard</a>
  </div>

</div>

<script>
function previewPhoto(input) {
  var btn      = document.getElementById('upload-btn');
  var nameEl   = document.getElementById('photo-filename');
  var preview  = document.getElementById('avatar-preview');

  if (!input.files || !input.files[0]) return;

  var file = input.files[0];
  var maxMB = 3;
  if (file.size > maxMB * 1024 * 1024) {
    alert('File is too large. Maximum size is ' + maxMB + ' MB.');
    input.value = '';
    btn.style.display = 'none';
    nameEl.textContent = '';
    return;
  }

  var allowed = ['image/jpeg','image/png','image/gif','image/webp'];
  if (!allowed.includes(file.type)) {
    alert('Unsupported file type. Please use JPG, PNG, GIF, or WEBP.');
    input.value = '';
    btn.style.display = 'none';
    nameEl.textContent = '';
    return;
  }

  nameEl.textContent = '✓ ' + file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)';
  btn.style.display = 'inline-flex';

  // Show live preview
  var reader = new FileReader();
  reader.onload = function(e) {
    preview.innerHTML = '<img src="' + e.target.result + '" alt="Preview" '
      + 'style="width:100%;height:100%;object-fit:cover;">';
  };
  reader.readAsDataURL(file);
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
