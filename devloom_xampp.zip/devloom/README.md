# Devloom — PHP Web Application
## "Weaving Code Together"

---

## 📁 Folder Structure

```
devloom/
├── index.php            ← Home page
├── auth.php             ← Login & Register
├── dashboard.php        ← User Dashboard
├── logout.php           ← Logout handler
├── contact.php          ← Contact page
│
├── admin/
│   └── index.php        ← Admin Panel
│
├── config/
│   └── db.php           ← DB connection + helpers
│
├── includes/
│   ├── header.php       ← Navbar + HTML head
│   └── footer.php       ← Footer + JS
│
├── assets/
│   └── css/
│       └── style.css    ← All styles
│
├── uploads/
│   └── screenshots/     ← Uploaded project images
│
└── database/
    └── devloom.sql      ← Import this into MySQL
```

---

## 🚀 LOCAL SETUP (XAMPP)

### Step 1 — Start XAMPP
Open XAMPP Control Panel → Start **Apache** and **MySQL**

### Step 2 — Copy Project
Paste the `devloom/` folder into:
```
C:\xampp\htdocs\devloom\          ← Windows
/Applications/XAMPP/htdocs/devloom/  ← Mac
```

### Step 3 — Import Database
1. Open http://localhost/phpmyadmin
2. Click **New** → create database named `devloom`
3. Click the `devloom` database → go to **Import** tab
4. Choose `database/devloom.sql` → click **Go**

### Step 4 — Set Uploads Permissions (Mac/Linux only)
```bash
chmod -R 777 /Applications/XAMPP/htdocs/devloom/uploads/
```

### Step 5 — Open the App
```
http://localhost/devloom/
```

---

## 🔑 Login Credentials

| Role  | Email               | Password     |
|-------|---------------------|--------------|
| Admin | admin@devloom.io    | Admin@2024#  |
| User  | arjun@email.com     | pass123      |
| User  | priya@email.com     | pass123      |

---

## 🌐 LIVE HOSTING (cPanel / Shared Hosting)

### Step 1 — Upload Files
Use **File Manager** or **FileZilla FTP** to upload `devloom/` to:
```
public_html/devloom/
```
OR upload directly to `public_html/` if it's your main site.

### Step 2 — Create MySQL Database (cPanel)
1. cPanel → **MySQL Databases**
2. Create database: `youraccount_devloom`
3. Create user: `youraccount_dluser` with a strong password
4. Add user to database with **All Privileges**

### Step 3 — Import SQL
1. cPanel → **phpMyAdmin**
2. Select your new database → **Import** → upload `devloom.sql`

### Step 4 — Update config/db.php
Edit these lines:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'youraccount_dluser');
define('DB_PASS', 'YourStrongPassword');
define('DB_NAME', 'youraccount_devloom');
```
Also update the paths if the app is in `public_html/` root:
```php
define('UPLOAD_PATH', __DIR__ . '/../uploads/screenshots/');
define('UPLOAD_URL',  '/uploads/screenshots/');   // ← Remove /devloom prefix
```
And in header.php, change `/devloom/` to `/` in all href links.

### Step 5 — Uploads Folder Permissions
In File Manager → right-click `uploads/screenshots/` → **Change Permissions** → set to **755** or **777**

### Step 6 — Visit Your Site
```
https://yourdomain.com/devloom/
```

---

## 🤖 AI Note Feature

The **"Generate with Claude AI"** button in Admin Panel calls the
Anthropic API directly from the browser using JavaScript fetch.

To enable it in production, add your API key to `includes/footer.php`:
```js
headers: {
  'Content-Type': 'application/json',
  'x-api-key': 'sk-ant-YOUR_KEY_HERE',      // ← Add this
  'anthropic-version': '2023-06-01',
  'anthropic-dangerous-direct-browser-ipc': 'true'
}
```
> For production, move this call to a PHP backend (e.g., `ajax/generate_note.php`)
> using cURL so the API key stays server-side and is never exposed.

---

## 🔒 Security Checklist for Production

- [ ] Change `ADMIN_PASS` in `config/db.php` to something very strong
- [ ] Move `config/db.php` above `public_html/` if possible
- [ ] Add `.htaccess` to deny direct access to `/config/` and `/database/`
- [ ] Use HTTPS (free Let's Encrypt via cPanel)
- [ ] Never expose your Claude API key in frontend JS — use a PHP proxy
- [ ] Set `display_errors = Off` in php.ini for production

---

Built with PHP 8+ · MySQL · Pure CSS · No frameworks required

---

## 🔒 Security Changes Made (before publishing)

This copy has been updated with a few safety fixes ahead of public deployment:

1. **Admin password changed** to a random strong value: `iQkcnjUGJbY3Bs` (in `config/db.php`).
   **Log in once, then change it again** — either edit `ADMIN_PASS` in `config/db.php` directly, or set up a proper admin password-change flow.
2. **`DEBUG_MODE`** added to `config/db.php`. Keep it `true` while testing locally; **set it to `false` before going live** so database errors aren't shown to visitors (they're logged to your server's `error_log` instead).
3. **CSRF protection** added — every form that changes data (login, register, password reset/change, profile, messages, and the whole admin panel) now includes a hidden security token that's checked on submit. If you add new forms later, call `csrf_field()` inside the `<form>` tag and `csrf_check()` at the top of that form's POST handler.
4. **File upload whitelist** added (`isAllowedUpload()` in `config/db.php`) — uploads across messages, admin attachments, and project screenshots are now limited to common file types (images, PDFs, Office docs, zip, txt/csv, mp3/mp4) and capped at 10MB, with executable-style extensions always blocked regardless of the list passed in.
5. **AI proxy model** updated to a current Claude model string in `api_proxy.php`.

⚠️ Note: if you deploy on free shared hosting (e.g. InfinityFree), outbound API calls from `api_proxy.php` to Anthropic's API may be unreliable on some free hosts. Test this specific feature after deploying.
