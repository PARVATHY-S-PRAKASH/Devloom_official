Put the built Android app here as:

    devloom.apk

The get-app.php page (https://your-site/devloom/get-app.php) automatically
detects this file and turns on the download button + QR code once it exists.

How to produce devloom.apk:
  See devloom-mobile/README.md, section "Build a downloadable APK".
  Short version:
    cd devloom-mobile
    npm install -g eas-cli
    eas login
    eas build:configure
    eas build -p android --profile preview
  This builds on Expo's servers (not on this web server) and gives you a
  link to download the finished .apk — save that file here as devloom.apk.
