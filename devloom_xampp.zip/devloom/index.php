<?php
require_once __DIR__ . '/config/db.php';
$pageTitle  = 'Home';
$activePage = 'home';
include __DIR__ . '/includes/header.php';
?>

<!-- ── Floating orbs ── -->
<div class="orb-float" style="width:560px;height:560px;top:5%;right:-12%;background:radial-gradient(circle,rgba(16,185,129,.18),transparent 70%);animation-delay:0s;animation-duration:9s;"></div>
<div class="orb-float" style="width:380px;height:380px;bottom:15%;left:-8%;background:radial-gradient(circle,rgba(20,184,166,.14),transparent 70%);animation-delay:3s;animation-duration:11s;"></div>
<div class="orb-float" style="width:220px;height:220px;top:40%;left:35%;background:radial-gradient(circle,rgba(96,165,250,.08),transparent 70%);animation-delay:5s;animation-duration:7s;"></div>

<!-- ── Hero ── -->
<section class="hero animate-up">
  <span class="badge badge-amber mb-16 hero-badge-pulse">🎓 Built for Students &amp; Developers</span>

  <h1 class="heading-xl mb-8">
    Dev<span class="text-green grad-text">loom</span>
  </h1>
  <p class="mono text-muted mb-24" style="font-size:clamp(14px,2.5vw,20px);letter-spacing:.12em;text-transform:uppercase;">
    <span id="hero-tagline" class="typewriter"></span>
  </p>
  <p class="animate-up-2" style="max-width:560px;font-size:17px;line-height:1.8;color:var(--muted);">
    A platform for students to build real projects, sharpen placement skills, prep for viva and interviews —
    all while connecting with an expert dev team.
  </p>

  <div class="flex gap-12 mt-20 flex-wrap flex-center animate-up-2">
    <a href="/devloom/auth.php" class="btn btn-primary" style="padding:14px 36px;font-size:16px;">
      Get Started Free →
    </a>
    <a href="#features" class="btn btn-outline" style="padding:14px 36px;font-size:16px;">
      Explore Features
    </a>
  </div>

  <div class="hero-stats animate-up-3">
    <?php foreach ([['10+','CS Topics Covered'],['6','Study Decks'],['100%','Free to Use']] as [$n,$l]): ?>
    <div style="text-align:center;">
      <div class="hero-stat-num"><?= $n ?></div>
      <div class="hero-stat-label"><?= $l ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<script>
// Typewriter for hero tagline
(function(){
  var phrases=['Weaving Code Together','Build. Learn. Grow.','Your Dev Journey Starts Here'];
  var el=document.getElementById('hero-tagline');
  if(!el) return;
  var pi=0,ci=0,deleting=false,wait=0;
  function tick(){
    var phrase=phrases[pi%phrases.length];
    if(wait>0){ wait--; setTimeout(tick,80); return; }
    if(!deleting){
      el.textContent=phrase.slice(0,++ci);
      if(ci>=phrase.length){ deleting=true; wait=22; }
    } else {
      el.textContent=phrase.slice(0,--ci);
      if(ci===0){ deleting=false; pi++; wait=8; }
    }
    setTimeout(tick, deleting?55:95);
  }
  setTimeout(tick,600);
})();
</script>

<!-- ── What's Inside ── -->
<section class="section" id="features" style="background:rgba(255,255,255,.015);border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
  <div class="container">
    <div class="text-center mb-32 reveal">
      <h2 class="heading-lg mb-12">Everything in <span class="text-green grad-text">One Place</span></h2>
      <p class="text-muted">Tools designed around what students actually need</p>
    </div>
    <div class="grid-2">
      <?php
      $features = [
        ['🎮','Fun Zone','Seven games to play and unwind — Snake, 2048, Memory Match, Word Search, Traffic Escape and more.'],
        ['🏆','Placement Prep','Topic-wise MCQs on Aptitude, SQL, Java, Python and HR. Practice with timed rounds and AI-powered mock interviews.'],
        ['📄','Resume Builder','Fill your details, pick a theme and download a polished PDF resume in minutes — ready for campus placements.'],
        ['🏅','Challenges','Coding challenges and practice problems to sharpen problem-solving and prepare for technical rounds.'],
        ['💬','Team Chat','Reach the dev team directly. Share files, ask questions about your project, and get replies fast.'],
        ['📦','Project Portal','Submit your development project, track its status, view screenshots, and receive the final deliverables with AI code notes.'],
      ];
      foreach ($features as $fi => [$icon,$title,$desc]):
      $dly = 'delay-'.min($fi+1,6);
      ?>
      <div class="card card-hover reveal <?= $dly ?>">
        <div style="font-size:30px;margin-bottom:14px;"><?= $icon ?></div>
        <h3 class="heading-sm mb-8"><?= $title ?></h3>
        <p class="text-muted" style="font-size:14px;line-height:1.75;"><?= $desc ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── How It Works ── -->
<section class="section" id="how-it-works">
  <div class="container-sm">
    <div class="text-center mb-32 reveal">
      <h2 class="heading-lg mb-12">How It <span class="text-green grad-text">Works</span></h2>
      <p class="text-muted">Four steps from registration to results</p>
    </div>
    <?php
    $steps = [
      ['01','Create Your Account',  'Sign up free. Set up your profile and get instant access to all learning tools.'],
      ['02','Study &amp; Prepare',       'Use Placement Prep, Resume Builder, Challenges and Fun Zone to sharpen skills and get campus-ready.'],
      ['03','Submit Your Project',  'Have a dev project? Describe it, set the scope, and our team will review and quote it.'],
      ['04','Receive &amp; Learn',       'Get your completed project with an AI-generated code walkthrough so you understand every line.'],
    ];
    foreach ($steps as $i => [$num,$title,$desc]):
    $dly = 'delay-'.($i+1);
    ?>
    <div class="step-card mb-12 reveal-left <?= $dly ?>">
      <div class="step-num"><?= $num ?></div>
      <div>
        <h3 class="heading-sm mb-8"><?= $title ?></h3>
        <p class="text-muted" style="font-size:14px;line-height:1.75;"><?= $desc ?></p>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<?php
$latestReviews = [];
try {
    $latestReviews = $pdo->query("
        SELECT r.rating, r.description, r.created_at, r.review_photo,
               u.name as user_name, u.avatar, u.profile_photo,
               p.title as project_title
        FROM reviews r
        JOIN users u ON u.id = r.user_id
        LEFT JOIN projects p ON p.id = r.project_id
        WHERE r.description IS NOT NULL AND TRIM(r.description) != ''
        ORDER BY r.created_at DESC
        LIMIT 6
    ")->fetchAll();
} catch (PDOException $e) {
    // Fallback: review_photo column may not exist yet
    $latestReviews = $pdo->query("
        SELECT r.rating, r.description, r.created_at, '' as review_photo,
               u.name as user_name, u.avatar, u.profile_photo,
               p.title as project_title
        FROM reviews r
        JOIN users u ON u.id = r.user_id
        LEFT JOIN projects p ON p.id = r.project_id
        WHERE r.description IS NOT NULL AND TRIM(r.description) != ''
        ORDER BY r.created_at DESC
        LIMIT 6
    ")->fetchAll();
}
?>

<?php if ($latestReviews): ?>
<section class="section" style="background:rgba(255,255,255,.015);border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
  <div class="container">
    <div class="text-center mb-32 reveal">
      <h2 class="heading-lg mb-12">What Students <span class="text-green grad-text">Say</span></h2>
      <p class="text-muted">Real feedback from real users</p>

      <?php
        $totalReviews = (int)$pdo->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
        $avgRating    = round((float)$pdo->query("SELECT AVG(rating) FROM reviews")->fetchColumn(), 1);
        $starFull     = floor($avgRating);
        $starHalf     = ($avgRating - $starFull) >= 0.5;
      ?>
      <div style="display:inline-flex;align-items:center;gap:10px;margin-top:16px;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:40px;padding:10px 24px;">
        <span style="font-size:20px;color:#f59e0b;letter-spacing:2px;">
          <?= str_repeat('★', $starFull) ?><?= $starHalf ? '½' : '' ?><?= str_repeat('☆', 5 - $starFull - ($starHalf?1:0)) ?>
        </span>
        <span style="font-size:15px;font-weight:700;color:#fef3c7;"><?= $avgRating ?></span>
        <span style="color:var(--muted);font-size:13px;">/ 5 · <?= $totalReviews ?> review<?= $totalReviews!=1?'s':'' ?></span>
      </div>
    </div>

    <div class="grid-2">
      <?php foreach ($latestReviews as $rvi => $rv): $rdly='delay-'.min($rvi+1,6);
        $ratingColors = ['','#ef4444','#f97316','#eab308','#22c55e','#10b981'];
        $col = $ratingColors[$rv['rating']] ?? '#10b981';
        $stars = str_repeat('★', (int)$rv['rating']) . str_repeat('☆', 5 - (int)$rv['rating']);
        $desc = strip_tags((string)($rv['description'] ?? ''));
        $shortDesc = mb_strlen($desc) > 140 ? mb_substr($desc, 0, 137) . '…' : $desc;
      ?>
      <div class="card card-hover reveal <?= $rdly ?>" style="border-left:3px solid <?= $col ?>;position:relative;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <span style="color:<?= $col ?>;font-size:16px;letter-spacing:1px;"><?= $stars ?></span>
          <span style="font-size:11px;color:var(--muted);"><?= date('d M Y', strtotime($rv['created_at'])) ?></span>
        </div>
        <p style="font-size:14px;color:#cbd5e1;line-height:1.75;margin-bottom:16px;font-style:italic;">
          "<?= e($shortDesc) ?>"
        </p>
        <div style="display:flex;align-items:center;gap:10px;border-top:1px solid rgba(255,255,255,.06);padding-top:12px;">
          <?php
            // Determine which photo to show: review_photo first, then profile_photo, then initials
            $displayPhoto = !empty($rv['review_photo']) ? $rv['review_photo'] : (!empty($rv['profile_photo']) ? $rv['profile_photo'] : '');
          ?>
          <?php if ($displayPhoto): ?>
          <img src="/devloom/uploads/avatars/<?= e(basename($displayPhoto)) ?>"
               alt="<?= e($rv['user_name']) ?>"
               style="width:34px;height:34px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid rgba(16,185,129,.3);">
          <?php else: ?>
          <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#10b981,#14b8a6);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;flex-shrink:0;">
            <?= e($rv['avatar']) ?>
          </div>
          <?php endif; ?>
          <div>
            <div style="font-size:13px;font-weight:600;color:#f1f5f9;"><?= e($rv['user_name']) ?></div>
            <?php if ($rv['project_title']): ?>
            <div style="font-size:11px;color:var(--muted);"><?= e($rv['project_title']) ?></div>
            <?php endif; ?>
          </div>
          <div style="margin-left:auto;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:20px;padding:3px 10px;font-size:12px;font-weight:700;color:<?= $col ?>;">
            <?= $rv['rating'] ?>/5
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ── CTA ── -->
<section class="section" style="padding-top:0;">
  <div class="container-sm">
    <div class="card text-center cta-glow reveal" style="padding:56px 48px;background:linear-gradient(135deg,rgba(16,185,129,.08),rgba(20,184,166,.04));border-color:rgba(16,185,129,.25);">
      <h2 class="heading-lg mb-16">Start Learning <span class="grad-text">Today</span></h2>
      <p class="text-muted mb-24" style="font-size:16px;line-height:1.8;">
        Free tools for every CS student — flash cards, placement prep, resume builder, viva practice and more.
      </p>
      <a href="/devloom/auth.php" class="btn btn-primary" style="padding:14px 44px;font-size:16px;">
        Create Free Account →
      </a>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
