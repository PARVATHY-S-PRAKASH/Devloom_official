<?php
/**
 * auth_question.php — Returns the security question for a given username (JSON).
 * Called by the Forgot Password tab via fetch().
 */
require_once __DIR__ . '/config/db.php';

header('Content-Type: application/json');

if (isLoggedIn()) {
    echo json_encode(['error' => 'Already logged in.']);
    exit;
}

$username = strtolower(trim($_GET['u'] ?? ''));

if (!$username || strlen($username) < 3) {
    echo json_encode(['error' => 'Username too short.']);
    exit;
}

try {
    // Check columns exist
    $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('security_question', $cols) || !in_array('security_answer', $cols)) {
        echo json_encode(['error' => 'Security questions not set up. Contact the administrator.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT security_question, security_answer FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $row = $stmt->fetch();

    if (!$row) {
        echo json_encode(['error' => 'No account found with that username.']);
        exit;
    }
    if (empty($row['security_question']) || empty($row['security_answer'])) {
        echo json_encode(['error' => 'No security question set for this account. Contact the administrator.']);
        exit;
    }

    echo json_encode(['question' => $row['security_question']]);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error.']);
}
