<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Flash Cards';
$activePage = 'features';
include __DIR__ . '/includes/header.php';
?>
<style>
.fc-wrap{max-width:860px;margin:0 auto;padding:32px 0 72px;}
.fc-header{margin-bottom:28px;}
.fc-header h1{font-size:1.7rem;font-weight:900;color:#f1f5f9;margin:0 0 4px;}
.fc-header p{color:#64748b;font-size:14px;margin:0;}

/* Deck selector */
.deck-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;margin-bottom:32px;}
.deck-btn{background:rgba(255,255,255,.03);border:1.5px solid rgba(255,255,255,.08);border-radius:14px;padding:18px 14px;cursor:pointer;text-align:left;transition:all .2s;display:flex;flex-direction:column;gap:6px;}
.deck-btn:hover{border-color:rgba(16,185,129,.35);background:rgba(16,185,129,.05);}
.deck-btn.selected{border-color:#10b981;background:rgba(16,185,129,.08);}
.deck-icon{font-size:1.9rem;line-height:1;}
.deck-name{font-size:13px;font-weight:700;color:#e2e8f0;}
.deck-count{font-size:11px;color:#64748b;}

/* Card area */
#card-area{display:none;}
#card-area.active{display:block;}
.fc-controls{display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap;}
.fc-progress-wrap{flex:1;min-width:140px;background:rgba(255,255,255,.06);border-radius:99px;height:6px;overflow:hidden;}
.fc-progress-fill{height:100%;background:linear-gradient(90deg,#10b981,#14b8a6);border-radius:99px;transition:width .4s ease;}
.fc-count{font-size:13px;color:#64748b;white-space:nowrap;font-family:monospace;}

/* The card itself */
.flip-scene{width:100%;height:240px;perspective:1000px;cursor:pointer;margin-bottom:20px;}
.flip-card{width:100%;height:100%;position:relative;transform-style:preserve-3d;transition:transform .5s cubic-bezier(.4,.2,.2,1);}
.flip-card.flipped{transform:rotateY(180deg);}
.flip-face{position:absolute;inset:0;border-radius:18px;backface-visibility:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 36px;text-align:center;gap:12px;}
.flip-front{background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.1);}
.flip-back{background:rgba(16,185,129,.07);border:1.5px solid rgba(16,185,129,.25);transform:rotateY(180deg);}
.flip-label{font-size:10px;font-family:monospace;text-transform:uppercase;letter-spacing:.12em;opacity:.45;margin-bottom:4px;}
.flip-text{font-size:1.15rem;font-weight:700;color:#f1f5f9;line-height:1.55;}
.flip-back .flip-text{color:#6ee7b7;font-size:1rem;}
.flip-hint{font-size:11px;color:#4b5563;margin-top:6px;}

/* Nav buttons */
.card-nav{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;}
.cn-btn{padding:10px 24px;border-radius:10px;border:1.5px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:#94a3b8;font-size:14px;font-weight:700;cursor:pointer;transition:all .2s;}
.cn-btn:hover:not(:disabled){background:rgba(255,255,255,.08);color:#f1f5f9;}
.cn-btn:disabled{opacity:.3;cursor:not-allowed;}
.cn-know{border-color:rgba(16,185,129,.3);color:#10b981;}
.cn-know:hover:not(:disabled){background:rgba(16,185,129,.1)!important;color:#10b981!important;}
.cn-skip{border-color:rgba(248,113,113,.3);color:#f87171;}
.cn-skip:hover:not(:disabled){background:rgba(248,113,113,.1)!important;color:#f87171!important;}

/* Score screen */
#score-screen{display:none;text-align:center;padding:48px 24px;}
#score-screen.active{display:block;}
.score-ring{display:inline-flex;align-items:center;justify-content:center;width:120px;height:120px;border-radius:50%;border:4px solid #10b981;font-size:2.4rem;font-weight:900;color:#10b981;margin-bottom:20px;}
.score-breakdown{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;margin:20px 0;}
.sc-pill{padding:8px 20px;border-radius:10px;font-size:14px;font-weight:700;}

/* Custom deck builder */
.builder-section{margin-top:36px;border-top:1px solid rgba(255,255,255,.07);padding-top:28px;}
.builder-section h2{font-size:1rem;font-weight:800;color:#94a3b8;margin:0 0 16px;font-family:monospace;text-transform:uppercase;letter-spacing:.08em;}
.card-entry{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:14px;margin-bottom:10px;display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:center;}
.card-entry input{background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:8px 12px;color:#e2e8f0;font-size:13px;width:100%;outline:none;box-sizing:border-box;}
.card-entry input:focus{border-color:rgba(16,185,129,.4);}
.rm-btn{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.2);color:#f87171;border-radius:8px;padding:7px 11px;cursor:pointer;font-size:13px;transition:all .2s;white-space:nowrap;}
.rm-btn:hover{background:rgba(248,113,113,.2);}
</style>

<div class="container">
<div class="fc-wrap">

  <div class="fc-header">
    <h1>🃏 Flash Cards</h1>
    <p>Pick a deck to study, flip cards to reveal answers, and track what you know.</p>
  </div>

  <!-- Deck picker -->
  <div id="deck-picker">
    <p style="font-size:12px;font-family:monospace;text-transform:uppercase;letter-spacing:.1em;color:#4b5563;margin-bottom:12px;">— Choose a Deck —</p>
    <div class="deck-grid" id="deck-grid"></div>
    <div style="text-align:center;margin-top:4px;">
      <button class="btn btn-outline" onclick="startCustom()" style="font-size:13px;">+ Build Custom Deck</button>
    </div>
  </div>

  <!-- Card study area -->
  <div id="card-area">
    <div class="fc-controls">
      <button class="btn btn-ghost btn-sm" onclick="backToDecks()">← Decks</button>
      <div class="fc-progress-wrap"><div class="fc-progress-fill" id="fc-prog" style="width:0%"></div></div>
      <span class="fc-count" id="fc-count">0 / 0</span>
      <button class="btn btn-ghost btn-sm" onclick="shuffleDeck()">🔀 Shuffle</button>
    </div>

    <div class="flip-scene" id="flip-scene" onclick="flipCard()">
      <div class="flip-card" id="flip-card">
        <div class="flip-face flip-front">
          <div class="flip-label">Question</div>
          <div class="flip-text" id="card-q">…</div>
          <div class="flip-hint">Tap to reveal answer</div>
        </div>
        <div class="flip-face flip-back">
          <div class="flip-label">Answer</div>
          <div class="flip-text" id="card-a">…</div>
        </div>
      </div>
    </div>

    <div class="card-nav">
      <button class="cn-btn cn-skip"  id="btn-skip"  onclick="markCard(false)">✗ Still Learning</button>
      <button class="cn-btn"          id="btn-flip2" onclick="flipCard()">↩ Flip</button>
      <button class="cn-btn cn-know"  id="btn-know"  onclick="markCard(true)">✓ Got It</button>
    </div>
  </div>

  <!-- Score screen -->
  <div id="score-screen">
    <div class="score-ring" id="score-pct">0%</div>
    <h2 class="heading-md mb-8" id="score-title">Round Complete!</h2>
    <p class="text-muted mb-16" id="score-sub"></p>
    <div class="score-breakdown">
      <span class="sc-pill" style="background:rgba(16,185,129,.1);color:#10b981;" id="sc-know">0 Got It</span>
      <span class="sc-pill" style="background:rgba(248,113,113,.1);color:#f87171;" id="sc-skip">0 Still Learning</span>
    </div>
    <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
      <button class="btn btn-primary" onclick="restartDeck()">↩ Retry Wrong</button>
      <button class="btn btn-outline" onclick="backToDecks()">Choose Another Deck</button>
    </div>
  </div>

  <!-- Custom deck builder -->
  <div class="builder-section" id="custom-builder" style="display:none;">
    <h2>🛠 Custom Deck Builder</h2>
    <div id="entry-list">
      <div class="card-entry">
        <input placeholder="Question / Term" class="q-inp">
        <input placeholder="Answer / Definition" class="a-inp">
        <button class="rm-btn" onclick="removeEntry(this)">✕</button>
      </div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;">
      <button class="btn btn-ghost btn-sm" onclick="addEntry()">+ Add Card</button>
      <button class="btn btn-primary btn-sm" onclick="launchCustom()">▶ Study This Deck</button>
    </div>
  </div>

</div>
</div>

<script>
// ── Built-in decks ──────────────────────────────────────────────────
const DECKS = [
  {
    id:'python', icon:'🐍', name:'Python Basics', color:'#10b981',
    cards:[
      {q:'What does `len()` return?',          a:'The number of items in a sequence (string, list, tuple, etc.)'},
      {q:'How do you declare a list in Python?',a:"Using square brackets: my_list = [1, 2, 3]"},
      {q:'What is a dictionary in Python?',     a:'An unordered key-value store: { "key": "value" }'},
      {q:'Difference between `==` and `is`?',  a:'`==` compares values; `is` compares object identity (memory address)'},
      {q:'What is a lambda function?',          a:'An anonymous one-line function: lambda x: x * 2'},
      {q:'What does `range(5)` produce?',       a:'Numbers 0, 1, 2, 3, 4 — stops before 5'},
      {q:'How do you open a file safely?',      a:"with open('file.txt', 'r') as f: — closes automatically"},
      {q:'What is list comprehension?',         a:'Concise way to create lists: [x**2 for x in range(5)]'},
      {q:'What does `*args` do?',               a:'Allows a function to accept any number of positional arguments as a tuple'},
      {q:'How to handle exceptions in Python?', a:'try: ... except ExceptionType as e: ... finally: ...'},
    ]
  },
  {
    id:'dsa', icon:'📊', name:'DSA Concepts', color:'#818cf8',
    cards:[
      {q:'Time complexity of binary search?',         a:'O(log n) — halves the search space each step'},
      {q:'What is a stack?',                          a:'LIFO (Last In, First Out) data structure. Operations: push, pop, peek'},
      {q:'What is a queue?',                          a:'FIFO (First In, First Out). Operations: enqueue, dequeue'},
      {q:'Worst-case time for bubble sort?',          a:'O(n²) — compares all pairs in nested loops'},
      {q:'What is a hash table?',                     a:'Key-value store using a hash function for O(1) avg lookup'},
      {q:'Difference between BFS and DFS?',          a:'BFS explores level by level (uses queue); DFS goes deep first (uses stack/recursion)'},
      {q:'What is dynamic programming?',              a:'Solving complex problems by breaking into overlapping subproblems and caching results'},
      {q:'Space complexity of merge sort?',           a:'O(n) — needs auxiliary space for merging'},
      {q:'What is a linked list?',                    a:'Sequence of nodes where each node holds data and a pointer to the next node'},
      {q:'What does O(1) mean?',                      a:'Constant time — execution time does not depend on input size'},
    ]
  },
  {
    id:'dbms', icon:'🗄️', name:'DBMS & SQL', color:'#38bdf8',
    cards:[
      {q:'What is a primary key?',                    a:'A column (or set) that uniquely identifies each row; cannot be NULL'},
      {q:'Difference between WHERE and HAVING?',      a:'WHERE filters rows before grouping; HAVING filters groups after GROUP BY'},
      {q:'What is normalization?',                    a:'Organizing tables to reduce redundancy. 1NF→2NF→3NF→BCNF'},
      {q:'What is an INNER JOIN?',                    a:'Returns rows where there is a match in BOTH tables'},
      {q:'What is a foreign key?',                    a:'A column that references the primary key of another table'},
      {q:'Difference between DELETE and TRUNCATE?',   a:'DELETE removes specific rows (can rollback); TRUNCATE removes all rows fast (DDL, no rollback)'},
      {q:'What is an index in a database?',           a:'A data structure (like B-tree) that speeds up SELECT queries at the cost of insert/update speed'},
      {q:'What is ACID in transactions?',             a:'Atomicity, Consistency, Isolation, Durability — properties of reliable transactions'},
      {q:'What is a VIEW?',                           a:'A stored query that behaves like a virtual table; does not store data'},
      {q:'What does GROUP BY do?',                    a:'Aggregates rows with the same column values — used with COUNT, SUM, AVG, MAX, MIN'},
    ]
  },
  {
    id:'os', icon:'⚙️', name:'Operating Systems', color:'#f59e0b',
    cards:[
      {q:'What is a process vs a thread?',            a:'Process = independent program with own memory. Thread = lightweight sub-unit inside a process sharing memory'},
      {q:'What is deadlock?',                         a:'Two or more processes waiting on each other's resources, creating a circular wait'},
      {q:'What is virtual memory?',                   a:'Technique that lets programs use more memory than physically available by using disk as extension'},
      {q:'What is paging?',                           a:'Dividing memory into fixed-size pages; maps virtual to physical addresses via page table'},
      {q:'What is a semaphore?',                      a:'Synchronization tool — integer variable used to control access to shared resources (binary or counting)'},
      {q:'What is CPU scheduling?',                   a:'OS decides which process runs next. Algorithms: FCFS, SJF, Round Robin, Priority'},
      {q:'What is context switching?',                a:'Saving state of one process and loading another — allows multitasking, but has overhead'},
      {q:'What is thrashing?',                        a:'Excessive paging where CPU spends more time swapping pages than executing processes'},
      {q:'What is a system call?',                    a:'Interface between user programs and the OS kernel (e.g. read(), write(), fork())'},
      {q:'What is a mutex?',                          a:'Mutual exclusion lock — ensures only one thread enters critical section at a time'},
    ]
  },
  {
    id:'cn', icon:'🌐', name:'Computer Networks', color:'#34d399',
    cards:[
      {q:'What is the OSI model?',                   a:'7 layers: Physical, Data Link, Network, Transport, Session, Presentation, Application'},
      {q:'Difference between TCP and UDP?',          a:'TCP: reliable, ordered, connection-based. UDP: fast, connectionless, no guaranteed delivery'},
      {q:'What is an IP address?',                   a:'Numeric identifier for a device on a network (IPv4: 32-bit; IPv6: 128-bit)'},
      {q:'What does DNS do?',                        a:'Translates domain names (google.com) to IP addresses'},
      {q:'What is a subnet mask?',                   a:'Determines which portion of an IP is the network vs host address'},
      {q:'What is HTTP vs HTTPS?',                   a:'HTTPS is HTTP encrypted with TLS/SSL — secures data in transit'},
      {q:'What is a MAC address?',                   a:'Hardware address of a network interface card — 48-bit, unique per device'},
      {q:'What is NAT?',                             a:'Network Address Translation — maps multiple private IPs to one public IP'},
      {q:'What is a router vs a switch?',            a:'Router connects different networks (Layer 3); Switch connects devices within same network (Layer 2)'},
      {q:'What is the 3-way TCP handshake?',         a:'SYN → SYN-ACK → ACK — establishes a reliable connection before data transfer'},
    ]
  },
  {
    id:'aptitude', icon:'🧮', name:'Aptitude', color:'#fb923c',
    cards:[
      {q:'If 12 men can do a job in 8 days, how long for 16 men?',      a:'6 days (inverse proportion: 12×8 = 16×d → d = 6)'},
      {q:'Simple interest formula?',                                     a:'SI = (P × R × T) / 100'},
      {q:'What is 15% of 240?',                                          a:'36 (240 × 0.15 = 36)'},
      {q:'A train 300m long passes a pole in 30s. Speed?',              a:'10 m/s = 36 km/h'},
      {q:'If A:B = 3:4 and B:C = 2:3, what is A:B:C?',                 a:'6:8:12 → simplified 3:4:6'},
      {q:'LCM of 12 and 18?',                                           a:'36 (2²×3² = 36)'},
      {q:'Compound interest formula?',                                   a:'A = P(1 + R/100)^T; CI = A − P'},
      {q:'Probability: P(A or B)?',                                     a:'P(A) + P(B) − P(A∩B)'},
      {q:'Profit % formula?',                                           a:'Profit% = (Profit / CP) × 100'},
      {q:'Pipes A fills in 6h, B fills in 12h. Together?',              a:'4h: 1/6 + 1/12 = 2/12 + 1/12 = 3/12 = 1/4 → 4 hours'},
    ]
  },
];

let currentDeck = [];
let currentIdx  = 0;
let knownSet    = new Set();
let skippedSet  = new Set();
let isFlipped   = false;
let wrongCards  = [];
let deckTitle   = '';

// ── Build deck picker ───────────────────────────────────────────────
function buildDeckGrid(){
  const g = document.getElementById('deck-grid');
  g.innerHTML = '';
  DECKS.forEach(d => {
    const b = document.createElement('button');
    b.className = 'deck-btn';
    b.innerHTML = `<span class="deck-icon">${d.icon}</span><span class="deck-name">${d.name}</span><span class="deck-count">${d.cards.length} cards</span>`;
    b.style.borderTopColor = d.color;
    b.onclick = () => launchDeck(d.cards, d.name);
    g.appendChild(b);
  });
}

function launchDeck(cards, title){
  currentDeck = [...cards];
  deckTitle   = title;
  knownSet.clear(); skippedSet.clear();
  currentIdx = 0; isFlipped = false;
  document.getElementById('deck-picker').style.display = 'none';
  document.getElementById('custom-builder').style.display = 'none';
  document.getElementById('score-screen').classList.remove('active');
  document.getElementById('card-area').classList.add('active');
  showCard();
}

function backToDecks(){
  document.getElementById('deck-picker').style.display = 'block';
  document.getElementById('card-area').classList.remove('active');
  document.getElementById('score-screen').classList.remove('active');
}

function showCard(){
  if(currentIdx >= currentDeck.length){ showScore(); return; }
  const c = currentDeck[currentIdx];
  document.getElementById('card-q').textContent = c.q;
  document.getElementById('card-a').textContent = c.a;
  const fc = document.getElementById('flip-card');
  fc.classList.remove('flipped');
  isFlipped = false;
  updateProgress();
}

function flipCard(){
  isFlipped = !isFlipped;
  document.getElementById('flip-card').classList.toggle('flipped', isFlipped);
}

function markCard(known){
  if(known) knownSet.add(currentIdx);
  else       skippedSet.add(currentIdx);
  currentIdx++;
  showCard();
}

function updateProgress(){
  const total = currentDeck.length;
  const done  = currentIdx;
  const pct   = total ? Math.round(done/total*100) : 0;
  document.getElementById('fc-prog').style.width = pct + '%';
  document.getElementById('fc-count').textContent = `${done} / ${total}`;
}

function shuffleDeck(){
  for(let i = currentDeck.length-1; i > 0; i--){
    const j = Math.floor(Math.random()*(i+1));
    [currentDeck[i],currentDeck[j]] = [currentDeck[j],currentDeck[i]];
  }
  knownSet.clear(); skippedSet.clear(); currentIdx = 0; isFlipped = false;
  showCard();
}

function showScore(){
  const total  = currentDeck.length;
  const known  = knownSet.size;
  const pct    = total ? Math.round(known/total*100) : 0;
  wrongCards   = currentDeck.filter((_,i) => skippedSet.has(i));

  document.getElementById('card-area').classList.remove('active');
  const ss = document.getElementById('score-screen');
  ss.classList.add('active');
  document.getElementById('score-pct').textContent  = pct + '%';
  document.getElementById('score-title').textContent = pct === 100 ? '🎉 Perfect Score!' : pct >= 70 ? '✨ Great Work!' : 'Keep Practising!';
  document.getElementById('score-sub').textContent   = `You got ${known} of ${total} cards correct in "${deckTitle}".`;
  document.getElementById('sc-know').textContent     = `${known} Got It`;
  document.getElementById('sc-skip').textContent     = `${total - known} Still Learning`;
}

function restartDeck(){
  if(!wrongCards.length){ backToDecks(); return; }
  launchDeck(wrongCards, deckTitle + ' (Wrong Only)');
}

// ── Custom deck builder ─────────────────────────────────────────────
function startCustom(){
  const el = document.getElementById('custom-builder');
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
  if(el.style.display === 'block') el.scrollIntoView({behavior:'smooth'});
}

function addEntry(){
  const list = document.getElementById('entry-list');
  const div  = document.createElement('div');
  div.className = 'card-entry';
  div.innerHTML = '<input placeholder="Question / Term" class="q-inp"><input placeholder="Answer / Definition" class="a-inp"><button class="rm-btn" onclick="removeEntry(this)">✕</button>';
  list.appendChild(div);
}

function removeEntry(btn){
  const entries = document.querySelectorAll('.card-entry');
  if(entries.length <= 1){ alert('Need at least one card.'); return; }
  btn.closest('.card-entry').remove();
}

function launchCustom(){
  const cards = [];
  document.querySelectorAll('.card-entry').forEach(row => {
    const q = row.querySelector('.q-inp').value.trim();
    const a = row.querySelector('.a-inp').value.trim();
    if(q && a) cards.push({q, a});
  });
  if(cards.length < 2){ alert('Add at least 2 complete cards.'); return; }
  launchDeck(cards, 'Custom Deck');
}

buildDeckGrid();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
