<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Online IDE';
$activePage = 'features';
include __DIR__ . '/includes/header.php';
?>
<style>
.ide-wrap{max-width:1140px;margin:0 auto;padding:24px 0 60px;}
.ide-header{margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;}
.ide-header h1{font-size:1.6rem;font-weight:900;color:#f1f5f9;margin:0;}
.ide-layout{display:grid;grid-template-columns:1fr 380px;gap:16px;align-items:start;}
@media(max-width:900px){.ide-layout{grid-template-columns:1fr;}}
/* Editor panel */
.editor-panel{background:#0d1117;border:1px solid rgba(255,255,255,.1);border-radius:14px;overflow:hidden;}
.editor-topbar{display:flex;align-items:center;gap:8px;padding:10px 14px;background:rgba(0,0,0,.3);border-bottom:1px solid rgba(255,255,255,.08);flex-wrap:wrap;}
.lang-pill{padding:5px 12px;border-radius:20px;border:1.5px solid rgba(255,255,255,.12);background:transparent;color:#94a3b8;font-size:12px;font-weight:700;cursor:pointer;transition:all .18s;}
.lang-pill.active{border-color:#10b981;background:rgba(16,185,129,.12);color:#10b981;}
#code-editor{width:100%;min-height:340px;background:#0d1117;color:#e6edf3;font-family:'Courier New',Courier,monospace;font-size:13.5px;border:none;padding:16px;resize:vertical;outline:none;line-height:1.65;box-sizing:border-box;tab-size:2;}
.editor-actions{display:flex;gap:8px;padding:10px 14px;background:rgba(0,0,0,.2);border-top:1px solid rgba(255,255,255,.07);flex-wrap:wrap;align-items:center;}
/* Output */
.output-panel{background:#0a0f1a;border-top:1px solid rgba(255,255,255,.07);padding:14px 16px;min-height:100px;font-family:'Courier New',monospace;font-size:12.5px;color:#94a3b8;white-space:pre-wrap;word-break:break-all;max-height:220px;overflow-y:auto;}
.output-panel .ok{color:#6ee7b7;} .output-panel .err{color:#f87171;} .output-panel .warn{color:#fbbf24;}
/* Right panel */
.right-panel{display:flex;flex-direction:column;gap:14px;}
.rp-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:14px;overflow:hidden;}
.rp-title{font-size:12px;font-weight:700;font-family:monospace;text-transform:uppercase;letter-spacing:.08em;color:#64748b;padding:11px 14px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;gap:6px;}
.rp-body{padding:14px;}
.ai-output{font-size:13px;color:#cbd5e1;line-height:1.7;min-height:60px;}
.ai-output .loading{display:flex;align-items:center;gap:8px;color:#64748b;}
.dot{display:inline-block;width:5px;height:5px;border-radius:50%;background:#818cf8;margin:0 2px;animation:blink 1.2s infinite;}
.dot:nth-child(2){animation-delay:.2s;}.dot:nth-child(3){animation-delay:.4s;}
@keyframes blink{0%,80%,100%{opacity:.2}40%{opacity:1}}
/* Snippets */
.snippet-row{display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap;}
.snip-btn{padding:5px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.09);background:rgba(255,255,255,.04);color:#94a3b8;font-size:11px;cursor:pointer;transition:all .18s;font-family:monospace;}
.snip-btn:hover{border-color:rgba(16,185,129,.4);color:#10b981;}
/* Error highlights */
.err-line{background:rgba(239,68,68,.15);border-left:3px solid #ef4444;}
/* Tab stops in textarea */
#code-editor{tab-size:4;}
</style>

<div class="container">
<div class="ide-wrap">
  <div class="ide-header">
    <h1>💻 Online IDE</h1>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
      <span style="font-size:12px;color:#64748b;">Write → Run → Debug → Explain</span>
    </div>
  </div>

  <div class="ide-layout">
    <!-- LEFT: Code Editor -->
    <div>
      <div class="editor-panel">
        <div class="editor-topbar">
          <span style="font-size:11px;color:#64748b;font-family:monospace;margin-right:4px;">LANGUAGE:</span>
          <button class="lang-pill active" onclick="setLang('python',this)">🐍 Python</button>
          <button class="lang-pill" onclick="setLang('javascript',this)">🟡 JavaScript</button>
          <button class="lang-pill" onclick="setLang('java',this)">☕ Java</button>
          <button class="lang-pill" onclick="setLang('c',this)">⚙ C</button>
          <button class="lang-pill" onclick="setLang('cpp',this)">⚙ C++</button>
          <button class="lang-pill" onclick="setLang('sql',this)">🗄 SQL</button>
        </div>
        <div style="position:relative;">
          <textarea id="code-editor" spellcheck="false" onkeydown="handleTab(event)" placeholder="// Write your code here…"></textarea>
        </div>
        <div style="display:flex;gap:6px;padding:8px 14px;background:rgba(0,0,0,.15);border-top:1px solid rgba(255,255,255,.05);flex-wrap:wrap;">
          <span style="font-size:11px;color:#475569;">Quick snippets:</span>
          <div id="snippet-row" class="snippet-row" style="margin:0;"></div>
        </div>
        <div class="editor-actions">
          <button class="btn btn-primary" onclick="runCode()" id="run-btn" style="padding:9px 20px;font-size:13px;">
            ▶ Run Code
          </button>
          <button class="btn btn-ghost btn-sm" onclick="debugCode()">🐛 Debug</button>
          <button class="btn btn-ghost btn-sm" onclick="explainCode()">💡 Explain</button>
          <button class="btn btn-ghost btn-sm" onclick="optimizeCode()">⚡ Optimize</button>
          <button class="btn btn-ghost btn-sm" onclick="clearEditor()" style="margin-left:auto;color:#475569;">🗑 Clear</button>
        </div>
        <div id="output-label" style="font-size:11px;font-family:monospace;color:#475569;padding:8px 16px 4px;display:none;">OUTPUT:</div>
        <div class="output-panel" id="output-panel" style="display:none;"></div>
      </div>
    </div>

    <!-- RIGHT: AI Assistant panels -->
    <div class="right-panel">

      <!-- Explain / Debug output -->
      <div class="rp-card">
        <div class="rp-title" id="ai-panel-title">💡 AI Assistant</div>
        <div class="rp-body">
          <div class="ai-output" id="ai-output">
            <span style="color:#475569;font-size:12px;">Click Explain, Debug, or Optimize to get AI analysis of your code.</span>
          </div>
        </div>
      </div>

      <!-- Complexity -->
      <div class="rp-card">
        <div class="rp-title">📊 Complexity Analysis</div>
        <div class="rp-body">
          <div id="complexity-output" style="font-size:13px;color:#cbd5e1;line-height:1.7;">
            <span style="color:#475569;font-size:12px;">Run Debug or Explain to see time & space complexity.</span>
          </div>
        </div>
      </div>

      <!-- Anthropic API Key for AI features -->
      <div class="rp-card" style="border:1px solid rgba(16,185,129,.25);background:rgba(16,185,129,.04);">
        <div class="rp-title" style="color:#10b981;">🤖 Anthropic API Key (for AI features)</div>
        <div class="rp-body">
          <input id="anthropic-key" type="password"
            style="width:100%;background:rgba(0,0,0,.25);border:1px solid rgba(16,185,129,.3);border-radius:8px;color:#e2e8f0;font-size:12px;font-family:monospace;padding:8px 10px;outline:none;box-sizing:border-box;"
            placeholder="sk-ant-…">
          <p style="font-size:11px;color:#94a3b8;margin:6px 0 0;">
            Required for <strong>Run (AI sim)</strong>, Debug, Explain, and Complexity features.
            Get your key at <a href="https://console.anthropic.com/keys" target="_blank" style="color:#10b981;">console.anthropic.com/keys</a>.
          </p>
          <p style="font-size:11px;color:#64748b;margin:4px 0 0;">Key is saved in your browser only and sent securely to your own server.</p>
        </div>
      </div>

      <!-- RapidAPI Key for Judge0 -->
      <div class="rp-card" style="border:1px solid rgba(245,158,11,.25);background:rgba(245,158,11,.04);">
        <div class="rp-title" style="color:#f59e0b;">🔑 Judge0 API Key (for Real Execution)</div>
        <div class="rp-body">
          <input id="rapidapi-key" type="password"
            style="width:100%;background:rgba(0,0,0,.25);border:1px solid rgba(245,158,11,.3);border-radius:8px;color:#e2e8f0;font-size:12px;font-family:monospace;padding:8px 10px;outline:none;box-sizing:border-box;"
            placeholder="Paste your RapidAPI key here…">
          <p style="font-size:11px;color:#94a3b8;margin:6px 0 0;">
            Get a <strong>free key</strong> at
            <a href="https://rapidapi.com/judge0-official/api/judge0-ce" target="_blank" style="color:#f59e0b;">rapidapi.com → Judge0 CE</a>
            (free tier: 50 runs/day). Without a key, runs are simulated by AI (no real compilation).
          </p>
          <p style="font-size:11px;color:#64748b;margin:4px 0 0;">Key is saved in your browser only.</p>
        </div>
      </div>

      <!-- Input for running -->
      <div class="rp-card">
        <div class="rp-title">⌨ Custom Input (stdin)</div>
        <div class="rp-body">
          <textarea id="stdin-input" style="width:100%;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.08);border-radius:8px;color:#e2e8f0;font-size:12px;font-family:monospace;padding:8px 10px;resize:vertical;outline:none;min-height:60px;box-sizing:border-box;" placeholder="Enter input values here (one per line)…"></textarea>
          <p style="font-size:11px;color:#475569;margin:4px 0 0;">This input is passed to your program when you click Run.</p>
        </div>
      </div>

    </div>
  </div>
</div>
</div>

<script>
var curLang = 'python';
var SNIPPETS = {
  python:[
    {l:'Hello World',c:'print("Hello, World!")'},
    {l:'For Loop',c:'for i in range(10):\n    print(i)'},
    {l:'Function',c:'def greet(name):\n    return f"Hello, {name}!"\n\nprint(greet("World"))'},
    {l:'List Comp',c:'squares = [x**2 for x in range(1, 11)]\nprint(squares)'},
    {l:'Class',c:'class Animal:\n    def __init__(self, name):\n        self.name = name\n    def speak(self):\n        return f"{self.name} speaks"\n\na = Animal("Dog")\nprint(a.speak())'},
    {l:'Fibonacci',c:'def fib(n):\n    a, b = 0, 1\n    for _ in range(n):\n        print(a, end=" ")\n        a, b = b, a+b\nfib(10)'},
  ],
  javascript:[
    {l:'Hello World',c:'console.log("Hello, World!");'},
    {l:'Arrow Fn',c:'const greet = (name) => `Hello, ${name}!`;\nconsole.log(greet("World"));'},
    {l:'For Loop',c:'for (let i = 0; i < 10; i++) {\n    console.log(i);\n}'},
    {l:'Array Map',c:'const nums = [1,2,3,4,5];\nconst squares = nums.map(x => x * x);\nconsole.log(squares);'},
    {l:'Promise',c:'const delay = ms => new Promise(r => setTimeout(r, ms));\nasync function main() {\n    await delay(100);\n    console.log("Done!");\n}\nmain();'},
  ],
  java:[
    {l:'Hello World',c:'public class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n    }\n}'},
    {l:'For Loop',c:'public class Main {\n    public static void main(String[] args) {\n        for (int i = 0; i < 10; i++) {\n            System.out.println(i);\n        }\n    }\n}'},
    {l:'Array',c:'public class Main {\n    public static void main(String[] args) {\n        int[] nums = {1, 2, 3, 4, 5};\n        for (int n : nums) System.out.println(n);\n    }\n}'},
    {l:'Class',c:'class Animal {\n    String name;\n    Animal(String name) { this.name = name; }\n    String speak() { return name + " speaks"; }\n    \n    public static void main(String[] args) {\n        Animal a = new Animal("Dog");\n        System.out.println(a.speak());\n    }\n}'},
  ],
  c:[
    {l:'Hello World',c:'#include <stdio.h>\nint main() {\n    printf("Hello, World!\\n");\n    return 0;\n}'},
    {l:'For Loop',c:'#include <stdio.h>\nint main() {\n    for (int i = 0; i < 10; i++) {\n        printf("%d\\n", i);\n    }\n    return 0;\n}'},
    {l:'Array',c:'#include <stdio.h>\nint main() {\n    int nums[] = {1, 2, 3, 4, 5};\n    int n = sizeof(nums)/sizeof(nums[0]);\n    for (int i = 0; i < n; i++)\n        printf("%d\\n", nums[i]);\n    return 0;\n}'},
    {l:'Function',c:'#include <stdio.h>\nint add(int a, int b) { return a + b; }\nint main() {\n    printf("Sum: %d\\n", add(3, 4));\n    return 0;\n}'},
  ],
  cpp:[
    {l:'Hello World',c:'#include <iostream>\nusing namespace std;\nint main() {\n    cout << "Hello, World!" << endl;\n    return 0;\n}'},
    {l:'Vector',c:'#include <iostream>\n#include <vector>\nusing namespace std;\nint main() {\n    vector<int> v = {1,2,3,4,5};\n    for (auto x : v) cout << x << " ";\n    return 0;\n}'},
    {l:'Class',c:'#include <iostream>\nusing namespace std;\nclass Animal {\npublic:\n    string name;\n    Animal(string n) : name(n) {}\n    string speak() { return name + " speaks"; }\n};\nint main() {\n    Animal a("Dog");\n    cout << a.speak() << endl;\n    return 0;\n}'},
  ],
  sql:[
    {l:'SELECT',c:'SELECT * FROM employees\nWHERE department = \'Engineering\'\nORDER BY salary DESC\nLIMIT 10;'},
    {l:'JOIN',c:'SELECT e.name, d.dept_name\nFROM employees e\nINNER JOIN departments d ON e.dept_id = d.id\nWHERE e.salary > 50000;'},
    {l:'GROUP BY',c:'SELECT department, COUNT(*) as count, AVG(salary) as avg_sal\nFROM employees\nGROUP BY department\nHAVING COUNT(*) > 5\nORDER BY avg_sal DESC;'},
    {l:'CREATE',c:'CREATE TABLE students (\n    id INT PRIMARY KEY AUTO_INCREMENT,\n    name VARCHAR(100) NOT NULL,\n    email VARCHAR(150) UNIQUE,\n    grade DECIMAL(4,2),\n    created_at DATETIME DEFAULT CURRENT_TIMESTAMP\n);'},
  ]
};
var TEMPLATES = {
  python:'# Python Code\n# Write your solution here\n\n',
  javascript:'// JavaScript Code\n// Write your solution here\n\n',
  java:'public class Main {\n    public static void main(String[] args) {\n        // Write your code here\n        \n    }\n}',
  c:'#include <stdio.h>\n\nint main() {\n    // Write your code here\n    \n    return 0;\n}',
  cpp:'#include <iostream>\nusing namespace std;\n\nint main() {\n    // Write your code here\n    \n    return 0;\n}',
  sql:'-- SQL Query\n-- Write your query here\n\n'
};

function setLang(lang, btn) {
  curLang = lang;
  document.querySelectorAll('.lang-pill').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  var editor = document.getElementById('code-editor');
  if(!editor.value.trim() || editor.value === TEMPLATES[curLang]) {
    editor.value = TEMPLATES[lang];
  }
  renderSnippets();
}

function renderSnippets() {
  var row = document.getElementById('snippet-row');
  if(!row) return;
  var snips = SNIPPETS[curLang] || [];
  row.innerHTML = '';
  snips.forEach(function(s) {
    var btn = document.createElement('button');
    btn.className = 'snip-btn';
    btn.textContent = s.l;
    btn.onclick = (function(code){ return function(){ insertSnippet(code); }; })(s.c);
    row.appendChild(btn);
  });
}

function insertSnippet(code) {
  document.getElementById('code-editor').value = code;
}

function handleTab(e) {
  if(e.key === 'Tab') {
    e.preventDefault();
    var ta = e.target;
    var start = ta.selectionStart, end = ta.selectionEnd;
    ta.value = ta.value.substring(0, start) + '    ' + ta.value.substring(end);
    ta.selectionStart = ta.selectionEnd = start + 4;
  }
}

function clearEditor() {
  document.getElementById('code-editor').value = TEMPLATES[curLang] || '';
  document.getElementById('output-panel').style.display = 'none';
  document.getElementById('output-label').style.display = 'none';
  document.getElementById('ai-output').innerHTML = '<span style="color:#475569;font-size:12px;">Click Explain, Debug, or Optimize to get AI analysis.</span>';
  document.getElementById('complexity-output').innerHTML = '<span style="color:#475569;font-size:12px;">Run Debug or Explain to see complexity.</span>';
}

function showOutput(html, isError) {
  var panel = document.getElementById('output-panel');
  var label = document.getElementById('output-label');
  panel.style.display = 'block';
  label.style.display = 'block';
  panel.innerHTML = html;
}

function showAI(html, title) {
  document.getElementById('ai-panel-title').innerHTML = title || '💡 AI Assistant';
  document.getElementById('ai-output').innerHTML = html;
}

function setLoading(id, msg) {
  document.getElementById(id).innerHTML = '<div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span> '+msg+'</div>';
}

// ── RUN CODE via Judge0 API (free tier) ──────────────────────
var JUDGE0_LANG = {python:71, javascript:63, java:62, c:50, cpp:54, sql:82};
var JUDGE0_URL = 'https://judge0-ce.p.rapidapi.com';

// Persist RapidAPI key in localStorage
(function(){
  var saved = localStorage.getItem('devloom_rapidapi_key');
  if(saved){var el=document.getElementById('rapidapi-key');if(el)el.value=saved;}
  var el=document.getElementById('rapidapi-key');
  if(el)el.addEventListener('input',function(){localStorage.setItem('devloom_rapidapi_key',el.value.trim());});

  // Persist Anthropic key in localStorage
  var savedAnt = localStorage.getItem('devloom_anthropic_key');
  if(savedAnt){var ea=document.getElementById('anthropic-key');if(ea)ea.value=savedAnt;}
  var ea=document.getElementById('anthropic-key');
  if(ea)ea.addEventListener('input',function(){localStorage.setItem('devloom_anthropic_key',ea.value.trim());});
})();

async function runCode() {
  var code = document.getElementById('code-editor').value.trim();
  if(!code) { showOutput('<span class="err">No code to run.</span>'); return; }
  var stdin = document.getElementById('stdin-input').value;
  var btn = document.getElementById('run-btn');
  btn.textContent = '⏳ Running…'; btn.disabled = true;
  showOutput('<span style="color:#475569;">⏳ Compiling and running…</span>');

  var rapidKey = (document.getElementById('rapidapi-key')||{}).value || localStorage.getItem('devloom_rapidapi_key') || '';

  if(!rapidKey || rapidKey === 'PASTE_YOUR_RAPIDAPI_KEY_HERE') {
    btn.textContent = '▶ Run Code'; btn.disabled = false;
    showOutput('<span style="color:#f59e0b;">⚠ No Judge0 API key set — using AI simulation instead.\nFor real code execution, paste your RapidAPI key in the panel on the right.</span>\n\n');
    runWithAI(code, stdin);
    return;
  }

  var langId = JUDGE0_LANG[curLang] || 71;
  try {
    // Submit
    var subRes = await fetch(JUDGE0_URL + '/submissions?base64_encoded=false&wait=true', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-RapidAPI-Key': rapidKey,
        'X-RapidAPI-Host': 'judge0-ce.p.rapidapi.com'
      },
      body: JSON.stringify({
        source_code: code,
        language_id: langId,
        stdin: stdin,
        cpu_time_limit: 5,
        memory_limit: 128000
      })
    });
    var result = await subRes.json();
    btn.textContent = '▶ Run Code'; btn.disabled = false;

    if(result.message && result.message.toLowerCase().includes('invalid') ){
      showOutput('<span class="err">❌ Invalid RapidAPI key. Please check your key in the panel on the right.</span>');
      return;
    }
    if(result.stdout) {
      showOutput('<span class="ok">'+escHtml(result.stdout)+'</span>');
    } else if(result.stderr) {
      showOutput('<span class="err">RUNTIME ERROR:\n'+escHtml(result.stderr)+'</span>');
    } else if(result.compile_output) {
      showOutput('<span class="err">COMPILE ERROR:\n'+escHtml(result.compile_output)+'</span>');
    } else if(result.status) {
      var s = result.status;
      if(s.id === 3) showOutput('<span class="ok">Program ran successfully (no output).</span>');
      else showOutput('<span class="warn">Status: '+s.description+'</span>');
    } else {
      showOutput('<span class="warn">Unexpected response — falling back to AI simulation.</span>\n\n');
      runWithAI(code, stdin);
    }
  } catch(e) {
    btn.textContent = '▶ Run Code'; btn.disabled = false;
    // Fallback: use AI to simulate execution
    showOutput('<span style="color:#f59e0b;">⚠ Judge0 request failed — using AI simulation.\n</span>\n');
    runWithAI(code, stdin);
  }
}

async function runWithAI(code, stdin) {
  setLoading('output-panel','Simulating execution…');
  var stdinNote = stdin ? '\n\nStdin input:\n'+stdin : '';
  var result = await callProxy(
    'You are a code execution simulator. Execute this '+curLang+' code mentally and show EXACTLY what the output would be. Show only the program output, nothing else. If there are errors, show them as a compiler/runtime would.'+stdinNote,
    [{role:'user',content:'Execute this code:\n```'+curLang+'\n'+code+'\n```'}]
  );
  if(result==='__NO_API_KEY__') {
    showOutput('<span style="color:#fbbf24;">⚠ No Anthropic API key set.\nPaste your sk-ant-… key in the 🤖 API Key panel on the right to use AI simulation.</span>');
    var btn=document.getElementById('run-btn');if(btn){btn.textContent='▶ Run Code';btn.disabled=false;}
    return;
  }
  showOutput('<span class="ok">'+escHtml(result)+'</span>');
}

// ── DEBUG ─────────────────────────────────────────────────────
async function debugCode() {
  var code = document.getElementById('code-editor').value.trim();
  if(!code) { showAI('<span style="color:#f87171;">No code to debug.</span>','🐛 Debug'); return; }
  showAI('<div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span> Analyzing for bugs…</div>','🐛 Debugging…');
  document.getElementById('complexity-output').innerHTML = '<div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>';

  var result = await callProxy(
    'You are a code debugger. Analyze this '+curLang+' code for bugs, errors, and issues. Format your response as:\n🐛 BUGS FOUND: (list each bug with line reference)\n✅ FIXES: (exact fixed code or fix for each bug)\n⚠ WARNINGS: (potential issues)\n📊 TIME COMPLEXITY: O(?)\n📦 SPACE COMPLEXITY: O(?)\nBe specific about line numbers.',
    [{role:'user',content:'Debug this '+curLang+' code:\n```\n'+code+'\n```'}]
  );
  if(result==='__NO_API_KEY__'){showApiKeyWarning('ai-output');document.getElementById('complexity-output').innerHTML='<span style="color:#475569;font-size:12px;">API key required.</span>';return;}
  showAI(formatAIOutput(result), '🐛 Debug Results');
  extractComplexity(result);
}

// ── EXPLAIN ───────────────────────────────────────────────────
async function explainCode() {
  var code = document.getElementById('code-editor').value.trim();
  if(!code) { showAI('<span style="color:#f87171;">No code to explain.</span>','💡 Explain'); return; }
  showAI('<div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span> Generating explanation…</div>','💡 Explaining…');
  document.getElementById('complexity-output').innerHTML = '<div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>';

  var result = await callProxy(
    'You are a code explainer for students. Explain this '+curLang+' code in simple terms. Format:\n📖 WHAT IT DOES: (1-2 sentences)\n🔍 LINE BY LINE:\n(explain each important block)\n💡 KEY CONCEPTS: (list concepts used)\n📊 TIME COMPLEXITY: O(?)\n📦 SPACE COMPLEXITY: O(?)',
    [{role:'user',content:'Explain this '+curLang+' code:\n```\n'+code+'\n```'}]
  );
  if(result==='__NO_API_KEY__'){showApiKeyWarning('ai-output');document.getElementById('complexity-output').innerHTML='<span style="color:#475569;font-size:12px;">API key required.</span>';return;}
  showAI(formatAIOutput(result), '💡 Code Explanation');
  extractComplexity(result);
}

// ── OPTIMIZE ──────────────────────────────────────────────────
async function optimizeCode() {
  var code = document.getElementById('code-editor').value.trim();
  if(!code) { showAI('<span style="color:#f87171;">No code to optimize.</span>','⚡ Optimize'); return; }
  showAI('<div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span> Finding optimizations…</div>','⚡ Optimizing…');

  var result = await callProxy(
    'You are a code optimizer. Analyze this '+curLang+' code and suggest optimizations. Format:\n⚡ OPTIMIZATIONS:\n1. (what to improve and why)\n2. ...\n✨ OPTIMIZED CODE:\n```\n(paste optimized version)\n```\n📊 IMPROVEMENT: (before vs after complexity)',
    [{role:'user',content:'Optimize this '+curLang+' code:\n```\n'+code+'\n```'}]
  );
  if(result==='__NO_API_KEY__'){showApiKeyWarning('ai-output');return;}
  showAI(formatAIOutput(result), '⚡ Optimized');
}

function extractComplexity(text) {
  var tc = text.match(/TIME COMPLEXITY[:\s]+([^\n]+)/i);
  var sc = text.match(/SPACE COMPLEXITY[:\s]+([^\n]+)/i);
  var html = '';
  if(tc) html += '<div style="margin-bottom:8px;"><span style="color:#64748b;font-size:11px;">TIME</span><br><strong style="color:#818cf8;font-size:1.1rem;">'+tc[1].trim()+'</strong></div>';
  if(sc) html += '<div><span style="color:#64748b;font-size:11px;">SPACE</span><br><strong style="color:#10b981;font-size:1.1rem;">'+sc[1].trim()+'</strong></div>';
  if(html) document.getElementById('complexity-output').innerHTML = html;
  else document.getElementById('complexity-output').innerHTML = '<span style="color:#475569;font-size:12px;">No complexity info found.</span>';
}

function formatAIOutput(text) {
  return text
    .replace(/```[\w]*\n?([\s\S]*?)```/g, '<pre style="background:rgba(0,0,0,.3);border-radius:8px;padding:10px;font-size:12px;overflow-x:auto;color:#6ee7b7;border-left:3px solid #10b981;">$1</pre>')
    .replace(/^(📖|🔍|💡|📊|📦|🐛|✅|⚠|⚡|✨)/gm, '<strong style="color:#818cf8;">$1</strong>')
    .replace(/\n/g, '<br>');
}

function showApiKeyWarning(panelId) {
  var target = panelId || 'ai-output';
  document.getElementById(target).innerHTML =
    '<div style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.3);border-radius:8px;padding:12px;font-size:12px;color:#fbbf24;">' +
    '<strong>⚠ Anthropic API Key Required</strong><br><br>' +
    'Paste your <code style="background:rgba(0,0,0,.3);padding:2px 5px;border-radius:4px;">sk-ant-…</code> key in the <strong>🤖 API Key</strong> panel on the right to use AI features.<br><br>' +
    '<a href="https://console.anthropic.com/keys" target="_blank" style="color:#10b981;">Get your free API key →</a>' +
    '</div>';
}

async function callProxy(system, messages) {
  var antKey = (document.getElementById('anthropic-key')||{}).value
               || localStorage.getItem('devloom_anthropic_key') || '';
  if(!antKey || !antKey.startsWith('sk-ant-')) {
    return '__NO_API_KEY__';
  }
  try {
    var res = await fetch('api_proxy.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': antKey
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: system,
        messages: messages
      })
    });
    var data = await res.json();
    if(data.error) return '⚠ ' + (data.message || data.error);
    return data.content?.map(function(c){return c.text||'';}).join('') || 'No response.';
  } catch(e) {
    return '⚠ Connection error: ' + e.message;
  }
}

function escHtml(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

// Init
document.getElementById('code-editor').value = TEMPLATES[curLang];
renderSnippets();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
