# Devloom — Web + Mobile Integration Guide

This zip contains your **existing PHP/XAMPP web app** (`devloom/`) with the
Android app **attached and wired up**, plus the **mobile app source**
(`devloom-mobile/`). No existing web app feature, page, or table was
changed or removed — everything below is additive.

## What was added to `devloom/` (the web app)

| Path | What it does |
|---|---|
| `mobile_api/` | New folder. A small REST-ish API the mobile app talks to (login, register, refresh, forgot password, dashboard summary, profile, device registration). Reuses your existing `devloom` MySQL database and `config/db.php` connection — a user's web account and app account are the same account. |
| `get-app.php` | New public page at `/devloom/get-app.php` where users download the APK, with a QR code for scanning on a phone. |
| `downloads/` | Drop the built `devloom.apk` here — the download page turns itself on automatically once the file exists. |
| `database/migrate_mobile.sql` | Optional manual SQL for the two new tables (`mobile_tokens`, `device_tokens`). Not required — `mobile_api/bootstrap.php` creates them automatically on first use, same auto-migration style already used in `config/db.php`. |
| `includes/header.php` | One line added: a "📱 Get App" nav link, visible to everyone. |
| `admin/index.php` | Two small additions: when you update a project's status, or reply to a user's message, it now also pushes a phone notification to that user (if they've installed the app and are logged in). No existing admin behavior changed. |

Nothing else in the web app was touched.

## What was changed in `devloom-mobile/` (the app source)

- `lib/config.ts` — `API_BASE_URL` now points at `devloom/mobile_api` instead of a placeholder NestJS URL.
- `lib/api.ts` / `lib/notifications.ts` — endpoint paths updated to match the new PHP files (e.g. `/login.php` instead of `/auth/mobile-login`).
- `DEMO_MODE` is still `true` by default, so the app keeps working out of the box with mock data. Flip it to `false` once you've set the correct `API_BASE_URL` for your setup (see comments in `lib/config.ts`).

Everything else in the app (screens, components, theme, navigation) is unchanged.

## ⚠️ About the actual `.apk` file — the one step you need to run yourself

I can hand you all the source code and the backend it talks to, but **I
cannot compile a `.apk` binary inside this chat environment** — that
requires Android build tooling (SDK, Gradle, signing keys) or Expo's cloud
build service, neither of which this sandbox has network access to. This
isn't a missing feature I skipped — it's genuinely outside what a chat
assistant's code environment can do.

Here's the one step to finish it, from a real computer with Node.js installed:

```bash
cd devloom-mobile
npm install
npm install -g eas-cli
eas login              # free Expo account
eas build:configure
eas build -p android --profile preview
```

`eas build` runs on Expo's servers and, after a few minutes, gives you a
download link to a real, installable `.apk`. Save that file as:

```
devloom/downloads/devloom.apk
```

Re-upload the `devloom` folder (or just that one file) to your XAMPP
`htdocs`, and `get-app.php` will immediately start serving it.

## Setting up push notifications end-to-end

1. **Get a project ID**: still inside `devloom-mobile`, run `eas init` (part of the same `eas` login above). It prints a project ID.
2. Paste that ID into `devloom-mobile/lib/notifications.ts`, replacing `'YOUR_EAS_PROJECT_ID'`.
3. Rebuild the APK (`eas build -p android --profile preview` again) so the new build includes it.
4. On the web app side: nothing else to configure — `mobile_api/bootstrap.php` already sends pushes via Expo's push API (`https://exp.host/--/api/v2/push/send`) whenever:
   - an admin replies to a user's message, or
   - an admin updates a project's status,
   - or a password is reset from the app.

Test it by: installing the real APK on a phone → log in → have the admin (on the web dashboard) reply to that user or update their project → the phone should get a notification within a few seconds.

**Important:** push notifications only work in a real installed APK, not in Expo Go / dev mode — this is an Expo/Android platform limitation, not a bug in this setup.

## Local testing checklist

- [ ] XAMPP running, `devloom` database imported (as before — nothing changed there)
- [ ] Visit `http://localhost/devloom/get-app.php` — page loads (shows "APK not uploaded yet" until you add one)
- [ ] `devloom-mobile`: `npm install && npx expo start` still runs fine in demo mode (unaffected)
- [ ] After building the real APK and flipping `DEMO_MODE = false` with the correct `API_BASE_URL` for your network: register/login from the app creates/matches a row in the `users` table exactly like the website does
- [ ] Admin replies to that user on the website → phone gets a push notification
