<?php
/**
 * fix_uploads.php — Run this ONCE to fix folder structure + DB migrations.
 * Visit: http://localhost/devloom/fix_uploads.php
 * Delete this file after running it.
 */
require_once __DIR__ . '/config/db.php';
$log = [];

/* ── 1. Create all upload folders ────────────────────────── */
$dirs = [
    __DIR__ . '/uploads/',
    __DIR__ . '/uploads/files/',
    __DIR__ . '/uploads/screenshots/',
    __DIR__ . '/uploads/messages/',
];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        $log[] = ['ok', "Created folder: " . basename($dir) . "/"];
    } else {
        $log[] = ['ok', "Folder exists: " . basename($dir) . "/"];
    }
    // Check writability
    if (!is_writable($dir)) {
        $log[] = ['warn', "⚠️  NOT WRITABLE: $dir — right-click the folder, Properties → Security → give XAMPP/Apache write access"];
    } else {
        $log[] = ['ok', "Writable ✓: $dir"];
    }
}

/* ── 2. Copy any legacy files screenshots/ → files/ ─────── */
$legacyDir = __DIR__ . '/uploads/screenshots/';
$newDir    = __DIR__ . '/uploads/files/';
$copied = 0; $skipped = 0;
if (is_dir($legacyDir)) {
    foreach (scandir($legacyDir) as $file) {
        if ($file === '.' || $file === '..') continue;
        $src  = $legacyDir . $file;
        $dest = $newDir    . $file;
        if (!file_exists($dest)) { copy($src, $dest); $copied++; }
        else $skipped++;
    }
    $log[] = ['ok', "Copied $copied file(s) from screenshots/ → files/ ($skipped already existed)"];
}

/* ── 3. DB migrations ────────────────────────────────────── */
$migrations = [
    // screenshots table extra columns
    "ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS original_name VARCHAR(300) DEFAULT '' AFTER filename",
    "ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS file_type ENUM('screenshot','project_file') DEFAULT 'screenshot' AFTER original_name",
    // user_messages edited column
    "ALTER TABLE user_messages ADD COLUMN IF NOT EXISTS edited TINYINT(1) DEFAULT 0",
    // message_attachments table
    "CREATE TABLE IF NOT EXISTS message_attachments (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        message_id    INT          NOT NULL,
        filename      VARCHAR(300) NOT NULL,
        original_name VARCHAR(300) NOT NULL DEFAULT '',
        file_size     INT          DEFAULT 0,
        mime_type     VARCHAR(120) DEFAULT '',
        uploaded_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (message_id) REFERENCES user_messages(id) ON DELETE CASCADE
    )",
    // password_resets table
    "CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token VARCHAR(64) NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )",
    // reviews table
    "CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        project_id INT DEFAULT NULL,
        rating TINYINT(1) NOT NULL DEFAULT 5,
        description TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
    )",
];

foreach ($migrations as $sql) {
    try {
        $pdo->exec($sql);
        // Get a short label from the SQL
        preg_match('/(CREATE TABLE IF NOT EXISTS|ALTER TABLE|CREATE TABLE)\s+(\w+)/i', $sql, $m);
        $label = isset($m[2]) ? $m[2] : 'query';
        $log[] = ['ok', "Migration OK: $label"];
    } catch (Exception $e) {
        $log[] = ['warn', "Migration notice: " . $e->getMessage()];
    }
}

/* ── 4. Check orphaned DB records (in DB but not on disk) ── */
$orphans = [];
$rows = $pdo->query("SELECT filename FROM screenshots")->fetchAll(PDO::FETCH_COLUMN);
foreach ($rows as $fname) {
    $exists = file_exists(__DIR__ . '/uploads/files/' . $fname)
           || file_exists(__DIR__ . '/uploads/screenshots/' . $fname);
    if (!$exists) $orphans[] = $fname;
}
if ($orphans) {
    $log[] = ['warn', count($orphans) . " screenshot record(s) in DB have no file on disk — re-upload them in the admin panel:"];
    foreach ($orphans as $o) $log[] = ['info', "&nbsp;&nbsp;&nbsp;• $o"];
} else {
    $log[] = ['ok', "All screenshot DB records have matching files on disk ✓"];
}

?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Devloom — Fix Uploads</title>
  <style>
    body { font-family: monospace; background:#0a0f14; color:#e2e8f0; padding:40px; }
    h1   { color:#10b981; margin-bottom:24px; }
    .log { line-height:2; font-size:14px; }
    .ok   { color:#6ee7b7; }
    .warn { color:#fbbf24; }
    .info { color:#94a3b8; }
    .done { margin-top:28px; padding:18px 22px; background:rgba(16,185,129,.1); border:1px solid rgba(16,185,129,.3); border-radius:10px; color:#6ee7b7; line-height:2; }
    a { color:#10b981; }
  </style>
</head>
<body>
  <h1>🔧 Devloom — Fix Uploads &amp; DB</h1>
  <div class="log">
    <?php foreach ($log as [$type, $msg]): ?>
    <div class="<?= $type ?>"><?= $msg ?></div>
    <?php endforeach; ?>
  </div>
  <div class="done">
    <strong>All done!</strong><br>
    • If you see yellow ⚠️ "NOT WRITABLE" warnings above, right-click the <code>uploads/</code> folder in Windows Explorer → Properties → Security → give full write access to the Apache/XAMPP user.<br>
    • If files show "orphaned" above, go to the <a href="/devloom/admin/index.php">Admin Panel</a> and re-upload those screenshots for the project.<br>
    • After fixing, <strong>delete this file</strong> (fix_uploads.php) for security.<br><br>
    <a href="/devloom/admin/index.php">→ Admin Panel</a> &nbsp;|&nbsp;
    <a href="/devloom/dashboard.php">→ Dashboard</a>
  </div>
</body>
</html>
