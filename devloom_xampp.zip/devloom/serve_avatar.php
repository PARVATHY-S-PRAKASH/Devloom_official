<?php
/**
 * serve_avatar.php — Safely serve profile photos from uploads/avatars/
 * Usage: /devloom/serve_avatar.php?f=avatar_1_1234567890.jpg
 */
require_once __DIR__ . '/config/db.php';

$file    = basename($_GET['f'] ?? '');
$allowed = ['jpg','jpeg','png','gif','webp'];
$ext     = strtolower(pathinfo($file, PATHINFO_EXTENSION));

if (!$file || !in_array($ext, $allowed)) {
    http_response_code(400); exit('Invalid file.');
}

$path = __DIR__ . '/uploads/avatars/' . $file;

if (!file_exists($path)) {
    http_response_code(404); exit('Not found.');
}

$mime = [
    'jpg'  => 'image/jpeg', 'jpeg' => 'image/jpeg',
    'png'  => 'image/png',  'gif'  => 'image/gif',
    'webp' => 'image/webp',
][$ext] ?? 'application/octet-stream';

header('Content-Type: '  . $mime);
header('Content-Length: ' . filesize($path));
header('Cache-Control: public, max-age=86400');
readfile($path);
