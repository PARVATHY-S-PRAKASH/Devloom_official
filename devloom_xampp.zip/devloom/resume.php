<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Resume Builder';
$activePage = 'features';
include __DIR__ . '/includes/header.php';
$userName  = $_SESSION['user_name'] ?? '';
$userEmail = $_SESSION['user_email'] ?? '';
?>
<style>
.rb-wrap{max-width:1100px;margin:0 auto;padding:30px 0 80px;}
.rb-header{text-align:center;margin-bottom:28px;}
.rb-header h1{font-size:2rem;font-weight:900;color:#f1f5f9;}
.rb-grid{display:grid;grid-template-columns:380px 1fr;gap:24px;align-items:start;}
@media(max-width:820px){.rb-grid{grid-template-columns:1fr;}}
.rb-form-panel{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:22px;}
.rb-preview-panel{background:#fff;border-radius:16px;overflow:hidden;min-height:600px;box-shadow:0 4px 40px rgba(0,0,0,.4);}
.section-title{font-size:11px;font-family:monospace;color:#64748b;text-transform:uppercase;letter-spacing:.1em;margin:18px 0 10px;padding-bottom:6px;border-bottom:1px solid rgba(255,255,255,.06);}
.section-title:first-child{margin-top:0;}
.rb-input{width:100%;background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.09);border-radius:9px;color:#e2e8f0;padding:9px 12px;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;transition:border-color .2s;margin-bottom:8px;}
.rb-input:focus{border-color:rgba(16,185,129,.4);}
.rb-input::placeholder{color:#475569;}
textarea.rb-input{resize:vertical;min-height:72px;}
.add-btn{width:100%;padding:8px;border:1px dashed rgba(255,255,255,.15);border-radius:8px;background:transparent;color:#64748b;font-size:12px;cursor:pointer;transition:all .2s;margin-bottom:6px;}
.add-btn:hover{border-color:rgba(16,185,129,.4);color:#10b981;}
.item-row{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:8px;padding:10px 12px;margin-bottom:8px;position:relative;}
.remove-btn{position:absolute;right:8px;top:8px;background:none;border:none;color:#475569;cursor:pointer;font-size:14px;}
.remove-btn:hover{color:#f87171;}
.tpl-row{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;}
.tpl-btn{flex:1;padding:8px;border:1.5px solid rgba(255,255,255,.1);border-radius:8px;background:transparent;color:#94a3b8;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;min-width:70px;}
.tpl-btn.active{border-color:#10b981;background:rgba(16,185,129,.1);color:#10b981;}
/* Preview */
#resume-preview{padding:32px;font-family:'Segoe UI',Arial,sans-serif;color:#1e293b;font-size:13px;line-height:1.5;}
.rv-name{font-size:24px;font-weight:800;margin-bottom:2px;}
.rv-contact{font-size:11px;color:#64748b;margin-bottom:14px;display:flex;gap:12px;flex-wrap:wrap;}
.rv-section{margin-bottom:14px;}
.rv-sh{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;padding-bottom:4px;margin-bottom:8px;border-bottom:2px solid #1e293b;}
.rv-item{margin-bottom:8px;}
.rv-item-title{font-weight:700;font-size:13px;}
.rv-item-sub{font-size:11px;color:#64748b;margin-bottom:3px;}
.rv-item-desc{font-size:12px;color:#334155;}
.rv-skills{display:flex;flex-wrap:wrap;gap:5px;}
.rv-skill{background:#f1f5f9;border-radius:4px;padding:2px 8px;font-size:11px;font-weight:600;}
.rv-two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
/* Themes */
.theme-green .rv-sh{border-color:#059669;color:#059669;}
.theme-green .rv-name{color:#059669;}
.theme-green .rv-skill{background:#dcfce7;color:#166534;}
.theme-blue .rv-sh{border-color:#2563eb;color:#2563eb;}
.theme-blue .rv-name{color:#2563eb;}
.theme-blue .rv-skill{background:#dbeafe;color:#1e40af;}
.theme-purple .rv-sh{border-color:#7c3aed;color:#7c3aed;}
.theme-purple .rv-name{color:#7c3aed;}
.theme-purple .rv-skill{background:#ede9fe;color:#5b21b6;}
/* Modern Two-Column template */
.tpl-modern{display:grid;grid-template-columns:200px 1fr;min-height:600px;font-family:'Segoe UI',Arial,sans-serif;font-size:13px;color:#1e293b;}
.tpl-modern .rv-sidebar{background:#1e293b;color:#f1f5f9;padding:24px 16px;}
.tpl-modern .rv-sidebar .rv-name{color:#fff;font-size:20px;font-weight:900;margin-bottom:4px;}
.tpl-modern .rv-sidebar .rv-contact{flex-direction:column;gap:6px;font-size:11px;color:#94a3b8;margin-bottom:16px;}
.tpl-modern .rv-sidebar .rv-sh{border-bottom:2px solid #334155;color:#10b981;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;padding-bottom:3px;margin-bottom:8px;}
.tpl-modern .rv-sidebar .rv-skill{background:#334155;color:#94a3b8;font-size:11px;}
.tpl-modern .rv-sidebar .rv-skills{display:flex;flex-wrap:wrap;gap:4px;}
.tpl-modern .rv-main{padding:24px 20px;}
.tpl-modern .rv-main .rv-sh{border-bottom:2px solid #10b981;color:#10b981;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;padding-bottom:3px;margin-bottom:10px;}
/* Minimal template */
.tpl-minimal{font-family:'Georgia',serif;font-size:13px;color:#2d2d2d;padding:32px;}
.tpl-minimal .rv-name{font-size:28px;font-weight:400;letter-spacing:2px;text-transform:uppercase;border-bottom:1px solid #2d2d2d;padding-bottom:8px;margin-bottom:6px;}
.tpl-minimal .rv-contact{font-size:11px;color:#666;gap:16px;margin-bottom:18px;display:flex;flex-wrap:wrap;}
.tpl-minimal .rv-sh{font-size:11px;font-weight:400;text-transform:uppercase;letter-spacing:.15em;color:#888;border-bottom:1px solid #ddd;padding-bottom:3px;margin-bottom:10px;}
.tpl-minimal .rv-skill{background:#f5f5f5;color:#555;font-size:11px;font-family:'Georgia',serif;}
/* Tech template */
.tpl-tech{font-family:'Courier New',Courier,monospace;font-size:12.5px;color:#1e293b;background:#fff;}
.tpl-tech .rv-tech-header{background:#0f172a;padding:24px 28px;color:#e2e8f0;}
.tpl-tech .rv-name{color:#10b981;font-size:24px;font-weight:900;letter-spacing:-0.5px;}
.tpl-tech .rv-title-line{color:#64748b;font-size:11px;margin-bottom:8px;}
.tpl-tech .rv-contact{color:#94a3b8;font-size:10.5px;gap:10px;display:flex;flex-wrap:wrap;margin-top:4px;}
.tpl-tech .rv-body{padding:20px 28px;}
.tpl-tech .rv-sh{color:#0f172a;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.12em;border-bottom:2px solid #10b981;padding-bottom:3px;margin-bottom:10px;}
.tpl-tech .rv-skill{background:#f0fdf4;color:#166534;font-size:10.5px;border:1px solid #bbf7d0;font-family:'Courier New',monospace;}
/* Executive (photo header) */
.tpl-executive{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;color:#1a1a2e;}
.tpl-executive .rv-exec-header{background:linear-gradient(135deg,#1a1a2e,#16213e);padding:28px;color:#fff;display:flex;gap:20px;align-items:center;}
.tpl-executive .rv-exec-photo{width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,.3);flex-shrink:0;background:rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:32px;}
.tpl-executive .rv-exec-info{flex:1;}
.tpl-executive .rv-name{color:#fff;font-size:26px;font-weight:800;margin-bottom:4px;}
.tpl-executive .rv-contact{color:rgba(255,255,255,.75);font-size:11px;gap:10px;display:flex;flex-wrap:wrap;}
.tpl-executive .rv-body{padding:22px 28px;}
.tpl-executive .rv-sh{color:#1a1a2e;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;border-bottom:2.5px solid #1a1a2e;padding-bottom:3px;margin-bottom:10px;}
.tpl-executive .rv-skill{background:#e8e8f0;color:#1a1a2e;font-size:11px;}
/* Elegant (two-col with photo) */
.tpl-elegant{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;color:#2c2c2c;display:grid;grid-template-columns:220px 1fr;min-height:600px;}
.tpl-elegant .rv-sidebar{background:#f8f4ef;padding:28px 18px;border-right:1px solid #e0d8cf;}
.tpl-elegant .rv-elegant-photo{width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid #c9a96e;margin:0 auto 14px;display:flex;align-items:center;justify-content:center;font-size:36px;background:#e8e0d8;}
.tpl-elegant .rv-name{font-size:18px;font-weight:800;color:#2c2c2c;text-align:center;margin-bottom:6px;}
.tpl-elegant .rv-contact{flex-direction:column;gap:5px;font-size:11px;color:#6b5e4e;text-align:center;}
.tpl-elegant .rv-sh{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.15em;color:#c9a96e;border-bottom:1px solid #c9a96e;padding-bottom:3px;margin:14px 0 8px;}
.tpl-elegant .rv-skill{background:#ede8e0;color:#6b5e4e;font-size:10.5px;}
.tpl-elegant .rv-main{padding:28px 22px;}
.tpl-elegant .rv-main .rv-sh{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#c9a96e;border-bottom:2px solid #c9a96e;padding-bottom:3px;margin-bottom:10px;}
/* Corporate */
.tpl-corporate{font-family:'Arial',sans-serif;font-size:13px;color:#1a1a1a;}
.tpl-corporate .rv-corp-header{border-bottom:4px solid #1a5276;padding:20px 28px 16px;display:flex;gap:20px;align-items:center;}
.tpl-corporate .rv-corp-photo{width:72px;height:72px;border-radius:4px;object-fit:cover;border:2px solid #1a5276;flex-shrink:0;background:#eaf2f8;display:flex;align-items:center;justify-content:center;font-size:28px;}
.tpl-corporate .rv-corp-info{flex:1;}
.tpl-corporate .rv-name{color:#1a5276;font-size:24px;font-weight:700;margin-bottom:3px;}
.tpl-corporate .rv-contact{color:#555;font-size:11px;gap:10px;display:flex;flex-wrap:wrap;}
.tpl-corporate .rv-body{padding:18px 28px;}
.tpl-corporate .rv-sh{color:#1a5276;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;border-left:4px solid #1a5276;padding-left:8px;margin-bottom:8px;border-bottom:none;}
.tpl-corporate .rv-skill{background:#eaf2f8;color:#1a5276;font-size:11px;}
/* Modern photo variant */
.tpl-modern .rv-photo-circle{width:75px;height:75px;border-radius:50%;object-fit:cover;border:3px solid #10b981;margin:0 auto 14px;display:flex;align-items:center;justify-content:center;font-size:30px;background:#1e3a2e;}
.tpl-creative{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;color:#1e293b;}
.tpl-creative .rv-header-bar{background:linear-gradient(135deg,#f97316,#ea580c);padding:24px 28px;color:#fff;}
.tpl-creative .rv-name{color:#fff;font-size:26px;font-weight:900;}
.tpl-creative .rv-contact{color:rgba(255,255,255,.85);font-size:11px;gap:12px;display:flex;flex-wrap:wrap;margin-top:6px;}
.tpl-creative .rv-body{padding:20px 28px;}
.tpl-creative .rv-sh{color:#ea580c;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;border-left:4px solid #ea580c;padding-left:8px;margin-bottom:10px;border-bottom:none;}
.tpl-creative .rv-skill{background:#fff7ed;color:#c2410c;font-size:11px;}
</style>

<div class="container">
<div class="rb-wrap">
  <div class="rb-header">
    <h1>📄 Resume Builder</h1>
    <p style="color:#94a3b8;">Build a professional resume instantly. Fill in details → preview updates live → download as PDF.</p>
  </div>

  <div class="rb-grid">
    <!-- Form Panel -->
    <div class="rb-form-panel">
      <div class="section-title">Template & Theme</div>
      <div class="tpl-row">
        <button class="tpl-btn active" onclick="setTheme('default',this)" title="Clean classic layout">📄 Classic</button>
        <button class="tpl-btn" onclick="setTheme('modern',this)" title="Dark sidebar, photo support">🎨 Modern</button>
        <button class="tpl-btn" onclick="setTheme('executive',this)" title="Professional photo header">👔 Executive</button>
        <button class="tpl-btn" onclick="setTheme('minimal',this)" title="Elegant serif, no photo">✍ Minimal</button>
        <button class="tpl-btn" onclick="setTheme('creative',this)" title="Bold orange header">🎯 Creative</button>
        <button class="tpl-btn" onclick="setTheme('tech',this)" title="Developer-focused, dark accent">💻 Tech</button>
        <button class="tpl-btn" onclick="setTheme('elegant',this)" title="Two-column with photo">🌟 Elegant</button>
        <button class="tpl-btn" onclick="setTheme('corporate',this)" title="Classic corporate, photo optional">🏢 Corporate</button>
        <button class="tpl-btn" onclick="setTheme('green',this)">🟢 Green</button>
        <button class="tpl-btn" onclick="setTheme('blue',this)">🔵 Blue</button>
        <button class="tpl-btn" onclick="setTheme('purple',this)">🟣 Purple</button>
      </div>
      <div id="photo-notice" style="font-size:11px;color:#10b981;margin-bottom:6px;display:none;">📸 This template supports an optional profile photo.</div>

      <div class="section-title">Personal Info</div>
      <input class="rb-input" id="r-name" placeholder="Full Name" oninput="renderResume()">
      <input class="rb-input" id="r-email" placeholder="Email" oninput="renderResume()">
      <input class="rb-input" id="r-phone" placeholder="Phone" oninput="renderResume()">
      <input class="rb-input" id="r-location" placeholder="Location (City, State)" oninput="renderResume()">
      <input class="rb-input" id="r-linkedin" placeholder="LinkedIn URL (optional)" oninput="renderResume()">
      <input class="rb-input" id="r-github" placeholder="GitHub URL (optional)" oninput="renderResume()">

      <div id="photo-upload-section" style="display:none;">
        <div class="section-title" style="margin-top:4px;">Profile Photo <span style="color:#64748b;font-size:10px;">(optional for this template)</span></div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
          <div id="photo-preview" style="width:64px;height:64px;border-radius:50%;background:rgba(255,255,255,.07);border:2px dashed rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:22px;overflow:hidden;flex-shrink:0;">👤</div>
          <div style="flex:1;">
            <label style="display:inline-block;padding:7px 14px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:8px;color:#10b981;font-size:12px;cursor:pointer;font-weight:600;">
              📷 Upload Photo
              <input type="file" id="r-photo" accept="image/*" style="display:none;" onchange="handlePhotoUpload(this)">
            </label>
            <button onclick="clearPhoto()" style="background:none;border:none;color:#475569;font-size:11px;cursor:pointer;margin-left:8px;">✕ Remove</button>
            <p style="font-size:10px;color:#475569;margin:4px 0 0;">JPG, PNG. Max 2MB. Photo is embedded locally only.</p>
          </div>
        </div>
      </div>
      <textarea class="rb-input" id="r-summary" placeholder="Professional summary / objective (2-3 lines)" oninput="renderResume()"></textarea>

      <div class="section-title">Education</div>
      <div id="edu-list"></div>
      <button class="add-btn" onclick="addEdu()">+ Add Education</button>

      <div class="section-title">Experience</div>
      <div id="exp-list"></div>
      <button class="add-btn" onclick="addExp()">+ Add Experience</button>

      <div class="section-title">Projects</div>
      <div id="proj-list"></div>
      <button class="add-btn" onclick="addProj()">+ Add Project</button>

      <div class="section-title">Skills</div>
      <input class="rb-input" id="r-skills" placeholder="Comma-separated: Java, Python, MySQL, React…" oninput="renderResume()">

      <div class="section-title">Certifications</div>
      <input class="rb-input" id="r-certs" placeholder="e.g. AWS Certified, Oracle Java SE…" oninput="renderResume()">

      <div class="section-title">Achievements</div>
      <textarea class="rb-input" id="r-achievements" placeholder="e.g. • Best Project Award 2024&#10;• Hackathon Winner" oninput="renderResume()"></textarea>

      <button class="btn btn-primary" onclick="downloadPDF()" style="width:100%;padding:12px;margin-top:10px;font-size:14px;">
        📥 Download PDF
      </button>
    </div>

    <!-- Preview Panel -->
    <div class="rb-preview-panel">
      <div id="resume-preview" class="theme-default">
        <div style="text-align:center;color:#94a3b8;padding:80px 20px;">
          Fill in your details on the left to see your resume preview here 👈
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<script>
var curTheme = 'default';
var eduCount = 0, expCount = 0, projCount = 0;
var photoDataUrl = null;

// Templates that support/need photo
var PHOTO_TEMPLATES = ['modern','executive','elegant','corporate'];

function handlePhotoUpload(input) {
  if(!input.files||!input.files[0])return;
  var file=input.files[0];
  if(file.size>2*1024*1024){alert('Image too large. Max 2MB.');return;}
  var reader=new FileReader();
  reader.onload=function(e){
    photoDataUrl=e.target.result;
    var prev=document.getElementById('photo-preview');
    if(prev)prev.innerHTML='<img src="'+photoDataUrl+'" style="width:100%;height:100%;object-fit:cover;">';
    renderResume();
  };
  reader.readAsDataURL(file);
}

function clearPhoto() {
  photoDataUrl=null;
  var prev=document.getElementById('photo-preview');
  if(prev)prev.innerHTML='👤';
  var inp=document.getElementById('r-photo');
  if(inp)inp.value='';
  renderResume();
}

function photoHtml(size, style) {
  size=size||80; style=style||'';
  if(photoDataUrl){
    return '<img src="'+photoDataUrl+'" style="width:'+size+'px;height:'+size+'px;border-radius:50%;object-fit:cover;'+style+'">';
  }
  return '';
}

// Pre-fill name/email
document.getElementById('r-name').value = '<?= addslashes($userName) ?>';
document.getElementById('r-email').value = '<?= addslashes($userEmail) ?>';

function setTheme(t, btn) {
  curTheme = t;
  document.querySelectorAll('.tpl-btn').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  // Show/hide photo upload
  var photoSec=document.getElementById('photo-upload-section');
  var photoNote=document.getElementById('photo-notice');
  if(PHOTO_TEMPLATES.includes(t)){
    if(photoSec)photoSec.style.display='block';
    if(photoNote)photoNote.style.display='block';
  } else {
    if(photoSec)photoSec.style.display='none';
    if(photoNote)photoNote.style.display='none';
  }
  renderResume();
}

function addEdu() {
  var id = ++eduCount;
  var d = document.createElement('div');
  d.className = 'item-row'; d.id = 'edu-'+id;
  d.innerHTML =
    '<button class="remove-btn" onclick="removeItem(\'edu-'+id+'\')">✕</button>'+
    '<input class="rb-input" id="edu-deg-'+id+'" placeholder="Degree / Course" oninput="renderResume()">'+
    '<input class="rb-input" id="edu-inst-'+id+'" placeholder="Institution Name" oninput="renderResume()">'+
    '<input class="rb-input" id="edu-year-'+id+'" placeholder="Year (e.g. 2020–2024)" oninput="renderResume()">'+
    '<input class="rb-input" id="edu-grade-'+id+'" placeholder="CGPA / Percentage (optional)" oninput="renderResume()">';
  document.getElementById('edu-list').appendChild(d);
  renderResume();
}

function addExp() {
  var id = ++expCount;
  var d = document.createElement('div');
  d.className = 'item-row'; d.id = 'exp-'+id;
  d.innerHTML =
    '<button class="remove-btn" onclick="removeItem(\'exp-'+id+'\')">✕</button>'+
    '<input class="rb-input" id="exp-role-'+id+'" placeholder="Job Title / Role" oninput="renderResume()">'+
    '<input class="rb-input" id="exp-comp-'+id+'" placeholder="Company Name" oninput="renderResume()">'+
    '<input class="rb-input" id="exp-dur-'+id+'" placeholder="Duration (e.g. Jun 2023 – Aug 2023)" oninput="renderResume()">'+
    '<textarea class="rb-input" id="exp-desc-'+id+'" placeholder="• Responsibilities and achievements" oninput="renderResume()"></textarea>';
  document.getElementById('exp-list').appendChild(d);
  renderResume();
}

function addProj() {
  var id = ++projCount;
  var d = document.createElement('div');
  d.className = 'item-row'; d.id = 'proj-'+id;
  d.innerHTML =
    '<button class="remove-btn" onclick="removeItem(\'proj-'+id+'\')">✕</button>'+
    '<input class="rb-input" id="proj-name-'+id+'" placeholder="Project Name" oninput="renderResume()">'+
    '<input class="rb-input" id="proj-tech-'+id+'" placeholder="Tech stack (e.g. React, Node.js, MySQL)" oninput="renderResume()">'+
    '<textarea class="rb-input" id="proj-desc-'+id+'" placeholder="Brief description of what you built and its impact" oninput="renderResume()"></textarea>';
  document.getElementById('proj-list').appendChild(d);
  renderResume();
}

function removeItem(id) {
  var el = document.getElementById(id);
  if(el) el.remove();
  renderResume();
}

function g(id) { var el=document.getElementById(id); return el ? el.value.trim() : ''; }

// NEW: full multi-template renderResume
function renderResume() {
  var name=g('r-name'), email=g('r-email'), phone=g('r-phone'),
      location=g('r-location'), linkedin=g('r-linkedin'), github=g('r-github'),
      summary=g('r-summary'), skills=g('r-skills'), certs=g('r-certs'), ach=g('r-achievements');

  if(!name && !email) {
    document.getElementById('resume-preview').innerHTML='<div style="text-align:center;color:#94a3b8;padding:80px 20px;">Fill in your details on the left to see your resume preview here 👈</div>';
    return;
  }

  // Shared builders
  var eduItems='';
  for(var i=1;i<=eduCount;i++){
    if(!document.getElementById('edu-'+i))continue;
    var deg=g('edu-deg-'+i),inst=g('edu-inst-'+i),year=g('edu-year-'+i),grade=g('edu-grade-'+i);
    if(!deg&&!inst)continue;
    eduItems+='<div class="rv-item"><div class="rv-item-title">'+(deg||'—')+'</div><div class="rv-item-sub">'+(inst||'')+(year?' · '+year:'')+(grade?' · '+grade:'')+'</div></div>';
  }
  var expItems='';
  for(var i=1;i<=expCount;i++){
    if(!document.getElementById('exp-'+i))continue;
    var role=g('exp-role-'+i),comp=g('exp-comp-'+i),dur=g('exp-dur-'+i),desc=g('exp-desc-'+i);
    if(!role&&!comp)continue;
    expItems+='<div class="rv-item"><div class="rv-item-title">'+(role||'—')+'</div><div class="rv-item-sub">'+(comp||'')+(dur?' · '+dur:'')+'</div>'+(desc?'<div class="rv-item-desc">'+desc.replace(/\n/g,'<br>')+'</div>':'')+'</div>';
  }
  var projItems='';
  for(var i=1;i<=projCount;i++){
    if(!document.getElementById('proj-'+i))continue;
    var pname=g('proj-name-'+i),tech=g('proj-tech-'+i),pdesc=g('proj-desc-'+i);
    if(!pname)continue;
    projItems+='<div class="rv-item"><div class="rv-item-title">'+(pname||'—')+(tech?' <span style="font-weight:400;color:#64748b;font-size:11px;">· '+tech+'</span>':'')+'</div>'+(pdesc?'<div class="rv-item-desc">'+pdesc.replace(/\n/g,'<br>')+'</div>':'')+'</div>';
  }
  var skillArr=skills?skills.split(',').map(function(s){return s.trim();}).filter(Boolean):[];
  var skillHtml=skillArr.map(function(s){return '<span class="rv-skill">'+s+'</span>';}).join('');
  var contactHtml='';
  if(email)contactHtml+='<span>✉ '+email+'</span>';
  if(phone)contactHtml+='<span>📞 '+phone+'</span>';
  if(location)contactHtml+='<span>📍 '+location+'</span>';
  if(linkedin)contactHtml+='<span>🔗 <a href="'+linkedin+'" style="color:inherit;text-decoration:none;">'+linkedin+'</a></span>';
  if(github)contactHtml+='<span>💻 <a href="'+github+'" style="color:inherit;text-decoration:none;">'+github+'</a></span>';

  var html='';
  if(curTheme==='modern'){
    var photoCircle=photoDataUrl?'<img src="'+photoDataUrl+'" style="width:75px;height:75px;border-radius:50%;object-fit:cover;border:3px solid #10b981;margin:0 auto 14px;display:block;">':'';
    var sideHtml=photoCircle+'<div class="rv-name">'+(name||'Your Name')+'</div><div class="rv-contact">'+contactHtml+'</div>';
    if(skillArr.length)sideHtml+='<div class="rv-sh" style="margin-top:16px;">Skills</div><div class="rv-skills">'+skillHtml+'</div>';
    if(certs)sideHtml+='<div class="rv-sh" style="margin-top:16px;">Certifications</div><div style="font-size:11px;color:#94a3b8;">'+certs+'</div>';
    var mainHtml='';
    if(summary)mainHtml+='<div class="rv-section"><div class="rv-sh">Objective</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(eduItems)mainHtml+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(expItems)mainHtml+='<div class="rv-section"><div class="rv-sh">Experience</div>'+expItems+'</div>';
    if(projItems)mainHtml+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(ach)mainHtml+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html='<div class="tpl-modern"><div class="rv-sidebar">'+sideHtml+'</div><div class="rv-main">'+mainHtml+'</div></div>';
  } else if(curTheme==='executive'){
    var photoEl=photoDataUrl?'<img src="'+photoDataUrl+'" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,.3);">':'<div style="width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:32px;flex-shrink:0;">👤</div>';
    html='<div class="tpl-executive">';
    html+='<div class="rv-exec-header">'+photoEl+'<div class="rv-exec-info"><div class="rv-name">'+(name||'Your Name')+'</div><div class="rv-contact">'+contactHtml+'</div></div></div>';
    html+='<div class="rv-body">';
    if(summary)html+='<div class="rv-section"><div class="rv-sh">Professional Summary</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(expItems)html+='<div class="rv-section"><div class="rv-sh">Experience</div>'+expItems+'</div>';
    if(eduItems)html+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(projItems)html+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(skillArr.length)html+='<div class="rv-section"><div class="rv-sh">Core Skills</div><div class="rv-skills">'+skillHtml+'</div></div>';
    if(certs)html+='<div class="rv-section"><div class="rv-sh">Certifications</div><div class="rv-item-desc">'+certs+'</div></div>';
    if(ach)html+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html+='</div></div>';
  } else if(curTheme==='tech'){
    html='<div class="tpl-tech">';
    html+='<div class="rv-tech-header"><div class="rv-name">'+(name||'Your Name')+'</div><div class="rv-contact">'+contactHtml+'</div></div>';
    html+='<div class="rv-body">';
    if(summary)html+='<div class="rv-section"><div class="rv-sh">// About</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(skillArr.length)html+='<div class="rv-section"><div class="rv-sh">// Skills</div><div class="rv-skills">'+skillHtml+'</div></div>';
    if(expItems)html+='<div class="rv-section"><div class="rv-sh">// Experience</div>'+expItems+'</div>';
    if(eduItems)html+='<div class="rv-section"><div class="rv-sh">// Education</div>'+eduItems+'</div>';
    if(projItems)html+='<div class="rv-section"><div class="rv-sh">// Projects</div>'+projItems+'</div>';
    if(certs)html+='<div class="rv-section"><div class="rv-sh">// Certifications</div><div class="rv-item-desc">'+certs+'</div></div>';
    if(ach)html+='<div class="rv-section"><div class="rv-sh">// Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html+='</div></div>';
  } else if(curTheme==='elegant'){
    var photoEl=photoDataUrl?'<img src="'+photoDataUrl+'" style="width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid #c9a96e;margin:0 auto 14px;display:block;">':'<div style="width:90px;height:90px;border-radius:50%;background:#e8e0d8;display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto 14px;">👤</div>';
    var sideHtml=photoEl+'<div class="rv-name" style="text-align:center;">'+(name||'Your Name')+'</div><div class="rv-contact" style="justify-content:center;text-align:center;">'+contactHtml+'</div>';
    if(skillArr.length)sideHtml+='<div class="rv-sh">Skills</div><div class="rv-skills">'+skillHtml+'</div>';
    if(certs)sideHtml+='<div class="rv-sh">Certifications</div><div style="font-size:11px;color:#6b5e4e;">'+certs+'</div>';
    var mainHtml='';
    if(summary)mainHtml+='<div class="rv-section"><div class="rv-sh">Profile</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(expItems)mainHtml+='<div class="rv-section"><div class="rv-sh">Experience</div>'+expItems+'</div>';
    if(eduItems)mainHtml+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(projItems)mainHtml+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(ach)mainHtml+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html='<div class="tpl-elegant"><div class="rv-sidebar">'+sideHtml+'</div><div class="rv-main">'+mainHtml+'</div></div>';
  } else if(curTheme==='corporate'){
    var photoEl=photoDataUrl?'<img src="'+photoDataUrl+'" style="width:72px;height:72px;border-radius:4px;object-fit:cover;border:2px solid #1a5276;">':'';
    html='<div class="tpl-corporate">';
    html+='<div class="rv-corp-header">'+(photoEl?'<div class="rv-corp-photo">'+photoEl+'</div>':'')+'<div class="rv-corp-info"><div class="rv-name">'+(name||'Your Name')+'</div><div class="rv-contact">'+contactHtml+'</div></div></div>';
    html+='<div class="rv-body">';
    if(summary)html+='<div class="rv-section"><div class="rv-sh">Summary</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(expItems)html+='<div class="rv-section"><div class="rv-sh">Work Experience</div>'+expItems+'</div>';
    if(eduItems)html+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(projItems)html+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(skillArr.length)html+='<div class="rv-section"><div class="rv-sh">Skills</div><div class="rv-skills">'+skillHtml+'</div></div>';
    if(certs)html+='<div class="rv-section"><div class="rv-sh">Certifications</div><div class="rv-item-desc">'+certs+'</div></div>';
    if(ach)html+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html+='</div></div>';
  } else if(curTheme==='minimal'){
    html='<div class="tpl-minimal">';
    html+='<div class="rv-name">'+(name||'Your Name')+'</div>';
    html+='<div class="rv-contact">'+contactHtml+'</div>';
    if(summary)html+='<div class="rv-section"><div class="rv-sh">Profile</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(eduItems)html+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(expItems)html+='<div class="rv-section"><div class="rv-sh">Experience</div>'+expItems+'</div>';
    if(projItems)html+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(skillArr.length)html+='<div class="rv-section"><div class="rv-sh">Skills</div><div class="rv-skills">'+skillHtml+'</div></div>';
    if(certs)html+='<div class="rv-section"><div class="rv-sh">Certifications</div><div class="rv-item-desc">'+certs+'</div></div>';
    if(ach)html+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html+='</div>';
  } else if(curTheme==='creative'){
    html='<div class="tpl-creative">';
    html+='<div class="rv-header-bar"><div class="rv-name">'+(name||'Your Name')+'</div><div class="rv-contact">'+contactHtml+'</div></div>';
    html+='<div class="rv-body">';
    if(summary)html+='<div class="rv-section"><div class="rv-sh">About Me</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(eduItems)html+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(expItems)html+='<div class="rv-section"><div class="rv-sh">Experience</div>'+expItems+'</div>';
    if(projItems)html+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(skillArr.length)html+='<div class="rv-section"><div class="rv-sh">Skills</div><div class="rv-skills">'+skillHtml+'</div></div>';
    if(certs)html+='<div class="rv-section"><div class="rv-sh">Certifications</div><div class="rv-item-desc">'+certs+'</div></div>';
    if(ach)html+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html+='</div></div>';
  } else {
    html='<div class="theme-'+curTheme+'">';
    html+='<div class="rv-name">'+(name||'Your Name')+'</div>';
    html+='<div class="rv-contact">'+contactHtml+'</div>';
    if(summary)html+='<div class="rv-section"><div class="rv-sh">Objective</div><div class="rv-item-desc">'+summary.replace(/\n/g,'<br>')+'</div></div>';
    if(eduItems)html+='<div class="rv-section"><div class="rv-sh">Education</div>'+eduItems+'</div>';
    if(expItems)html+='<div class="rv-section"><div class="rv-sh">Experience</div>'+expItems+'</div>';
    if(projItems)html+='<div class="rv-section"><div class="rv-sh">Projects</div>'+projItems+'</div>';
    if(skillArr.length)html+='<div class="rv-section"><div class="rv-sh">Skills</div><div class="rv-skills">'+skillHtml+'</div></div>';
    if(certs)html+='<div class="rv-section"><div class="rv-sh">Certifications</div><div class="rv-item-desc">'+certs+'</div></div>';
    if(ach)html+='<div class="rv-section"><div class="rv-sh">Achievements</div><div class="rv-item-desc">'+ach.replace(/\n/g,'<br>')+'</div></div>';
    html+='</div>';
  }
  document.getElementById('resume-preview').innerHTML = html;
}

function downloadPDF() {
  var name = g('r-name') || 'resume';
  var content = document.getElementById('resume-preview').innerHTML;
  var win = window.open('','_blank');
  win.document.write('<!DOCTYPE html><html><head><title>'+name+' — Resume</title>'+
    '<style>body{font-family:Segoe UI,Arial,sans-serif;margin:0;padding:0;color:#1e293b;font-size:13px;line-height:1.5;}'+
    '.rv-name{font-size:24px;font-weight:800;margin-bottom:2px;}'+
    '.rv-contact{font-size:11px;color:#64748b;margin-bottom:14px;display:flex;gap:12px;flex-wrap:wrap;}'+
    '.rv-section{margin-bottom:14px;}.rv-sh{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;padding-bottom:4px;margin-bottom:8px;border-bottom:2px solid #1e293b;}'+
    '.rv-item{margin-bottom:8px;}.rv-item-title{font-weight:700;}.rv-item-sub{font-size:11px;color:#64748b;}.rv-item-desc{font-size:12px;color:#334155;}'+
    '.rv-skills{display:flex;flex-wrap:wrap;gap:5px;}.rv-skill{background:#f1f5f9;border-radius:4px;padding:2px 8px;font-size:11px;font-weight:600;}'+
    '.theme-green .rv-sh{border-color:#059669;color:#059669;}.theme-green .rv-name{color:#059669;}.theme-green .rv-skill{background:#dcfce7;color:#166534;}'+
    '.theme-blue .rv-sh{border-color:#2563eb;color:#2563eb;}.theme-blue .rv-name{color:#2563eb;}.theme-blue .rv-skill{background:#dbeafe;color:#1e40af;}'+
    '.theme-purple .rv-sh{border-color:#7c3aed;color:#7c3aed;}.theme-purple .rv-name{color:#7c3aed;}.theme-purple .rv-skill{background:#ede9fe;color:#5b21b6;}'+
    '.tpl-modern{display:grid;grid-template-columns:200px 1fr;min-height:600px;}'+
    '.rv-sidebar{background:#1e293b;color:#f1f5f9;padding:24px 16px;}.rv-sidebar .rv-name{color:#fff;font-size:20px;font-weight:900;margin-bottom:4px;}'+
    '.rv-sidebar .rv-contact{flex-direction:column;gap:6px;font-size:11px;color:#94a3b8;margin-bottom:16px;}'+
    '.rv-sidebar .rv-sh{border-bottom:2px solid #334155;color:#10b981;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;padding-bottom:3px;margin-bottom:8px;}'+
    '.rv-sidebar .rv-skill{background:#334155;color:#94a3b8;font-size:11px;}.rv-sidebar .rv-skills{display:flex;flex-wrap:wrap;gap:4px;}'+
    '.rv-main{padding:24px 20px;}.rv-main .rv-sh{border-bottom:2px solid #10b981;color:#10b981;font-size:12px;font-weight:800;text-transform:uppercase;padding-bottom:3px;margin-bottom:10px;}'+
    '.tpl-minimal{font-family:Georgia,serif;font-size:13px;color:#2d2d2d;padding:32px;}'+
    '.tpl-minimal .rv-name{font-size:28px;font-weight:400;letter-spacing:2px;text-transform:uppercase;border-bottom:1px solid #2d2d2d;padding-bottom:8px;margin-bottom:6px;}'+
    '.tpl-minimal .rv-contact{font-size:11px;color:#666;gap:16px;margin-bottom:18px;display:flex;flex-wrap:wrap;}'+
    '.tpl-minimal .rv-sh{font-size:11px;font-weight:400;text-transform:uppercase;letter-spacing:.15em;color:#888;border-bottom:1px solid #ddd;padding-bottom:3px;margin-bottom:10px;}'+
    '.tpl-creative{font-family:Segoe UI,Arial,sans-serif;font-size:13px;color:#1e293b;}'+
    '.rv-header-bar{background:linear-gradient(135deg,#f97316,#ea580c);padding:24px 28px;color:#fff;}'+
    '.tpl-creative .rv-name{color:#fff;font-size:26px;font-weight:900;}'+
    '.tpl-creative .rv-contact{color:rgba(255,255,255,.85);font-size:11px;gap:12px;display:flex;flex-wrap:wrap;margin-top:6px;}'+
    '.rv-body{padding:20px 28px;}'+
    '.tpl-creative .rv-sh{color:#ea580c;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;border-left:4px solid #ea580c;padding-left:8px;margin-bottom:10px;border-bottom:none;}'+
    '.tpl-creative .rv-skill{background:#fff7ed;color:#c2410c;font-size:11px;}'+
    '@media print{body{padding:0;}}</style></head><body>'+content+'</body></html>');
  win.document.close();
  setTimeout(function(){win.print();},400);
}

// Auto-add one of each on load
addEdu(); addExp(); addProj();
renderResume();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
