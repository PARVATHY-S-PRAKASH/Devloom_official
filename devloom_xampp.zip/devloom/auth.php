<?php
require_once __DIR__ . '/config/db.php';

if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '/devloom/admin/index.php' : '/devloom/dashboard.php'));
    exit;
}

$error      = '';
$success    = '';
$defaultTab = 'login';

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    // ── LOGIN ─────────────────────────────────────────────────
    if ($action === 'login') {
        $username = strtolower(trim($_POST['username'] ?? ''));
        $pass     = $_POST['password'] ?? '';

        // Admin check
        if ($username === strtolower(ADMIN_USERNAME) && $pass === ADMIN_PASS) {
            $_SESSION['user_id']     = 0;
            $_SESSION['is_admin']    = true;
            $_SESSION['user_name']   = 'Admin';
            $_SESSION['user_avatar'] = 'AD';
            header('Location: /devloom/admin/index.php');
            exit;
        }

        // Regular user — look up by username OR by email (backward compat)
        $stmt = $pdo->prepare(
            "SELECT * FROM users WHERE username = ? OR (email IS NOT NULL AND email = ?) LIMIT 1"
        );
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($pass, $user['password'])) {
            $_SESSION['user_id']     = $user['id'];
            $_SESSION['user_name']   = $user['name'];
            $_SESSION['user_avatar'] = $user['avatar'];
            $_SESSION['is_admin']    = false;
            header('Location: /devloom/dashboard.php');
            exit;
        }
        $error      = 'Invalid username or password.';
        $defaultTab = 'login';
    }

    // ── REGISTER ──────────────────────────────────────────────
    if ($action === 'register') {
        $name     = trim($_POST['name']     ?? '');
        $username = strtolower(trim($_POST['username'] ?? ''));
        $email    = trim($_POST['email']    ?? '');
        $phone    = trim($_POST['phone']    ?? '');
        $pass     = $_POST['password']      ?? '';
        $secQ     = trim($_POST['security_question'] ?? '');
        $secA     = strtolower(trim($_POST['security_answer'] ?? ''));
        $defaultTab = 'register';

        if (!$name || !$username || !$pass)
            $error = 'Name, username, and password are required.';
        elseif (!preg_match('/^[a-zA-Z0-9_]{3,60}$/', $username))
            $error = 'Username: 3–60 chars, letters/numbers/underscores only.';
        elseif (strlen($pass) < 6)
            $error = 'Password must be at least 6 characters.';
        elseif (!$phone)
            $error = 'Phone number is required (used for password recovery).';
        elseif (!$secQ || !$secA)
            $error = 'Please choose a security question and provide an answer.';
        elseif ($email && !filter_var($email, FILTER_VALIDATE_EMAIL))
            $error = 'Enter a valid email address (or leave it blank).';
        else {
            $chk = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $chk->execute([$username]);
            if ($chk->fetch()) {
                $error = 'That username is already taken.';
            } else {
                // Check email uniqueness if provided
                if ($email) {
                    $chkEmail = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                    $chkEmail->execute([$email]);
                    if ($chkEmail->fetch()) {
                        $error = 'That email address is already registered.';
                        goto register_done;
                    }
                }

                $avatar = strtoupper(substr($name, 0, 1));
                $parts  = explode(' ', $name);
                if (isset($parts[1])) $avatar .= strtoupper(substr($parts[1], 0, 1));

                $stmt = $pdo->prepare(
                    "INSERT INTO users (name, username, email, phone, password, avatar, security_question, security_answer)
                     VALUES (?,?,?,?,?,?,?,?)"
                );
                $stmt->execute([
                    $name,
                    $username,
                    $email ?: null,
                    $phone,
                    password_hash($pass, PASSWORD_DEFAULT),
                    $avatar,
                    $secQ,
                    password_hash($secA, PASSWORD_DEFAULT),
                ]);

                $success    = 'Account created! You can now sign in.';
                $defaultTab = 'login';
            }
            register_done:
        }
    }

    // ── FORGOT PASSWORD — Step 1: verify username + phone + security answer ──
    if ($action === 'forgot_step1') {
        $username = strtolower(trim($_POST['username'] ?? ''));
        $phone    = preg_replace('/\D/', '', trim($_POST['phone'] ?? ''));
        $secA     = strtolower(trim($_POST['security_answer'] ?? ''));
        $defaultTab = 'forgot';

        if (!$username || !$phone || !$secA) {
            $error = 'Please fill in all three fields.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if (!$user) {
                $error = 'Username not found.';
            } elseif (empty($user['phone']) || preg_replace('/\D/', '', $user['phone']) !== $phone) {
                $error = 'Phone number does not match our records.';
            } elseif (empty($user['security_answer']) || !password_verify($secA, $user['security_answer'])) {
                $error = 'Security answer is incorrect.';
            } else {
                // All verified — allow password reset
                $_SESSION['pwd_reset_uid']  = $user['id'];
                $_SESSION['pwd_reset_time'] = time();
                $defaultTab = 'forgot';
                $success = '__STEP2__';
            }
        }
    }

    // ── FORGOT PASSWORD — Step 2: set new password ────────────
    if ($action === 'forgot_step2') {
        $defaultTab = 'forgot';
        $uid        = (int)($_SESSION['pwd_reset_uid']  ?? 0);
        $resetTime  = (int)($_SESSION['pwd_reset_time'] ?? 0);
        $newPass    = $_POST['new_password']     ?? '';
        $confPass   = $_POST['confirm_password'] ?? '';

        if (!$uid || (time() - $resetTime) > 900) { // 15-min window
            unset($_SESSION['pwd_reset_uid'], $_SESSION['pwd_reset_time']);
            $error = 'Session expired. Please start over.';
        } elseif (strlen($newPass) < 6) {
            $error   = 'Password must be at least 6 characters.';
            $success = '__STEP2__'; // keep step-2 form visible
        } elseif ($newPass !== $confPass) {
            $error   = 'Passwords do not match.';
            $success = '__STEP2__'; // keep step-2 form visible
        } else {
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
                ->execute([password_hash($newPass, PASSWORD_DEFAULT), $uid]);
            unset($_SESSION['pwd_reset_uid'], $_SESSION['pwd_reset_time']);
            $success    = 'Password reset successfully! You can now sign in.';
            $defaultTab = 'login';
        }
    }
}

// Restore step-2 state if session still valid (page refresh)
$showStep2 = false;
if (isset($_SESSION['pwd_reset_uid']) && (time() - ($_SESSION['pwd_reset_time'] ?? 0)) < 900) {
    $showStep2 = true;
}
if ($success === '__STEP2__') { $showStep2 = true; $success = ''; }

// Fetch security question for forgot step 1 (AJAX-less: show in same form)
$forgotUserQuestion = '';
if ($defaultTab === 'forgot' && !empty($_POST['username'])) {
    $tmpU = strtolower(trim($_POST['username']));
    try {
        $tmpStmt = $pdo->prepare("SELECT security_question FROM users WHERE username = ? LIMIT 1");
        $tmpStmt->execute([$tmpU]);
        $tmpRow = $tmpStmt->fetch();
        if ($tmpRow) $forgotUserQuestion = $tmpRow['security_question'];
    } catch (PDOException $e) {}
}

$pageTitle  = 'Sign In';
$activePage = 'auth';
include __DIR__ . '/includes/header.php';
?>

<style>
.auth-tabs { display:flex; border-bottom:1px solid var(--border); margin-bottom:0; }
.auth-tab  {
  flex:1; background:none; border:none; border-bottom:2px solid transparent;
  color:var(--muted); padding:10px 6px; cursor:pointer; font-family:var(--font-head);
  font-weight:600; font-size:13px; letter-spacing:.04em; transition:all .2s; margin-bottom:-1px;
}
.auth-tab.active  { color:var(--green); border-bottom-color:var(--green); }
.auth-tab:hover:not(.active) { color:var(--text); }
.tab-body { padding-top:26px; }
</style>

<div style="min-height:88vh;display:flex;align-items:center;justify-content:center;padding:40px 24px;">
  <div style="width:100%;max-width:460px;" class="animate-up">

    <div class="text-center mb-24">
      <a href="/devloom/index.php" class="nav-brand" style="justify-content:center;font-size:28px;text-decoration:none;">
        Dev<span class="text-green">loom</span>
      </a>
      <p class="text-muted mt-8 mono" style="font-size:13px;letter-spacing:.08em;">WEAVING CODE TOGETHER</p>
    </div>

    <div class="card" style="padding:32px 36px 36px;">

      <?php if ($error):   ?><div class="alert alert-error mb-20"><?= e($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="alert alert-success mb-20"><?= e($success) ?></div><?php endif; ?>

      <!-- Tabs -->
      <div class="auth-tabs mb-0">
        <button class="auth-tab <?= $defaultTab==='login'  ?'active':'' ?>" onclick="authTab('login',this)">Sign In</button>
        <button class="auth-tab <?= $defaultTab==='register'?'active':'' ?>" onclick="authTab('register',this)">Register</button>
        <button class="auth-tab <?= $defaultTab==='forgot' ?'active':'' ?>" onclick="authTab('forgot',this)">Forgot Password</button>
      </div>

      <!-- ══════════════════════════════════════════════════════
           LOGIN
      ══════════════════════════════════════════════════════ -->
      <div id="tab-login" class="tab-body" <?= $defaultTab!=='login'?'style="display:none"':'' ?>>
        <form method="POST" id="login-form" autocomplete="on"><?= csrf_field() ?>
          <input type="hidden" name="action" value="login">

          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" name="username" id="login-username" class="form-control"
                   placeholder="your_username" required autocomplete="username"
                   oninput="this.value=this.value.toLowerCase()">
          </div>

          <div class="form-group">
            <label class="form-label">Password</label>
            <div style="position:relative;">
              <input type="password" name="password" id="pw-login" class="form-control"
                     placeholder="••••••••" required autocomplete="current-password" style="padding-right:44px;">
              <button type="button" onclick="togglePw('pw-login','eye-login')" id="eye-login"
                style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                       cursor:pointer;color:var(--muted);font-size:15px;display:flex;align-items:center;justify-content:center;">👁</button>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-full" style="margin-top:6px;">Sign In →</button>

          <p class="text-center mt-14" style="font-size:12px;color:var(--muted);">
            Forgot your password?
            <a href="/devloom/reset_password.php"
               style="color:#10b981;text-decoration:underline;font-size:12px;">
              Reset it here
            </a>
          </p>
        </form>
      </div>

      <!-- ══════════════════════════════════════════════════════
           REGISTER
      ══════════════════════════════════════════════════════ -->
      <div id="tab-register" class="tab-body" <?= $defaultTab!=='register'?'style="display:none"':'' ?>>
        <form method="POST" autocomplete="off"><?= csrf_field() ?>
          <input type="hidden" name="action" value="register">

          <div class="form-group">
            <label class="form-label">Full Name <span style="color:var(--red)">*</span></label>
            <input type="text" name="name" class="form-control" placeholder="Your full name" required>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Username <span style="color:var(--red)">*</span></label>
              <input type="text" name="username" class="form-control" placeholder="e.g. arjun_dev" required
                     pattern="[a-zA-Z0-9_]{3,60}" title="3–60 chars: letters, numbers, underscores"
                     oninput="this.value=this.value.toLowerCase()">
              <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">Letters, numbers, _ · 3–60 chars</small>
            </div>
            <div class="form-group">
              <label class="form-label">Email <span style="color:var(--muted);font-size:11px;">(optional)</span></label>
              <input type="email" name="email" class="form-control" placeholder="you@email.com">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Phone Number <span style="color:var(--red)">*</span></label>
            <input type="tel" name="phone" class="form-control" placeholder="e.g. 9876543210" required autocomplete="tel">
            <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">Used for password recovery — keep it accurate.</small>
          </div>

          <div class="form-group">
            <label class="form-label">Password <span style="color:var(--red)">*</span></label>
            <div style="position:relative;">
              <input type="password" name="password" id="pw-reg" class="form-control"
                     placeholder="Min. 6 characters" required autocomplete="new-password" style="padding-right:44px;">
              <button type="button" onclick="togglePw('pw-reg','eye-reg')" id="eye-reg"
                style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                       cursor:pointer;color:var(--muted);font-size:15px;display:flex;align-items:center;justify-content:center;">👁</button>
            </div>
          </div>

          <!-- Security question for forgot-password recovery -->
          <div style="background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.15);border-radius:10px;padding:14px 16px;margin-bottom:18px;">
            <p style="font-size:12px;color:var(--green);font-weight:700;margin-bottom:10px;letter-spacing:.04em;">🔑 ACCOUNT RECOVERY (used with your phone number to reset password)</p>
            <div class="form-group" style="margin-bottom:12px;">
              <label class="form-label">Security Question <span style="color:var(--red)">*</span></label>
              <select name="security_question" class="form-control" required>
                <option value="">— Choose a question —</option>
                <option>What was the name of your first pet?</option>
                <option>What is your mother's maiden name?</option>
                <option>What city were you born in?</option>
                <option>What was the name of your primary school?</option>
                <option>What is your favourite movie?</option>
                <option>What was your childhood nickname?</option>
                <option>What street did you grow up on?</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Your Answer <span style="color:var(--red)">*</span></label>
              <input type="text" name="security_answer" class="form-control"
                     placeholder="Answer (case-insensitive)" required autocomplete="off">
              <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">
                All three (username + phone + this answer) are needed to reset your password.
              </small>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-full">Create Account →</button>
        </form>
      </div>

      <!-- ══════════════════════════════════════════════════════
           FORGOT PASSWORD
      ══════════════════════════════════════════════════════ -->
      <div id="tab-forgot" class="tab-body" <?= $defaultTab!=='forgot'?'style="display:none"':'' ?>>

        <?php if ($showStep2): ?>
          <!-- STEP 2 — Set new password -->
          <p class="text-muted mb-20" style="font-size:13px;line-height:1.6;">
            ✅ Identity verified. Enter your new password below.
          </p>
          <form method="POST" autocomplete="off"><?= csrf_field() ?>
            <input type="hidden" name="action" value="forgot_step2">

            <div class="form-group">
              <label class="form-label">New Password <span style="color:var(--red)">*</span></label>
              <div style="position:relative;">
                <input type="password" name="new_password" id="pw-f2" class="form-control"
                       placeholder="Min. 6 characters" required autocomplete="new-password" style="padding-right:44px;"
                       oninput="fStrength(this.value)">
                <button type="button" onclick="togglePw('pw-f2','eye-f2')" id="eye-f2"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                         cursor:pointer;color:var(--muted);font-size:15px;display:flex;align-items:center;justify-content:center;">👁</button>
              </div>
              <div id="f-strength-bar" style="margin-top:5px;height:4px;border-radius:2px;background:var(--border);">
                <div id="f-strength-fill" style="height:100%;width:0;border-radius:2px;transition:all .3s;"></div>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Confirm Password <span style="color:var(--red)">*</span></label>
              <div style="position:relative;">
                <input type="password" name="confirm_password" id="pw-f2c" class="form-control"
                       placeholder="Repeat new password" required autocomplete="new-password" style="padding-right:44px;"
                       oninput="fMatch()">
                <button type="button" onclick="togglePw('pw-f2c','eye-f2c')" id="eye-f2c"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                         cursor:pointer;color:var(--muted);font-size:15px;display:flex;align-items:center;justify-content:center;">👁</button>
              </div>
              <div id="f-match-lbl" style="font-size:11px;margin-top:3px;"></div>
            </div>

            <button type="submit" class="btn btn-primary btn-full">Set New Password →</button>
          </form>

        <?php else: ?>
          <!-- STEP 1 — Enter username + phone + security answer -->
          <p class="text-muted mb-20" style="font-size:13px;line-height:1.6;">
            Enter your username, phone number, and your security question answer to reset your password.
          </p>
          <form method="POST" autocomplete="off" id="forgot-form"><?= csrf_field() ?>
            <input type="hidden" name="action" value="forgot_step1">

            <div class="form-group">
              <label class="form-label">Username <span style="color:var(--red)">*</span></label>
              <input type="text" name="username" id="forgot-username" class="form-control"
                     placeholder="your_username" required autocomplete="off"
                     oninput="this.value=this.value.toLowerCase(); loadQuestion(this.value)"
                     value="<?= e($_POST['username'] ?? '') ?>">
            </div>

            <div class="form-group">
              <label class="form-label">Phone Number <span style="color:var(--red)">*</span></label>
              <input type="tel" name="phone" class="form-control"
                     placeholder="Phone number you registered with" required autocomplete="off"
                     value="<?= e($_POST['phone'] ?? '') ?>">
            </div>

            <div class="form-group" id="sq-wrap" style="<?= $forgotUserQuestion ? '' : 'display:none' ?>">
              <label class="form-label">Security Question</label>
              <div id="sq-display" class="form-control"
                   style="background:rgba(16,185,129,.06);border-color:rgba(16,185,129,.2);
                          color:var(--green);cursor:default;min-height:44px;line-height:1.5;
                          display:flex;align-items:center;">
                <?= e($forgotUserQuestion) ?>
              </div>
            </div>

            <div class="form-group" id="sa-wrap" style="<?= $forgotUserQuestion ? '' : 'display:none' ?>">
              <label class="form-label">Your Answer <span style="color:var(--red)">*</span></label>
              <input type="text" name="security_answer" class="form-control"
                     placeholder="Your answer (case-insensitive)" autocomplete="off"
                     <?= $forgotUserQuestion ? 'required' : '' ?>>
            </div>

            <button type="submit" id="forgot-submit-btn" class="btn btn-primary btn-full"
                    style="<?= $forgotUserQuestion ? '' : 'display:none' ?>">
              Verify & Continue →
            </button>

            <p id="forgot-hint" class="text-muted mt-14" style="font-size:12px;<?= $forgotUserQuestion ? 'display:none' : '' ?>">
              Type your username above to reveal your security question.
            </p>
          </form>
        <?php endif; ?>

        <p class="text-center mt-16" style="font-size:12px;color:var(--muted);">
          Remembered it?
          <button type="button" onclick="authTab('login',document.querySelectorAll('.auth-tab')[0])"
                  style="background:none;border:none;color:#10b981;cursor:pointer;font-size:12px;text-decoration:underline;">
            Sign In
          </button>
        </p>
      </div><!-- /#tab-forgot -->

    </div><!-- /.card -->
  </div>
</div>

<script>
// ── Tab switching ──────────────────────────────────────────────
function authTab(id, btn) {
  ['login','register','forgot'].forEach(function(t) {
    var el = document.getElementById('tab-' + t);
    if (el) el.style.display = (t === id) ? '' : 'none';
  });
  document.querySelectorAll('.auth-tab').forEach(function(b) { b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
}

// ── Password visibility toggle ─────────────────────────────────
function togglePw(inputId, btnId) {
  var pw  = document.getElementById(inputId);
  var eye = document.getElementById(btnId);
  if (!pw) return;
  pw.type = pw.type === 'password' ? 'text' : 'password';
  if (eye) eye.innerHTML = pw.type === 'text' ? '&#x1F648;' : '&#x1F441;';
}

// ── Load security question via fetch ──────────────────────────
var _qTimer = null;
function loadQuestion(val) {
  var wrap  = document.getElementById('sq-wrap');
  var disp  = document.getElementById('sq-display');
  var saW   = document.getElementById('sa-wrap');
  var btn   = document.getElementById('forgot-submit-btn');
  var hint  = document.getElementById('forgot-hint');
  if (!wrap) return;

  clearTimeout(_qTimer);
  if (val.length < 3) {
    wrap.style.display = 'none';
    saW.style.display  = 'none';
    if (btn)  btn.style.display  = 'none';
    if (hint) hint.style.display = '';
    return;
  }
  _qTimer = setTimeout(function() {
    fetch('/devloom/auth_question.php?u=' + encodeURIComponent(val))
      .then(function(r){ return r.json(); })
      .then(function(d) {
        if (d.question) {
          disp.textContent = d.question;
          wrap.style.display = '';
          saW.style.display  = '';
          if (btn)  btn.style.display  = '';
          if (hint) hint.style.display = 'none';
        } else {
          wrap.style.display = 'none';
          saW.style.display  = 'none';
          if (btn)  btn.style.display  = 'none';
          if (hint) { hint.style.display = ''; hint.textContent = d.error || 'Username not found.'; }
        }
      })
      .catch(function() {});
  }, 400);
}

// ── Forgot step-2 password strength ───────────────────────────
function fStrength(v) {
  var fill = document.getElementById('f-strength-fill');
  if (!fill) return;
  var s = 0;
  if (v.length >= 6)  s++;
  if (v.length >= 10) s++;
  if (/[A-Z]/.test(v)) s++;
  if (/[0-9]/.test(v)) s++;
  if (/[^A-Za-z0-9]/.test(v)) s++;
  var c = ['#ef4444','#f97316','#f59e0b','#10b981','#10b981'];
  var w = ['20%','40%','60%','80%','100%'];
  var i = v.length === 0 ? -1 : Math.max(0, Math.min(s-1, 4));
  fill.style.width      = i < 0 ? '0' : w[i];
  fill.style.background = i < 0 ? '' : c[i];
}
function fMatch() {
  var v1 = document.getElementById('pw-f2')  ? document.getElementById('pw-f2').value  : '';
  var v2 = document.getElementById('pw-f2c') ? document.getElementById('pw-f2c').value : '';
  var lbl = document.getElementById('f-match-lbl');
  if (!lbl || !v2) return;
  lbl.style.color   = v1 === v2 ? '#10b981' : '#ef4444';
  lbl.textContent   = v1 === v2 ? '✓ Passwords match' : '✗ Passwords do not match';
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
