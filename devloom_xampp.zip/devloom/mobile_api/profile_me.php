<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('GET');

$user = mobile_require_auth($pdo);
mobile_send([
    'id'            => (int)$user['id'],
    'name'          => $user['name'],
    'email'         => $user['email'],
    'username'      => $user['username'],
    'phone'         => $user['phone'] ?? '',
    'bio'           => $user['bio'] ?? '',
    'profilePhoto'  => !empty($user['profile_photo']) ? '/devloom/' . ltrim($user['profile_photo'], '/') : null,
    'role'          => 'student',
]);
