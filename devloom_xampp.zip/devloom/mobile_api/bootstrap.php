<?php
/**
 * mobile_api/bootstrap.php
 * ------------------------------------------------------------------
 * Shared bootstrap for every mobile_api/*.php endpoint.
 *
 * This is a brand-new, self-contained folder — it does NOT change any
 * existing file, table, or behaviour of the web app. It reuses the same
 * $pdo connection and password hashing as the website (config/db.php)
 * so a user's web account and app account are the same account.
 *
 * Auth model: the website uses PHP sessions (cookies). A mobile app
 * can't rely on cookies the same way, so this layer issues simple
 * bearer tokens instead (stored in the new `mobile_tokens` table).
 * Nothing about the existing session-based login is touched.
 * ------------------------------------------------------------------
 */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');
// Allow the app (and local testing from a browser/emulator) to call this API.
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── One-time auto-migration: create the two tables this API needs ──
// (Same "safe to run every request" pattern already used in config/db.php)
(function () use ($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS mobile_tokens (
        id                 INT AUTO_INCREMENT PRIMARY KEY,
        user_id            INT NOT NULL,
        access_token       VARCHAR(64) NOT NULL UNIQUE,
        refresh_token      VARCHAR(64) NOT NULL UNIQUE,
        access_expires_at  DATETIME NOT NULL,
        refresh_expires_at DATETIME NOT NULL,
        created_at         DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS device_tokens (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        user_id     INT NOT NULL,
        push_token  VARCHAR(255) NOT NULL,
        platform    VARCHAR(20) DEFAULT '',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_token (user_id, push_token),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
})();

function mobile_json_input(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function mobile_send(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function mobile_error(string $message, int $status = 400): void {
    mobile_send(['message' => $message], $status);
}

function mobile_require_method(string $method): void {
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        mobile_error('Method not allowed', 405);
    }
}

/** Creates a fresh access + refresh token pair for a user and stores it. */
function mobile_issue_tokens(PDO $pdo, int $userId): array {
    $access  = bin2hex(random_bytes(32));
    $refresh = bin2hex(random_bytes(32));
    $accessExpires  = date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30);  // 30 days
    $refreshExpires = date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 180); // 180 days
    $pdo->prepare("INSERT INTO mobile_tokens (user_id, access_token, refresh_token, access_expires_at, refresh_expires_at)
                    VALUES (?,?,?,?,?)")
        ->execute([$userId, $access, $refresh, $accessExpires, $refreshExpires]);
    return ['accessToken' => $access, 'refreshToken' => $refresh];
}

/** Returns the logged-in user's row (from the Authorization: Bearer header), or null. */
function mobile_current_user(PDO $pdo): ?array {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (!$header || stripos($header, 'Bearer ') !== 0) return null;
    $token = trim(substr($header, 7));
    if (!$token) return null;

    $stmt = $pdo->prepare("SELECT u.* FROM mobile_tokens t
                            JOIN users u ON u.id = t.user_id
                            WHERE t.access_token = ? AND t.access_expires_at > NOW() LIMIT 1");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function mobile_require_auth(PDO $pdo): array {
    $user = mobile_current_user($pdo);
    if (!$user) mobile_error('Unauthorized — please log in again.', 401);
    return $user;
}

/** Shapes a `users` row into the JSON object the app expects. */
function mobile_user_public(array $u): array {
    return [
        'id'    => (int)$u['id'],
        'name'  => $u['name'],
        'email' => $u['email'],
        'role'  => 'student',
    ];
}

/**
 * Sends a push notification to every device registered for a user, via
 * Expo's push API (works for the Expo/EAS-built APK — no Firebase project
 * of your own required). Safe to call anywhere in the app (it fails
 * silently if the user has no registered device, or if the request fails).
 */
function mobile_notify_user(PDO $pdo, int $userId, string $title, string $body, array $data = []): void {
    $stmt = $pdo->prepare("SELECT push_token FROM device_tokens WHERE user_id = ?");
    $stmt->execute([$userId]);
    $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if (!$tokens) return;

    $messages = [];
    foreach ($tokens as $t) {
        $messages[] = ['to' => $t, 'title' => $title, 'body' => $body, 'data' => $data, 'sound' => 'default'];
    }

    $ch = curl_init('https://exp.host/--/api/v2/push/send');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($messages),
        CURLOPT_TIMEOUT        => 8,
    ]);
    curl_exec($ch); // fire-and-forget — errors here shouldn't break the calling page
    curl_close($ch);
}
