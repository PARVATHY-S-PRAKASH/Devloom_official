<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('POST');

$in = mobile_json_input();
$refreshToken = trim($in['refreshToken'] ?? '');
if (!$refreshToken) mobile_error('Missing refresh token.');

$stmt = $pdo->prepare("SELECT * FROM mobile_tokens WHERE refresh_token = ? AND refresh_expires_at > NOW() LIMIT 1");
$stmt->execute([$refreshToken]);
$row = $stmt->fetch();
if (!$row) mobile_error('Session expired — please log in again.', 401);

// Rotate: issue a new access token, keep same refresh token record window simple by re-issuing both.
$pdo->prepare("DELETE FROM mobile_tokens WHERE id = ?")->execute([$row['id']]);
$tokens = mobile_issue_tokens($pdo, (int)$row['user_id']);

mobile_send([
    'accessToken'  => $tokens['accessToken'],
    'refreshToken' => $tokens['refreshToken'],
]);
