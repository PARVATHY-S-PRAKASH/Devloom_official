<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('POST');

$in   = mobile_json_input();
$name  = trim($in['name'] ?? '');
$email = trim($in['email'] ?? '');
$pass  = (string)($in['password'] ?? '');

if (!$name || !$email || !$pass) mobile_error('Name, email and password are required.');
if (strlen($pass) < 6) mobile_error('Password must be at least 6 characters.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) mobile_error('Enter a valid email address.');

$chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$chk->execute([$email]);
if ($chk->fetch()) mobile_error('An account with that email already exists.', 409);

// Build a unique username from the email, same convention the website uses.
$base = preg_replace('/[^a-zA-Z0-9_]/', '', strtolower(strstr($email, '@', true))) ?: 'user';
$username = $base;
$i = 1;
$u = $pdo->prepare("SELECT id FROM users WHERE username = ?");
while (true) {
    $u->execute([$username]);
    if (!$u->fetch()) break;
    $username = $base . $i++;
}

$pdo->prepare("INSERT INTO users (name, username, email, password, avatar) VALUES (?,?,?,?,?)")
    ->execute([$name, $username, $email, password_hash($pass, PASSWORD_DEFAULT), strtoupper(substr($name, 0, 1))]);
$userId = (int)$pdo->lastInsertId();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

$tokens = mobile_issue_tokens($pdo, $userId);
mobile_send([
    'accessToken'  => $tokens['accessToken'],
    'refreshToken' => $tokens['refreshToken'],
    'user'         => mobile_user_public($user),
], 201);
