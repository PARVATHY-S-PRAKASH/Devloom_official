<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('POST');

$user = mobile_require_auth($pdo);
$in   = mobile_json_input();
$token    = trim($in['token'] ?? '');
$platform = trim($in['platform'] ?? '');
if (!$token) mobile_error('Missing push token.');

$pdo->prepare("INSERT INTO device_tokens (user_id, push_token, platform) VALUES (?,?,?)
                ON DUPLICATE KEY UPDATE platform = VALUES(platform)")
    ->execute([$user['id'], $token, $platform]);

mobile_send(['message' => 'Device registered for notifications.']);
