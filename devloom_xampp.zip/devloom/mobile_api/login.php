<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('POST');

$in    = mobile_json_input();
$email = trim($in['email'] ?? '');
$pass  = (string)($in['password'] ?? '');
if (!$email || !$pass) mobile_error('Email and password are required.');

// Same lookup the website uses: matches by username OR email.
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR (email IS NOT NULL AND email = ?) LIMIT 1");
$stmt->execute([$email, $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($pass, $user['password'])) {
    mobile_error('Invalid email or password.', 401);
}

$tokens = mobile_issue_tokens($pdo, (int)$user['id']);
mobile_send([
    'accessToken'  => $tokens['accessToken'],
    'refreshToken' => $tokens['refreshToken'],
    'user'         => mobile_user_public($user),
]);
