<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('GET');

$user = mobile_require_auth($pdo);
$uid  = (int)$user['id'];

$stmtP = $pdo->prepare("SELECT status FROM projects WHERE user_id = ?");
$stmtP->execute([$uid]);
$statuses = $stmtP->fetchAll(PDO::FETCH_COLUMN);

$total     = count($statuses);
$completed = count(array_filter($statuses, fn($s) => $s === 'completed'));
$inProgress = count(array_filter($statuses, fn($s) => $s === 'in-progress'));

$unreadStmt = $pdo->prepare("SELECT COUNT(*) FROM user_messages WHERE user_id=? AND sender='admin' AND is_read=0");
$unreadStmt->execute([$uid]);
$unread = (int)$unreadStmt->fetchColumn();

mobile_send([
    'totalProjects'      => $total,
    'completedProjects'  => $completed,
    'inProgressProjects' => $inProgress,
    'unreadMessages'     => $unread,
    // Placement/flashcards/games activity isn't tracked in the database yet
    // in this version of the web app, so these stay at 0 until that
    // progress-tracking is added server-side.
    'streakDays'         => 0,
    'mcqsCompleted'      => 0,
    'flashcardsReviewed' => 0,
    'resumeCompletion'   => 0,
]);
