<?php
require_once __DIR__ . '/bootstrap.php';
mobile_require_method('POST');

$in    = mobile_json_input();
$email = trim($in['email'] ?? '');

// Always respond the same way whether or not the account exists, so the
// app can't be used to discover which emails are registered.
if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        // This app has no outgoing-email (SMTP) setup, so instead of a
        // "reset link" we generate a temporary password and deliver it
        // through the same in-app Messages inbox already used for
        // admin <-> user messages (visible on the website's Messages page,
        // and pushed to the phone if the user has notifications on).
        $tempPass = substr(bin2hex(random_bytes(4)), 0, 8);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
            ->execute([password_hash($tempPass, PASSWORD_DEFAULT), $user['id']]);

        $body = "Your password was reset from the Devloom app. Your temporary password is: {$tempPass}\n\nPlease log in and change it right away from Profile > Change Password.";
        $pdo->prepare("INSERT INTO user_messages (user_id, sender, subject, body, is_read) VALUES (?, 'admin', 'Password Reset', ?, 0)")
            ->execute([$user['id'], $body]);

        mobile_notify_user($pdo, (int)$user['id'], 'Password reset', 'Check your Devloom Messages for your temporary password.');
    }
}

mobile_send(['message' => 'If an account exists for that email, reset instructions have been sent.']);
