<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Learn & Play';
$activePage = 'features';
$userName = $_SESSION['user_name'] ?? 'Student';
include __DIR__ . '/includes/header.php';
?>
<style>
.fhub-hero{text-align:center;padding:48px 0 36px;}
.fhub-hero h1{font-size:clamp(1.8rem,5vw,3rem);font-weight:900;background:linear-gradient(135deg,#10b981,#14b8a6,#6ee7b7);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:10px;}
.fhub-hero p{font-size:1rem;color:#94a3b8;max-width:500px;margin:0 auto;}
.fhub-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px;margin-top:36px;padding-bottom:60px;}
.fhub-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:20px;padding:26px 22px;text-decoration:none;display:flex;flex-direction:column;gap:10px;transition:transform .2s,border-color .2s,box-shadow .2s;}
.fhub-card:hover{transform:translateY(-4px);}
.fhub-card .icon{font-size:2.6rem;line-height:1;}
.fhub-card h3{font-size:1.1rem;font-weight:800;color:#f1f5f9;margin:0;}
.fhub-card p{font-size:.85rem;color:#94a3b8;margin:0;line-height:1.6;}
.fhub-card .tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:2px;}
.fhub-card .tag{font-size:11px;padding:2px 8px;border-radius:20px;font-weight:600;}
.fhub-card .go{margin-top:auto;font-size:13px;font-weight:700;}
.c1{border-color:rgba(16,185,129,.2);}.c1:hover{border-color:rgba(16,185,129,.4);box-shadow:0 14px 40px rgba(16,185,129,.1);}.c1 .go{color:#10b981;}
.c2{border-color:rgba(245,158,11,.2);}.c2:hover{border-color:rgba(245,158,11,.4);box-shadow:0 14px 40px rgba(245,158,11,.08);}.c2 .go{color:#fbbf24;}
.c3{border-color:rgba(99,102,241,.2);}.c3:hover{border-color:rgba(99,102,241,.4);box-shadow:0 14px 40px rgba(99,102,241,.1);}.c3 .go{color:#818cf8;}
.c4{border-color:rgba(236,72,153,.2);}.c4:hover{border-color:rgba(236,72,153,.4);box-shadow:0 14px 40px rgba(236,72,153,.1);}.c4 .go{color:#f472b6;}
</style>
<div class="container">
  <div class="fhub-hero">
    <h1>🎓 Learn & Play</h1>
    <p>Welcome back, <?= e($userName) ?>! Tools to sharpen skills, prep for placements, and have fun.</p>
  </div>
  <div class="fhub-grid">
    <a href="/devloom/placement.php" class="fhub-card c1">
      <div class="icon">🏆</div>
      <h3>Placement Prep</h3>
      <p>Topic-wise MCQs on Aptitude, SQL, Java, Python, HR + AI Mock Interviews. Ace your campus placement.</p>
      <div class="tags">
        <span class="tag" style="background:rgba(16,185,129,.12);color:#6ee7b7;">Aptitude</span>
        <span class="tag" style="background:rgba(16,185,129,.12);color:#6ee7b7;">Mock Interview</span>
        <span class="tag" style="background:rgba(16,185,129,.12);color:#6ee7b7;">HR</span>
      </div>
      <span class="go">Start Prep →</span>
    </a>
    <a href="/devloom/resume.php" class="fhub-card c2">
      <div class="icon">📄</div>
      <h3>Resume Builder</h3>
      <p>Build a professional resume instantly. Fill details, live preview, choose themes, download as PDF.</p>
      <div class="tags">
        <span class="tag" style="background:rgba(245,158,11,.12);color:#fbbf24;">Live Preview</span>
        <span class="tag" style="background:rgba(245,158,11,.12);color:#fbbf24;">4 Themes</span>
        <span class="tag" style="background:rgba(245,158,11,.12);color:#fbbf24;">PDF Download</span>
      </div>
      <span class="go">Build Resume →</span>
    </a>
    <a href="/devloom/challenges.php" class="fhub-card c3">
      <div class="icon">📚</div>
      <h3>Study Hub</h3>
      <p>Flashcards, MCQ quizzes, typing speed tests &amp; Pomodoro timer. Everything you need to study smarter.</p>
      <div class="tags">
        <span class="tag" style="background:rgba(99,102,241,.12);color:#a5b4fc;">Flashcards</span>
        <span class="tag" style="background:rgba(99,102,241,.12);color:#a5b4fc;">MCQ Quiz</span>
        <span class="tag" style="background:rgba(99,102,241,.12);color:#a5b4fc;">Pomodoro</span>
      </div>
      <span class="go">Study Now →</span>
    </a>
    <a href="/devloom/games.php" class="fhub-card c4">
      <div class="icon">🎮</div>
      <h3>Fun Zone</h3>
      <p>Snake (3 speeds), 2048, Jelly Hole, Memory Match, Word Search, Traffic Escape & Fruit Link!</p>
      <div class="tags">
        <span class="tag" style="background:rgba(236,72,153,.12);color:#f472b6;">7 Games</span>
        <span class="tag" style="background:rgba(236,72,153,.12);color:#f472b6;">High Scores</span>
        <span class="tag" style="background:rgba(236,72,153,.12);color:#f472b6;">Play Free</span>
      </div>
      <span class="go">Play Now →</span>
    </a>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
