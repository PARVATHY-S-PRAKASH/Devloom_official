<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Placement Prep';
$activePage = 'features';
$hasKey = defined('ANTHROPIC_API_KEY') && ANTHROPIC_API_KEY !== 'YOUR_API_KEY_HERE';
include __DIR__ . '/includes/header.php';
?>
<style>
.pl-wrap{max-width:860px;margin:0 auto;padding:36px 0 80px;}
.pl-header{text-align:center;margin-bottom:28px;}
.pl-header h1{font-size:2.1rem;font-weight:900;color:#f1f5f9;margin-bottom:8px;}
.mod-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:24px;}
.mod-btn{padding:16px 10px;border:1.5px solid rgba(255,255,255,.09);border-radius:14px;background:rgba(255,255,255,.03);cursor:pointer;text-align:center;transition:all .2s;color:#cbd5e1;font-weight:600;}
.mod-btn:hover,.mod-btn.active{border-color:rgba(245,158,11,.4);background:rgba(245,158,11,.08);color:#fbbf24;}
.mod-btn .mi{font-size:1.7rem;display:block;margin-bottom:5px;}
.mod-btn span{font-size:12px;}
#quiz-panel{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:26px;display:none;}
#quiz-panel.show{display:block;}
.q-text{font-size:1rem;font-weight:700;color:#f1f5f9;margin-bottom:18px;line-height:1.6;}
.opt-list{display:flex;flex-direction:column;gap:8px;margin-bottom:16px;}
.opt{padding:12px 16px;border:1.5px solid rgba(255,255,255,.1);border-radius:10px;background:transparent;color:#cbd5e1;text-align:left;cursor:pointer;font-size:.88rem;transition:all .2s;width:100%;}
.opt:hover:not(:disabled){border-color:rgba(245,158,11,.4);background:rgba(245,158,11,.06);color:#fbbf24;}
.opt.correct{border-color:#10b981!important;background:rgba(16,185,129,.1)!important;color:#6ee7b7!important;}
.opt.wrong{border-color:#ef4444!important;background:rgba(239,68,68,.09)!important;color:#f87171!important;}
.fb{background:rgba(0,0,0,.2);border-radius:9px;padding:12px 15px;font-size:.85rem;color:#94a3b8;line-height:1.7;display:none;margin-bottom:14px;}
.prog-bar{height:5px;background:rgba(255,255,255,.07);border-radius:3px;margin-bottom:20px;overflow:hidden;}
.prog-fill{height:100%;background:linear-gradient(90deg,#f59e0b,#fbbf24);border-radius:3px;transition:width .4s;}
#score-panel{display:none;text-align:center;padding:32px 16px;}
.sc-big{font-size:3rem;font-weight:900;color:#fbbf24;}
#mock-panel{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;overflow:hidden;display:none;}
#mock-panel.show{display:block;}
.mock-tabs{padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;gap:8px;flex-wrap:wrap;}
.mock-tab{padding:7px 14px;border:1.5px solid rgba(255,255,255,.12);border-radius:8px;background:transparent;color:#94a3b8;cursor:pointer;font-size:.82rem;font-weight:600;transition:all .2s;}
.mock-tab:hover{border-color:rgba(245,158,11,.4);color:#fbbf24;}
.mock-tab.active{border-color:rgba(245,158,11,.5);background:rgba(245,158,11,.1);color:#fbbf24;}
.m-chat{height:340px;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;}
.m-chat::-webkit-scrollbar{width:4px;}.m-chat::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);}
.mb{padding:11px 14px;border-radius:12px;font-size:.88rem;line-height:1.7;max-width:82%;}
.mb-ai{background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.15);color:#e2e8f0;border-radius:4px 12px 12px 12px;}
.mb-ai strong{color:#fbbf24;}
.mb-ai em{color:#94a3b8;font-size:.82rem;}
.mb-user{background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.15);color:#e2e8f0;border-radius:12px 4px 12px 12px;margin-left:auto;}
.mock-input-row{display:flex;gap:8px;padding:12px 14px;border-top:1px solid rgba(255,255,255,.07);}
.mock-inp{flex:1;background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.09);border-radius:9px;color:#e2e8f0;padding:9px 13px;font-size:.88rem;font-family:inherit;outline:none;}
.mock-inp:focus{border-color:rgba(245,158,11,.4);}
.dot{display:inline-block;width:5px;height:5px;border-radius:50%;background:#f59e0b;margin:0 2px;animation:blink 1.2s infinite;}
.dot:nth-child(2){animation-delay:.2s;}.dot:nth-child(3){animation-delay:.4s;}
@keyframes blink{0%,80%,100%{opacity:.2}40%{opacity:1}}
</style>

<div class="container">
<div class="pl-wrap">
  <div class="pl-header">
    <h1>🏆 Placement Preparation</h1>
    <p style="color:#94a3b8;">Topic-wise MCQs + Mock Interviews. Ace your campus placement!</p>
  </div>

  <div class="mod-grid">
    <button class="mod-btn" onclick="loadMod('aptitude',this)"><span class="mi">🔢</span><span>Aptitude</span></button>
    <button class="mod-btn" onclick="loadMod('quant',this)"><span class="mi">📐</span><span>Quantitative</span></button>
    <button class="mod-btn" onclick="loadMod('logical',this)"><span class="mi">🧩</span><span>Logical Reasoning</span></button>
    <button class="mod-btn" onclick="loadMod('technical',this)"><span class="mi">💻</span><span>Technical CS</span></button>
    <button class="mod-btn" onclick="loadMod('sql',this)"><span class="mi">🗄</span><span>SQL</span></button>
    <button class="mod-btn" onclick="loadMod('java',this)"><span class="mi">☕</span><span>Java</span></button>
    <button class="mod-btn" onclick="loadMod('python',this)"><span class="mi">🐍</span><span>Python</span></button>
    <button class="mod-btn" onclick="loadMod('hr',this)"><span class="mi">🤝</span><span>HR Questions</span></button>
    <button class="mod-btn" onclick="loadMod('mock',this)"><span class="mi">🎙</span><span>Mock Interview</span></button>
  </div>

  <div id="placeholder" style="text-align:center;color:#64748b;padding:48px;background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.08);border-radius:16px;">
    👆 Select a module above to begin
  </div>

  <!-- MCQ Panel -->
  <div id="quiz-panel">
    <div class="prog-bar"><div class="prog-fill" id="prog-fill" style="width:0%"></div></div>
    <div id="q-num" style="font-size:11px;font-family:monospace;color:#64748b;margin-bottom:10px;"></div>
    <div class="q-text" id="q-text"></div>
    <div class="opt-list" id="opt-list"></div>
    <div class="fb" id="fb"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;">
      <span id="live-sc" style="font-size:12px;color:#64748b;"></span>
      <button id="nxt-btn" class="btn btn-primary btn-sm" style="display:none;" onclick="nextQ()">Next →</button>
    </div>
    <div id="score-panel">
      <div class="sc-big" id="sc-big"></div>
      <div style="color:#94a3b8;margin:6px 0 14px;">Final Score</div>
      <div id="sc-msg" style="font-size:14px;color:#e2e8f0;margin-bottom:18px;"></div>
      <button class="btn btn-primary" id="retry-btn">🔄 Retry</button>
    </div>
  </div>

  <!-- Mock Interview Panel -->
  <div id="mock-panel">
    <div class="mock-tabs">
      <button class="mock-tab" onclick="startMock('fresher',this)">🎓 Fresher</button>
      <button class="mock-tab" onclick="startMock('experienced',this)">💼 Experienced</button>
      <button class="mock-tab" onclick="startMock('hr',this)">🤝 HR Round</button>
      <button class="mock-tab" onclick="startMock('technical',this)">⚙ Technical</button>
    </div>
    <div class="m-chat" id="m-chat">
      <div style="text-align:center;color:#64748b;font-size:13px;margin:auto;">Select an interview type above 👆</div>
    </div>
    <div class="mock-input-row">
      <input id="m-inp" class="mock-inp" placeholder="Your answer… (Enter to send)" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendMock();}">
      <button class="btn btn-primary btn-sm" onclick="sendMock()">Send</button>
    </div>
  </div>

</div>
</div>

<script>
// ─── MCQ Question Bank ────────────────────────────────────────────────────────
var QS = {
  aptitude:[
    {q:"A train 150m long passes a pole in 10s. Speed?",o:["15 m/s","12 m/s","10 m/s","20 m/s"],a:0,e:"Speed = distance/time = 150/10 = 15 m/s"},
    {q:"20% of a number is 40. Find the number.",o:["200","160","180","220"],a:0,e:"x × 20/100 = 40 → x = 200"},
    {q:"5 people around a circular table — arrangements?",o:["24","120","60","720"],a:0,e:"Circular permutation = (n-1)! = 4! = 24"},
    {q:"A does work in 15 days, B in 20 days. Together?",o:["8.57 days","10 days","7 days","12 days"],a:0,e:"Combined rate = 1/15 + 1/20 = 7/60 → 60/7 ≈ 8.57 days"},
    {q:"SI on Rs 1500 for 2 yrs at 5%?",o:["Rs 150","Rs 200","Rs 175","Rs 125"],a:0,e:"SI = P×R×T/100 = 1500×5×2/100 = Rs 150"},
    {q:"What % of 80 is 20?",o:["25%","20%","15%","30%"],a:0,e:"(20/80) × 100 = 25%"},
    {q:"CI on Rs 1000 at 10% for 2 years?",o:["Rs 210","Rs 200","Rs 220","Rs 100"],a:0,e:"CI = 1000×(1.1)² − 1000 = 1210 − 1000 = Rs 210"},
    {q:"A boat speed is 8 km/h, stream 2 km/h. Upstream speed?",o:["6 km/h","10 km/h","4 km/h","8 km/h"],a:0,e:"Upstream = boat speed − stream speed = 8 − 2 = 6 km/h"},
    {q:"A can do a job in 10 days. B in 15 days. Together in?",o:["6 days","5 days","8 days","4 days"],a:0,e:"Combined rate = 1/10 + 1/15 = 1/6 → 6 days"},
    {q:"Profit when CP=200 and SP=250?",o:["25%","20%","30%","15%"],a:0,e:"Profit% = (50/200) × 100 = 25%"}
  ],
  quant:[
    {q:"LCM of 12, 18, 24?",o:["72","36","48","144"],a:0,e:"LCM(12,18,24) = 72"},
    {q:"√0.0081 = ?",o:["0.09","0.9","0.009","0.81"],a:0,e:"√(81/10000) = 9/100 = 0.09"},
    {q:"Sum of first 10 natural numbers?",o:["55","50","45","60"],a:0,e:"n(n+1)/2 = 10×11/2 = 55"},
    {q:"x+y=10, xy=21. Find x²+y².",o:["58","100","42","79"],a:0,e:"x²+y² = (x+y)² − 2xy = 100 − 42 = 58"},
    {q:"Smallest number ÷3,5,7 leaves remainder 1?",o:["106","105","211","104"],a:0,e:"LCM(3,5,7) = 105, then +1 = 106"},
    {q:"(a+b)² = ?",o:["a²+2ab+b²","a²+b²","a²-2ab+b²","2a+2b"],a:0,e:"Standard algebraic identity: a²+2ab+b²"},
    {q:"HCF of 36 and 48?",o:["12","6","18","24"],a:0,e:"36 = 2²×3², 48 = 2⁴×3. HCF = 2²×3 = 12"},
    {q:"3/4 + 5/6 = ?",o:["19/12","8/10","2/3","4/5"],a:0,e:"LCM = 12: 9/12 + 10/12 = 19/12"},
    {q:"What is 15% of 240?",o:["36","32","40","24"],a:0,e:"240 × 15/100 = 36"},
    {q:"If 2x-3=7, then x=?",o:["5","4","6","3"],a:0,e:"2x = 10 → x = 5"}
  ],
  logical:[
    {q:"Series: 2, 6, 12, 20, 30, ?",o:["42","40","44","38"],a:0,e:"Differences: 4,6,8,10,12 → next = 30+12 = 42"},
    {q:"ABCD : DCBA :: MNOP : ?",o:["PONM","NMOP","PNMO","OPNM"],a:0,e:"Pattern is reversal → PONM"},
    {q:"Odd one out: 2, 3, 5, 7, 9, 11",o:["9","3","5","11"],a:0,e:"9 = 3×3, not prime. All others are prime numbers."},
    {q:"Series: 1, 4, 9, 16, 25, ?",o:["36","35","49","30"],a:0,e:"Perfect squares: 1²,2²,3²,4²,5²,6² → 36"},
    {q:"A > B, C < A, B > C. Who is shortest?",o:["C","B","A","Cannot determine"],a:0,e:"Order: A > B > C, so C is shortest"},
    {q:"Monday = day 2. What is day 9?",o:["Monday","Sunday","Tuesday","Wednesday"],a:0,e:"Day 2 + 7 = Day 9 = Monday (7-day cycle)"},
    {q:"'His mother is only daughter of my mother.' Relation?",o:["Mother","Sister","Aunt","Daughter"],a:0,e:"Only daughter of my mother = myself → she is his mother"},
    {q:"Find the missing: 3, 6, 11, 18, 27, ?",o:["38","36","40","42"],a:0,e:"Differences: 3,5,7,9,11 → 27+11 = 38"},
    {q:"If CAT=24, DOG=?",o:["26","27","25","28"],a:0,e:"C=3,A=1,T=20 → 24. D=4,O=15,G=7 → 26"},
    {q:"All roses are flowers. Some flowers are red. Therefore?",o:["Some roses may be red","All roses are red","No roses are red","All flowers are roses"],a:0,e:"Some roses can be red — standard syllogism, not definitive."}
  ],
  technical:[
    {q:"Time complexity of Binary Search?",o:["O(log n)","O(n)","O(n²)","O(1)"],a:0,e:"Halves search space each step → O(log n)"},
    {q:"Which data structure uses LIFO?",o:["Stack","Queue","Tree","Graph"],a:0,e:"Stack = Last In, First Out"},
    {q:"OSI layer handling routing?",o:["Network Layer","Transport","Data Link","Session"],a:0,e:"Network Layer (Layer 3) handles IP routing"},
    {q:"What is a primary key?",o:["Uniquely identifies each row","Can have NULL","Can repeat","Is a foreign key"],a:0,e:"Primary key: unique, not null, one per table"},
    {q:"Merge Sort worst case complexity?",o:["O(n log n)","O(n²)","O(n)","O(log n)"],a:0,e:"Merge Sort is always O(n log n)"},
    {q:"What is deadlock?",o:["Processes waiting for each other forever","Memory overflow","CPU overload","Network failure"],a:0,e:"Deadlock: circular wait — each process holds a resource the other needs"},
    {q:"HTTP stands for?",o:["HyperText Transfer Protocol","High Transfer Text","Hyper Token Protocol","None"],a:0,e:"HTTP = HyperText Transfer Protocol"},
    {q:"Which is NOT volatile memory?",o:["ROM","RAM","Cache","Register"],a:0,e:"ROM retains data without power — it is non-volatile"},
    {q:"What does SQL stand for?",o:["Structured Query Language","Simple Query Language","Standard Query Logic","Sequential Query Language"],a:0,e:"SQL = Structured Query Language"},
    {q:"Which sorting has best average complexity?",o:["Quick Sort O(n log n)","Bubble Sort O(n²)","Selection Sort O(n²)","Insertion Sort O(n²)"],a:0,e:"Quick Sort averages O(n log n)"}
  ],
  sql:[
    {q:"SQL command to retrieve data?",o:["SELECT","INSERT","UPDATE","DELETE"],a:0,e:"SELECT retrieves rows from a table"},
    {q:"What does DISTINCT do?",o:["Removes duplicate rows","Sorts rows","Groups rows","Filters rows"],a:0,e:"SELECT DISTINCT returns only unique values"},
    {q:"Which join = all from left + matched from right?",o:["LEFT JOIN","INNER JOIN","RIGHT JOIN","FULL JOIN"],a:0,e:"LEFT JOIN returns all records from left table"},
    {q:"Clause to filter groups?",o:["HAVING","WHERE","GROUP BY","ORDER BY"],a:0,e:"HAVING filters after grouping; WHERE filters before aggregation"},
    {q:"Add column to existing table?",o:["ALTER TABLE ... ADD COLUMN","ADD COLUMN","INSERT COLUMN","UPDATE TABLE"],a:0,e:"ALTER TABLE tbl ADD COLUMN col datatype"},
    {q:"What is a foreign key?",o:["References PK of another table","Unique key","Auto-increment","Composite key"],a:0,e:"Foreign key enforces referential integrity between tables"},
    {q:"COUNT(*) counts?",o:["All rows including NULL","Non-NULL only","Only distinct rows","None"],a:0,e:"COUNT(*) counts every row, including NULLs"},
    {q:"Which command deletes all rows but keeps table?",o:["TRUNCATE","DROP","DELETE","REMOVE"],a:0,e:"TRUNCATE removes all rows but keeps structure; DROP removes the whole table"},
    {q:"What does GROUP BY do?",o:["Groups rows by column for aggregation","Sorts ascending","Filters rows","Joins tables"],a:0,e:"GROUP BY groups rows with same value for use with aggregate functions"},
    {q:"Enforce uniqueness besides PK?",o:["UNIQUE constraint","CHECK constraint","NOT NULL","DEFAULT"],a:0,e:"UNIQUE constraint ensures no duplicate values in a column"}
  ],
  java:[
    {q:"Keyword for inheritance in Java?",o:["extends","inherits","implements","super"],a:0,e:"'extends' is used for class inheritance in Java"},
    {q:"Size of int in Java?",o:["4 bytes","2 bytes","8 bytes","Platform dependent"],a:0,e:"int is always 4 bytes in Java (unlike C/C++)"},
    {q:"Which is NOT an OOP pillar?",o:["Compilation","Encapsulation","Inheritance","Polymorphism"],a:0,e:"4 pillars: Encapsulation, Inheritance, Polymorphism, Abstraction"},
    {q:"JVM stands for?",o:["Java Virtual Machine","Java Variable Method","Java Verified Module","None"],a:0,e:"JVM executes Java bytecode on any platform — write once run anywhere"},
    {q:"'final' keyword on method prevents?",o:["Method overriding","Inheritance","Instantiation","Compilation"],a:0,e:"final method cannot be overridden by a subclass"},
    {q:"Exception handling keywords in Java?",o:["try/catch/finally","try/except","begin/rescue","error/handle"],a:0,e:"Java uses try, catch, finally, throw, throws"},
    {q:"ArrayList vs Array — key difference?",o:["ArrayList is dynamic size","Array is faster always","Both same","ArrayList is static"],a:0,e:"ArrayList grows dynamically; arrays have fixed size at creation"},
    {q:"What is an interface in Java?",o:["Abstract type with method signatures","A class","A data type","A loop"],a:0,e:"Interface defines a contract — method signatures without body (pre-Java 8)"},
    {q:"Most restrictive access modifier?",o:["private","protected","public","default"],a:0,e:"private is only accessible within the same class"},
    {q:"String is ___ in Java?",o:["Immutable","Mutable","Primitive","None"],a:0,e:"Strings are immutable — any change creates a new String object"}
  ],
  python:[
    {q:"Output of type([])?",o:["<class 'list'>","<class 'array'>","list","[]"],a:0,e:"type([]) returns <class 'list'>"},
    {q:"Which is mutable?",o:["List","Tuple","String","Frozenset"],a:0,e:"Lists are mutable; tuples, strings, frozensets are immutable"},
    {q:"PEP 8 is?",o:["Python style guide","Error Protocol","Package Manager","Extension"],a:0,e:"PEP 8 is Python's official coding style guide"},
    {q:"List comprehension for squares 1-5?",o:["[x**2 for x in range(1,6)]","[x^2 for x in 1..5]","list(x*x,range(5))","(x**2 for x in range(5))"],a:0,e:"[x**2 for x in range(1,6)] = [1, 4, 9, 16, 25]"},
    {q:"Open file for reading?",o:["open('f','r')","read('f')","file.open('r')","open('f','w')"],a:0,e:"open(filename, 'r') opens in read mode"},
    {q:"Exception handling in Python?",o:["try/except","try/catch","error/handle","begin/rescue"],a:0,e:"Python uses try/except (Java uses try/catch)"},
    {q:"What is a lambda in Python?",o:["Anonymous one-line function","A loop","A class","A module"],a:0,e:"lambda x: x+1 — anonymous function with a single expression"},
    {q:"Keyword used for a generator function?",o:["yield","return","generate","produce"],a:0,e:"yield makes a function a generator, returning values lazily"},
    {q:"How to shallow copy a list?",o:["list.copy() or list[:]","list=other","copy(list)","list.clone()"],a:0,e:"list.copy() or slicing [:] creates a shallow copy"},
    {q:"What does *args allow?",o:["Variable positional arguments","Variable keyword args","List unpacking","None"],a:0,e:"*args collects any number of positional arguments into a tuple"}
  ],
  hr:[
    {q:"Best structure for 'Tell me about yourself'?",o:["Present→Past→Future","Only past","Only hobbies","Read CV aloud"],a:0,e:"Present (current skills) → Past (experience) → Future (goals). Under 2 min."},
    {q:"'Greatest weakness' — best strategy?",o:["Real weakness + how you're improving","Say 'I work too hard'","Claim no weakness","Change topic"],a:0,e:"Be honest about a real weakness and show steps you're taking to improve"},
    {q:"'Why should we hire you?' focuses on?",o:["Your unique value to company","Salary needs","Criticizing others","Personal goals only"],a:0,e:"Highlight specific skills and how they directly benefit the company"},
    {q:"Best question to ask the interviewer?",o:["What does success look like here?","What's the salary?","Do I get WFH?","How many leaves?"],a:0,e:"Questions about success criteria show genuine interest in doing well"},
    {q:"'5 years from now' — what to AVOID saying?",o:["'In your position'","Mention growth goals","Align with company vision","Show ambition"],a:0,e:"Never imply you want the interviewer's job"},
    {q:"Most important body language in interviews?",o:["Eye contact + upright posture","Folded arms","Looking at notes","Leaning back"],a:0,e:"Eye contact shows confidence; upright posture shows engagement"},
    {q:"How to answer a behavioral question?",o:["STAR method","Tell a long story","Give only the result","Skip with 'I don't know'"],a:0,e:"STAR = Situation, Task, Action, Result — structured storytelling"},
    {q:"What to do if you don't know an answer?",o:["Acknowledge and describe your thinking","Guess randomly","Stay silent","Change the subject"],a:0,e:"Saying 'I'd approach it by...' demonstrates problem-solving ability"}
  ]
};

// ─── Mock Interview Question Bank ─────────────────────────────────────────────
var MOCK_QA = {
  fresher:[
    {q:"Tell me about yourself.",fb:"Great start! Keep your introduction under 2 minutes — present, past, then goals.",tip:"Structure: current skills → education background → what you're seeking."},
    {q:"Why did you choose this field / your degree?",fb:"Good answer! Showing genuine passion makes you stand out from other candidates.",tip:"Mention a specific moment or project that first sparked your interest."},
    {q:"What are your strengths?",fb:"Well expressed! Always back strengths with a brief real-life example.",tip:"Pick 2-3 strengths relevant to the role and support each with evidence."},
    {q:"What is your greatest weakness?",fb:"Nice approach! Interviewers appreciate self-awareness and the drive to improve.",tip:"Name a real weakness, then describe what you're actively doing to fix it."},
    {q:"Describe a challenging project you worked on.",fb:"Good use of structure! Focus on your specific contribution to the outcome.",tip:"Use STAR: Situation → Task → Action → Result. Quantify if possible."},
    {q:"Where do you see yourself in 5 years?",fb:"Solid answer! Align your goals with the company's growth direction.",tip:"Show ambition but stay realistic — mention skills you want to build here."},
    {q:"Why do you want to work for our company?",fb:"Excellent! Researching the company before the interview always scores points.",tip:"Mention something specific — a product, their culture, or a recent achievement."},
    {q:"How do you handle pressure or tight deadlines?",fb:"Great! A concrete example always makes your answer far more credible.",tip:"Describe your prioritisation method and stay calm in your delivery."},
    {q:"Tell me about a time you worked in a team.",fb:"Good teamwork example! Emphasise your personal contribution to the outcome.",tip:"Use STAR and highlight communication, conflict resolution, or leadership."},
    {q:"Do you have any questions for us?",fb:"Always ask at least one thoughtful question — it shows genuine interest!",tip:"Try: 'What does success look like in this role in the first 90 days?'"}
  ],
  experienced:[
    {q:"Walk me through your career journey so far.",fb:"Good overview! Highlight transitions that show growth and responsibility.",tip:"Keep it 2-3 minutes: present → key milestones → current expertise."},
    {q:"What has been your most impactful project, and what was your role?",fb:"Strong example! Quantifying business impact (revenue, time saved) is key.",tip:"Lead with the outcome first, then walk through how you achieved it."},
    {q:"Describe a time you led a team through a difficult situation.",fb:"Good leadership story! Focus on your decision-making process and outcome.",tip:"Show empathy, clear communication, and the measurable result."},
    {q:"How do you manage competing priorities across multiple projects?",fb:"Solid! Mentioning frameworks like OKRs or Kanban adds credibility.",tip:"Describe your actual system and how you communicate trade-offs to stakeholders."},
    {q:"Tell me about a time you disagreed with a manager or stakeholder.",fb:"Brave and well-handled! Respectful pushback is a sign of maturity.",tip:"Focus on data-driven persuasion and the outcome — not the conflict itself."},
    {q:"What is the most complex technical problem you have solved?",fb:"Impressive! Breaking down your thought process shows senior-level reasoning.",tip:"Explain the problem clearly for a non-technical audience, then go deep."},
    {q:"How do you stay current with industry trends?",fb:"Good answer! Specific resources — blogs, conferences, side projects — make it real.",tip:"Mention something recent you learned and describe how you applied it."},
    {q:"How do you mentor junior team members?",fb:"Great approach! Structured mentoring is highly valued at senior levels.",tip:"Give a concrete example — code reviews, pair programming, regular 1-on-1s."},
    {q:"Why are you looking for a new opportunity right now?",fb:"Well handled! Always frame your reason positively — growth, not escape.",tip:"Focus on what you are moving toward, not what you are leaving behind."},
    {q:"What salary range are you expecting?",fb:"Good! Researching market rates beforehand shows professionalism and confidence.",tip:"Give a range based on market data and your experience level — stay flexible."}
  ],
  hr:[
    {q:"Tell me about yourself.",fb:"Good start! HR wants personality and culture fit, not just your resume.",tip:"Include something personal that shows who you are beyond your job title."},
    {q:"Why do you want to leave your current company?",fb:"Well handled! Always stay positive — never badmouth your current employer.",tip:"Focus on growth opportunities, new challenges, or alignment with career goals."},
    {q:"How do you handle conflict with a colleague?",fb:"Great answer! Calm, direct communication is exactly what HR wants to see.",tip:"Use a real example. Show you addressed it privately, respectfully, and early."},
    {q:"Are you a team player or do you prefer working independently?",fb:"Good balance! The best answers show you adapt to both situations.",tip:"Give an example of each — demonstrate situational awareness."},
    {q:"How do you react to criticism or negative feedback?",fb:"Solid! Welcoming feedback and acting on it reflects high emotional intelligence.",tip:"Give an example where feedback genuinely improved your work or approach."},
    {q:"Describe your ideal work environment.",fb:"Good self-awareness! Research the company culture before your actual interview.",tip:"Align your preference with clues from the job description and company values."},
    {q:"What motivates you at work?",fb:"Great answer! Intrinsic motivators impress more than just salary or perks.",tip:"Be honest — interviewers detect generic answers easily. Tie it to a real example."},
    {q:"How do you manage work-life balance?",fb:"Well said! Showing you're sustainable long-term is a green flag for employers.",tip:"Mention boundaries you actively set and how they help your productivity."},
    {q:"Are you comfortable relocating or traveling for work?",fb:"Clear and honest answer! Transparency about constraints avoids problems later.",tip:"If there are limits, state them calmly and professionally."},
    {q:"What are your long-term career goals?",fb:"Impressive! Showing alignment with the company's direction signals commitment.",tip:"Be specific and tie your goals to skills this role will help you develop."}
  ],
  technical:[
    {q:"Explain the difference between a stack and a queue.",fb:"Correct! Knowing real-world use cases for LIFO vs FIFO makes your answer stand out.",tip:"Stack = undo operations, call stack. Queue = print jobs, BFS traversal."},
    {q:"What is the difference between HTTP and HTTPS?",fb:"Good explanation! Mentioning TLS/SSL and port 443 shows deeper understanding.",tip:"HTTPS encrypts data in transit using SSL/TLS; HTTP sends plain text."},
    {q:"What happens when you type a URL in a browser?",fb:"Excellent systems knowledge! DNS, TCP, and rendering flow all matter here.",tip:"DNS lookup → TCP handshake → HTTP request → server response → DOM render."},
    {q:"What is the difference between a process and a thread?",fb:"Good answer! The shared-memory distinction is the most important point.",tip:"Process = isolated execution unit. Thread = lightweight subprocess sharing process memory."},
    {q:"Explain REST API and its key principles.",fb:"Well explained! Deep knowledge of statelessness impresses technical interviewers.",tip:"REST: stateless, client-server, cacheable, uniform interface, layered system."},
    {q:"What is Big O notation and why does it matter?",fb:"Solid answer! Comparing O(n²) bubble sort vs O(n log n) merge sort adds real value.",tip:"Big O describes how an algorithm's time or space scales with input size n."},
    {q:"What is database indexing and when would you use it?",fb:"Good! The read/write trade-off shows real database experience.",tip:"Index speeds up SELECT queries but slows INSERT/UPDATE. Use on frequently queried columns."},
    {q:"Explain the four pillars of OOP.",fb:"Great explanation! A concrete code analogy like a Car class always helps.",tip:"Encapsulation, Abstraction, Inheritance, Polymorphism — know an example of each."},
    {q:"What is the difference between SQL and NoSQL databases?",fb:"Good comparison! Knowing which to pick for a given use case impresses interviewers.",tip:"SQL: structured, relational, ACID compliant. NoSQL: flexible schema, horizontal scaling."},
    {q:"How would you reverse a string? Explain your approach.",fb:"Well done! Mentioning edge cases like empty string or Unicode shows attention to detail.",tip:"Python: s[::-1]. JS: s.split('').reverse().join(''). Or a simple loop for O(n)."}
  ]
};

// ─── State Variables ───────────────────────────────────────────────────────────
var curMod = '', curQs = [], cIdx = 0, cScore = 0, answered = false;
var _activeModBtn = null;
var mockType = '', mockQIdx = 0;

// ─── MCQ Functions ─────────────────────────────────────────────────────────────
function shuffleQ(q) {
  var opts = q.o.map(function(text, i){ return {text: text, correct: i === q.a}; });
  for (var i = opts.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var tmp = opts[i]; opts[i] = opts[j]; opts[j] = tmp;
  }
  return {q: q.q, o: opts.map(function(x){ return x.text; }), a: opts.findIndex(function(x){ return x.correct; }), e: q.e};
}

function loadMod(mod, btn) {
  if (_activeModBtn) _activeModBtn.classList.remove('active');
  if (btn) { btn.classList.add('active'); _activeModBtn = btn; }
  curMod = mod;
  document.getElementById('placeholder').style.display = 'none';
  document.getElementById('mock-panel').classList.remove('show');
  document.getElementById('quiz-panel').classList.remove('show');
  document.getElementById('score-panel').style.display = 'none';

  if (mod === 'mock') {
    document.getElementById('mock-panel').classList.add('show');
    document.getElementById('m-chat').innerHTML = '<div style="text-align:center;color:#64748b;font-size:13px;margin:auto;">Select an interview type above 👆</div>';
    return;
  }

  var raw = QS[mod];
  if (!raw || !raw.length) { alert('Questions coming soon for this topic!'); return; }
  var shuffled = raw.slice().sort(function(){ return Math.random() - 0.5; });
  curQs = shuffled.slice(0, Math.min(shuffled.length, 8)).map(shuffleQ);
  cIdx = 0; cScore = 0; answered = false;
  document.getElementById('quiz-panel').classList.add('show');
  renderQ();
}

function renderQ() {
  if (cIdx >= curQs.length) { showScore(); return; }
  var q = curQs[cIdx]; answered = false;
  document.getElementById('q-num').textContent = 'Question ' + (cIdx + 1) + ' of ' + curQs.length;
  document.getElementById('q-text').textContent = q.q;
  document.getElementById('prog-fill').style.width = (cIdx / curQs.length * 100) + '%';
  document.getElementById('fb').style.display = 'none';
  document.getElementById('nxt-btn').style.display = 'none';
  document.getElementById('live-sc').textContent = 'Score: ' + cScore + '/' + cIdx;
  var ol = document.getElementById('opt-list'); ol.innerHTML = '';
  var letters = ['A', 'B', 'C', 'D'];
  q.o.forEach(function(o, i) {
    var b = document.createElement('button');
    b.className = 'opt';
    b.textContent = letters[i] + '. ' + o;
    b.onclick = (function(idx, qq){ return function(){ checkAns(idx, qq); }; })(i, q);
    ol.appendChild(b);
  });
}

function checkAns(i, q) {
  if (answered) return; answered = true;
  document.querySelectorAll('.opt').forEach(function(b, idx) {
    b.disabled = true;
    if (idx === q.a) b.classList.add('correct');
    else if (idx === i && i !== q.a) b.classList.add('wrong');
  });
  if (i === q.a) cScore++;
  var fb = document.getElementById('fb');
  fb.style.display = 'block';
  fb.textContent = (i === q.a ? '✅ Correct! ' : '❌ Incorrect. ') + (q.e || '');
  document.getElementById('nxt-btn').style.display = 'inline-flex';
  document.getElementById('live-sc').textContent = 'Score: ' + cScore + '/' + (cIdx + 1);
}

function nextQ() { cIdx++; renderQ(); }

function showScore() {
  var pct = Math.round(cScore / curQs.length * 100);
  document.getElementById('q-num').textContent = '';
  document.getElementById('q-text').textContent = '';
  document.getElementById('opt-list').innerHTML = '';
  document.getElementById('fb').style.display = 'none';
  document.getElementById('nxt-btn').style.display = 'none';
  document.getElementById('prog-fill').style.width = '100%';
  document.getElementById('live-sc').textContent = '';
  document.getElementById('sc-big').textContent = cScore + ' / ' + curQs.length;
  document.getElementById('sc-msg').textContent = pct >= 80 ? '🏆 Excellent! Placement ready!' : pct >= 60 ? '👍 Good! A bit more practice.' : '📚 Keep practicing — you can do it!';
  document.getElementById('score-panel').style.display = 'block';
  document.getElementById('retry-btn').onclick = function(){ loadMod(curMod, _activeModBtn); };
}

// ─── Mock Interview Functions ──────────────────────────────────────────────────
function startMock(type, btn) {
  mockType = type; mockQIdx = 0;
  document.querySelectorAll('.mock-tab').forEach(function(b){ b.classList.remove('active'); });
  if (btn) btn.classList.add('active');

  var labels = {fresher:'Fresher', experienced:'Experienced', hr:'HR Round', technical:'Technical'};
  var chat = document.getElementById('m-chat'); chat.innerHTML = '';

  var bank = MOCK_QA[type];
  var firstQ = bank[0].q;
  addMB('ai', 'Welcome to your <strong>' + labels[type] + ' mock interview</strong>! Answer each question as you would in a real interview. I will give you feedback after each answer.<br><br>🎙 <strong>Question 1/' + bank.length + ':</strong><br><br>' + firstQ);
}

function sendMock() {
  var inp = document.getElementById('m-inp');
  var val = inp.value.trim();
  if (!val) return;
  if (!mockType) { addMB('ai', 'Please select an interview type above first 👆'); return; }
  inp.value = '';

  // Show user message
  var ud = document.createElement('div');
  ud.className = 'mb mb-user';
  ud.textContent = val;
  document.getElementById('m-chat').appendChild(ud);
  document.getElementById('m-chat').scrollTop = 99999;

  // Generate built-in response
  var bank = MOCK_QA[mockType];
  var current = bank[mockQIdx % bank.length];
  mockQIdx++;

  var wordCount = val.trim().split(/\s+/).length;
  var lengthNote = wordCount < 8 ? ' Try to elaborate more in your actual interview.' : '';

  var reply, nextQ;
  if (mockQIdx >= bank.length) {
    reply = '✅ <strong>Feedback:</strong> ' + current.fb + lengthNote
      + '<br><br>💡 <em>Tip: ' + current.tip + '</em>'
      + '<br><br>──────────────────<br><br>'
      + '🏁 <strong>Interview Complete!</strong><br><br>You answered all ' + bank.length + ' questions. Great practice! Click an interview type above to start a new session.';
    mockQIdx = 0;
  } else {
    nextQ = bank[mockQIdx];
    reply = '✅ <strong>Feedback:</strong> ' + current.fb + lengthNote
      + '<br><br>💡 <em>Tip: ' + current.tip + '</em>'
      + '<br><br>──────────────────<br><br>'
      + '🎙 <strong>Question ' + (mockQIdx + 1) + '/' + bank.length + ':</strong><br><br>'
      + nextQ.q;
  }

  addMB('ai', reply);
}

function addMB(who, html) {
  var chat = document.getElementById('m-chat');
  var d = document.createElement('div');
  d.className = 'mb mb-' + who;
  if (who === 'ai') {
    d.innerHTML = html;
  } else {
    d.textContent = html;
  }
  chat.appendChild(d);
  chat.scrollTop = 99999;
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>