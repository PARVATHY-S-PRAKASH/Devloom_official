// Test the shuffle-with-answer fix
function shuffleOpts(q) {
  var opts = q.o.map((text,i)=>({text,correct:i===q.a}));
  opts.sort(()=>Math.random()-.5);
  return {q:q.q, o:opts.map(x=>x.text), a:opts.findIndex(x=>x.correct), e:q.e};
}
var q = {q:"Test",o:["Correct","Wrong1","Wrong2","Wrong3"],a:0,e:"It's correct"};
var shuffled = shuffleOpts(q);
console.log("Original correct:",q.o[q.a]);
console.log("After shuffle correct:",shuffled.o[shuffled.a]);
