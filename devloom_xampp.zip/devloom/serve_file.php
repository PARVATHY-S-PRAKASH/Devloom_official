<?php
/**
 * serve_file.php — Serves project screenshot/file attachments securely.
 */
require_once __DIR__ . '/config/db.php';

if (!isLoggedIn()) {
    http_response_code(403); exit('Access denied. Please log in.');
}

$filename = basename($_GET['f'] ?? '');
if (!$filename || strpos($filename, '..') !== false) {
    http_response_code(400); exit('Bad request');
}

// Verify access rights
if (!isAdmin()) {
    $userId = currentUserId();
    $stmt = $pdo->prepare(
        "SELECT s.id FROM screenshots s
         INNER JOIN projects p ON p.id = s.project_id
         WHERE s.filename = ? AND p.user_id = ? LIMIT 1"
    );
    $stmt->execute([$filename, $userId]);
    if (!$stmt->fetch()) {
        http_response_code(404); exit('File not found');
    }
} else {
    $stmt = $pdo->prepare("SELECT id FROM screenshots WHERE filename = ? LIMIT 1");
    $stmt->execute([$filename]);
    if (!$stmt->fetch()) {
        http_response_code(404); exit('File not found');
    }
}

// Use __DIR__ directly (avoids config/../ path issues on Windows/XAMPP)
$base = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
$searchPaths = [
    $base . 'files'       . DIRECTORY_SEPARATOR . $filename,
    $base . 'screenshots' . DIRECTORY_SEPARATOR . $filename,
];

$found = null;
foreach ($searchPaths as $p) {
    if (file_exists($p)) { $found = $p; break; }
}

if (!$found) {
    http_response_code(404);
    exit('File not found on disk.');
}

$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$mimeMap = [
    'jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png',
    'gif'=>'image/gif','webp'=>'image/webp','bmp'=>'image/bmp',
    'svg'=>'image/svg+xml','pdf'=>'application/pdf',
    'zip'=>'application/zip','rar'=>'application/x-rar-compressed',
    'doc'=>'application/msword',
    'docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls'=>'application/vnd.ms-excel',
    'xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt'=>'application/vnd.ms-powerpoint',
    'pptx'=>'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'txt'=>'text/plain','csv'=>'text/csv','mp4'=>'video/mp4','mp3'=>'audio/mpeg',
];
$mime = $mimeMap[$ext] ?? (function_exists('mime_content_type') ? mime_content_type($found) : 'application/octet-stream');

$forceDownload = isset($_GET['dl']);
$inline = !$forceDownload && in_array($ext, ['jpg','jpeg','png','gif','webp','bmp','svg','pdf']);

header('Content-Type: '        . $mime);
header('Content-Length: '      . filesize($found));
header('Cache-Control: private, max-age=86400');
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . addslashes($filename) . '"');
readfile($found);
exit;