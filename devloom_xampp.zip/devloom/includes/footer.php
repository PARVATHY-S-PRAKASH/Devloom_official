<?php // includes/footer.php ?>
</div><!-- /.page-wrap -->

<footer class="footer">
  <p>© <?= date('Y') ?> <strong>Devloom</strong> — Weaving Code Together</p>
  <p style="margin-top:4px;font-size:11px;color:#1e293b;">Built with PHP + MySQL · Running on XAMPP locally</p>
</footer>

<!-- Modal helper JS + Tab switcher + AI Note fetcher -->
<script>
// ── Modal helpers ───────────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open')
      .forEach(m => m.classList.remove('open'));
    document.body.style.overflow = '';
  }
});
document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', e => {
    if (e.target === m) { m.classList.remove('open'); document.body.style.overflow = ''; }
  });
});

// ── Tab switcher ────────────────────────────────────────────
function switchTab(groupId, tabId, btn) {
  document.querySelectorAll(`[data-tabgroup="${groupId}"]`).forEach(t => {
    t.classList.remove('active');
    t.style.display = 'none';
  });
  document.querySelectorAll(`[data-tabbtns="${groupId}"] .tab-btn`).forEach(b => b.classList.remove('active'));
  const panel = document.getElementById(tabId);
  if (panel) { panel.classList.add('active'); panel.style.display = ''; }
  if (btn)   btn.classList.add('active');
}
// Init: hide all non-first panels
document.querySelectorAll('[data-tabgroup]').forEach(panel => {
  if (!panel.classList.contains('active')) panel.style.display = 'none';
});

// ── AI Note Generator (Admin only) ─────────────────────────
async function generateAINote(projectId, title, tech, description) {
  const noteArea = document.getElementById('codeNote_' + projectId);
  const btn      = document.getElementById('aiBtn_'   + projectId);
  if (!noteArea || !btn) return;

  btn.disabled   = true;
  btn.textContent = '✨ Generating…';

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: `You are a senior developer writing a friendly, non-technical explanation for a client. Project: "${title}". Tech stack: ${tech || 'Not specified'}. Description: ${description}.\n\nWrite a clear, concise walkthrough (~150 words) of how this project was built, what the key components are, and how they connect. Use simple language the client can understand.`
        }]
      })
    });
    const data = await res.json();
    const text = data.content?.find(c => c.type === 'text')?.text || 'Could not generate note.';
    noteArea.value = text;
  } catch (err) {
    noteArea.value = 'AI generation failed. Please write the note manually.';
  }

  btn.disabled   = false;
  btn.textContent = '✨ Generate with Claude AI';
}

// ── Flash auto-dismiss ──────────────────────────────────────
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = 'opacity .5s';
    a.style.opacity    = '0';
    setTimeout(() => a.remove(), 500);
  });
}, 4000);

// ── Real-time notification polling ─────────────────────────
(function() {
  var lastCount = parseInt(document.querySelector('.notif-dot')?.textContent || '0');

  function pollNotifications() {
    fetch('/devloom/api_notify.php')
      .then(r => r.json())
      .then(function(data) {
        var count = data.count || 0;
        // Update all notification dots
        document.querySelectorAll('.notif-dot').forEach(function(dot) {
          if (count > 0) {
            dot.textContent = count;
            dot.style.display = 'inline-flex';
          } else {
            dot.style.display = 'none';
          }
        });
        // If new messages arrived since last check, show a toast
        if (count > lastCount && lastCount >= 0 && document.visibilityState === 'visible') {
          showToast('🔔 New message received!', '#f59e0b');
        }
        lastCount = count;
      })
      .catch(function() {});
  }

  function showToast(msg, color) {
    var t = document.createElement('div');
    t.style.cssText = 'position:fixed;bottom:24px;right:24px;background:' + color + ';color:#000;font-weight:700;padding:12px 20px;border-radius:12px;font-size:14px;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,.4);animation:slideUp .3s ease;';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function() { t.style.opacity='0'; t.style.transition='opacity .4s'; setTimeout(function(){t.remove();},400); }, 4000);
  }

  // Poll every 15 seconds
  setInterval(pollNotifications, 15000);
  // Initial poll after 3s
  setTimeout(pollNotifications, 3000);
})();
</script>

<script>
// ── Hide "Get App" nav link when already running as the installed app ──
// (standalone display-mode = launched from home screen icon, not a normal browser tab)
(function () {
  var isStandalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true; // iOS Safari's older flag
  if (isStandalone) {
    var link = document.getElementById('nav-get-app');
    if (link) link.style.display = 'none';
  }
})();
</script>

<script>
// ── PWA: register service worker ──
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('/devloom/sw.js').catch(function (err) {
      console.log('Service worker registration failed:', err);
    });
  });
}

// ── PWA: custom "Install app" prompt ──
// Chrome/Edge suppress the native install banner by default; this captures
// the event so we can show our own button (see #pwa-install-btn below)
// instead of relying on the browser's built-in (often-missed) UI.
let deferredInstallPrompt = null;
window.addEventListener('beforeinstallprompt', function (e) {
  e.preventDefault();
  deferredInstallPrompt = e;
  var btn = document.getElementById('pwa-install-btn');
  if (btn) btn.style.display = 'inline-flex';
});

function devloomInstallApp() {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  deferredInstallPrompt.userChoice.finally(function () {
    deferredInstallPrompt = null;
    var btn = document.getElementById('pwa-install-btn');
    if (btn) btn.style.display = 'none';
  });
}

window.addEventListener('appinstalled', function () {
  var btn = document.getElementById('pwa-install-btn');
  if (btn) btn.style.display = 'none';
});
</script>
</body>
</html>
