<?php
// includes/header.php
$pageTitle  = $pageTitle ?? 'Devloom';
$activePage = $activePage ?? '';
$userName   = $_SESSION['user_name']   ?? '';
$userAvatar = $_SESSION['user_avatar'] ?? '';
$adminMode  = isAdmin();

// Fetch profile photo for nav avatar (logged-in non-admin users)
$navProfilePhoto = '';
if (isLoggedIn() && !$adminMode) {
    try {
        $navRow = $pdo->prepare("SELECT profile_photo FROM users WHERE id = ?");
        $navRow->execute([currentUserId()]);
        $navData = $navRow->fetch();
        if ($navData && !empty($navData['profile_photo'])) {
            $navProfilePhoto = '/devloom/uploads/avatars/' . htmlspecialchars(basename($navData['profile_photo']), ENT_QUOTES, 'UTF-8');
        }
    } catch (Exception $e) { /* ignore if column not yet migrated */ }
}

// Unread count for admin nav only
$adminUnread = 0;
if ($adminMode) {
    $adminUnread = (int)$pdo->query("SELECT COUNT(*) FROM user_messages WHERE sender='user' AND is_read=0")->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($pageTitle) ?> — Devloom</title>
  <meta name="description" content="Devloom — Weaving Code Together. Professional software development platform.">
  <link rel="stylesheet" href="/devloom/assets/css/style.css">
  <link rel="stylesheet" href="/devloom/assets/css/animations.css">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 28 28'><rect x='2' y='6' width='4' height='16' rx='2' fill='%2310b981'/><rect x='8' y='2' width='4' height='24' rx='2' fill='%2310b981'/><rect x='14' y='8' width='4' height='12' rx='2' fill='%2314b8a6'/><rect x='20' y='4' width='4' height='20' rx='2' fill='%2310b981'/></svg>">
  <link rel="manifest" href="/devloom/manifest.json">
  <meta name="theme-color" content="#071009">
  <link rel="apple-touch-icon" href="/devloom/assets/icons/icon-192.png">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Devloom">
  <style>
    .notif-dot {
      display:inline-flex;align-items:center;justify-content:center;
      background:#f59e0b;color:#000;font-weight:700;font-size:10px;
      min-width:17px;height:17px;border-radius:999px;padding:0 4px;
      vertical-align:middle;margin-left:4px;line-height:1;
    }
  </style>
</head>
<body>

<!-- Woven Background -->
<div class="weavebg" aria-hidden="true">
  <?php for ($i = 0; $i < 18; $i++): ?>
  <div class="line" style="left:<?= ($i / 18 * 110 - 5) ?>%;animation-delay:<?= $i * 0.18 ?>s;animation-duration:<?= (3 + $i % 4) ?>s"></div>
  <?php endfor; ?>
  <div class="glow-1"></div>
  <div class="glow-2"></div>
</div>

<!-- Navbar -->
<nav class="navbar">
  <div class="nav-inner">
    <!-- Brand -->
    <a href="/devloom/index.php" class="nav-brand">
      <svg width="26" height="26" viewBox="0 0 28 28" fill="none" aria-hidden="true">
        <rect x="2"  y="6"  width="4" height="16" rx="2" fill="#10b981" opacity=".9"/>
        <rect x="8"  y="2"  width="4" height="24" rx="2" fill="#10b981"/>
        <rect x="14" y="8"  width="4" height="12" rx="2" fill="#14b8a6" opacity=".8"/>
        <rect x="20" y="4"  width="4" height="20" rx="2" fill="#10b981" opacity=".6"/>
      </svg>
      Dev<span>loom</span>
    </a>

    <!-- Links -->
    <div class="nav-links">
      <a href="/devloom/index.php"   class="nav-link <?= $activePage==='home'?'active':'' ?>">Home</a>
      <a href="/devloom/get-app.php" id="nav-get-app" class="nav-link <?= $activePage==='get-app'?'active':'' ?>">📱 Get App</a>
      <a href="/devloom/contact.php" class="nav-link <?= $activePage==='contact'?'active':'' ?>">
        <?php if (isLoggedIn() && !$adminMode): ?>Rate Us<?php else: ?>Contact<?php endif; ?>
      </a>

      <?php if (isLoggedIn()): ?>
        <?php if ($adminMode): ?>
          <a href="/devloom/admin/index.php" class="nav-link <?= $activePage==='admin'?'active':'' ?>">
            Admin Panel
            <?php if ($adminUnread): ?><span class="notif-dot"><?= $adminUnread ?></span><?php endif; ?>
          </a>
        <?php else: ?>
          <?php if ($activePage !== 'messages'): ?>
          <a href="/devloom/dashboard.php" class="nav-link <?= $activePage==='dashboard'?'active':'' ?>">Dashboard</a>
          <?php endif; ?>
          <a href="/devloom/messages.php"  class="nav-link <?= $activePage==='messages'?'active':'' ?>">Messages</a>
          <a href="/devloom/features.php"  class="nav-link <?= $activePage==='features'?'active':'' ?>">🎓 Learn & Play</a>
          <?php
          $navUnpaid = $pdo->query("SELECT id FROM projects WHERE user_id=".currentUserId()." AND paid=0 AND payment IS NOT NULL AND payment > 0 LIMIT 1")->fetch();
          if ($navUnpaid):
          ?>
          <a href="/devloom/payment.php?project_id=<?= $navUnpaid['id'] ?>" class="nav-link <?= $activePage==='payment'?'active':'' ?>" style="color:#10b981;">
            💳 Pay Now
            <span class="notif-dot" style="background:#10b981;">!</span>
          </a>
          <?php endif; ?>
        <?php endif; ?>

        <!-- User dropdown -->
        <div style="position:relative;display:inline-block;" id="user-menu-wrap">
          <button onclick="toggleUserMenu()" style="background:none;border:none;cursor:pointer;display:flex;align-items:center;gap:8px;padding:4px 8px;border-radius:8px;transition:background .2s;" onmouseenter="this.style.background='rgba(255,255,255,.06)'" onmouseleave="this.style.background='none'">
            <div class="nav-avatar <?= $adminMode?'admin':'' ?>" title="<?= e($userName) ?>"
                 style="<?= $navProfilePhoto ? 'padding:0;overflow:hidden;' : '' ?>">
              <?php if ($adminMode): ?>
                🛡
              <?php elseif ($navProfilePhoto): ?>
                <img src="<?= $navProfilePhoto ?>" alt="<?= e($userName) ?>"
                     style="width:100%;height:100%;object-fit:cover;">
              <?php else: ?>
                <?= e($userAvatar) ?>
              <?php endif; ?>
            </div>
            <span style="font-size:13px;color:#cbd5e1;"><?= e($userName) ?></span>
            <span style="color:var(--muted);font-size:10px;">▼</span>
          </button>
          <div id="user-dropdown" style="display:none;position:absolute;right:0;top:calc(100% + 6px);background:#1a2332;border:1px solid rgba(255,255,255,.1);border-radius:10px;min-width:175px;z-index:200;box-shadow:0 8px 32px rgba(0,0,0,.5);overflow:hidden;">
            <?php if (!$adminMode): ?>
            <a href="/devloom/profile.php" style="display:block;padding:10px 16px;color:#cbd5e1;text-decoration:none;font-size:13px;border-bottom:1px solid rgba(255,255,255,.06);transition:background .15s;" onmouseenter="this.style.background='rgba(255,255,255,.05)'" onmouseleave="this.style.background=''">👤 My Profile</a>
            <a href="/devloom/change_password.php" style="display:block;padding:10px 16px;color:#cbd5e1;text-decoration:none;font-size:13px;border-bottom:1px solid rgba(255,255,255,.06);transition:background .15s;" onmouseenter="this.style.background='rgba(255,255,255,.05)'" onmouseleave="this.style.background=''">🔒 Change Password</a>
            <?php endif; ?>
            <a href="/devloom/logout.php" style="display:block;padding:10px 16px;color:#f87171;text-decoration:none;font-size:13px;transition:background .15s;" onmouseenter="this.style.background='rgba(239,68,68,.08)'" onmouseleave="this.style.background=''">⬡ Logout</a>
          </div>
        </div>

      <?php else: ?>
        <a href="/devloom/auth.php" class="btn btn-primary btn-sm nav-cta" style="margin-left:8px;">Sign In</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<!-- Page loader -->
<div id="page-loader"></div>
<!-- Scroll progress -->
<div class="navbar-progress" id="nav-progress"></div>
<!-- Particle canvas -->
<canvas id="dl-particles"></canvas>

<div class="page-wrap">

<script>
/* ── Shared animation engine ── */
(function(){
  // Page loader fade
  window.addEventListener('load', function(){
    var l=document.getElementById('page-loader');
    if(l) setTimeout(function(){l.style.display='none';},700);
  });

  // Scroll progress bar
  window.addEventListener('scroll', function(){
    var prog=document.getElementById('nav-progress');
    if(prog){
      var pct=(window.scrollY/(document.body.scrollHeight-window.innerHeight))||0;
      prog.style.transform='scaleX('+Math.min(pct,1)+')';
    }
    // Scroll-to-top
    var st=document.getElementById('scroll-top');
    if(st){ if(window.scrollY>300) st.classList.add('visible'); else st.classList.remove('visible'); }
  });

  // Scroll-reveal via IntersectionObserver
  function initReveal(){
    var els=document.querySelectorAll('.reveal,.reveal-left,.reveal-right,.reveal-scale');
    if(!els.length) return;
    var io=new IntersectionObserver(function(entries){
      entries.forEach(function(e){
        if(e.isIntersecting){ e.target.classList.add('visible'); io.unobserve(e.target); }
      });
    },{threshold:0.12});
    els.forEach(function(el){ io.observe(el); });
  }
  document.addEventListener('DOMContentLoaded', initReveal);

  // Mouse-tracking glow on cards
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.card.card-hover').forEach(function(card){
      card.addEventListener('mousemove', function(e){
        var r=card.getBoundingClientRect();
        card.style.setProperty('--mx',((e.clientX-r.left)/r.width*100)+'%');
        card.style.setProperty('--my',((e.clientY-r.top)/r.height*100)+'%');
      });
    });

    // Animate hero stat counters
    document.querySelectorAll('.hero-stat-num').forEach(function(el){
      var text=el.textContent.trim();
      var num=parseFloat(text);
      if(isNaN(num)) return;
      var suffix=text.replace(/[\d.]/g,'');
      var duration=1200, start=null, from=0;
      var isFloat=text.indexOf('.')!==-1;
      function step(ts){
        if(!start) start=ts;
        var p=Math.min((ts-start)/duration,1);
        var ease=1-Math.pow(1-p,3);
        var cur=from+ease*(num-from);
        el.textContent=(isFloat?cur.toFixed(1):Math.round(cur))+suffix;
        if(p<1) requestAnimationFrame(step);
      }
      // Trigger when visible
      var io2=new IntersectionObserver(function(entries){
        entries.forEach(function(e){
          if(e.isIntersecting){ requestAnimationFrame(step); io2.unobserve(e.target); }
        });
      },{threshold:.5});
      io2.observe(el);
    });

    // Scroll-to-top button
    var stb=document.createElement('button');
    stb.id='scroll-top'; stb.title='Back to top'; stb.innerHTML='↑';
    stb.onclick=function(){ window.scrollTo({top:0,behavior:'smooth'}); };
    document.body.appendChild(stb);
  });

  // Lightweight particle background
  document.addEventListener('DOMContentLoaded', function(){
    var c=document.getElementById('dl-particles');
    if(!c) return;
    var ctx=c.getContext('2d');
    var W,H,pts=[];
    function resize(){ W=c.width=window.innerWidth; H=c.height=window.innerHeight; }
    resize(); window.addEventListener('resize',resize);
    for(var i=0;i<55;i++){
      pts.push({
        x:Math.random()*W, y:Math.random()*H,
        vx:(Math.random()-.5)*.28, vy:(Math.random()-.5)*.28,
        r:Math.random()*1.4+.4,
        a:Math.random()*.55+.1
      });
    }
    function draw(){
      ctx.clearRect(0,0,W,H);
      // connections
      for(var i=0;i<pts.length;i++){
        for(var j=i+1;j<pts.length;j++){
          var dx=pts[i].x-pts[j].x, dy=pts[i].y-pts[j].y;
          var d=Math.sqrt(dx*dx+dy*dy);
          if(d<130){
            ctx.strokeStyle='rgba(16,185,129,'+(0.07*(1-d/130))+')';
            ctx.lineWidth=.6;
            ctx.beginPath(); ctx.moveTo(pts[i].x,pts[i].y); ctx.lineTo(pts[j].x,pts[j].y); ctx.stroke();
          }
        }
      }
      // dots
      pts.forEach(function(p){
        ctx.beginPath();
        ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
        ctx.fillStyle='rgba(16,185,129,'+p.a+')';
        ctx.fill();
        p.x+=p.vx; p.y+=p.vy;
        if(p.x<0||p.x>W) p.vx*=-1;
        if(p.y<0||p.y>H) p.vy*=-1;
      });
      requestAnimationFrame(draw);
    }
    draw();
  });
})();

function toggleUserMenu() {
  var d = document.getElementById('user-dropdown');
  d.style.display = d.style.display === 'none' ? 'block' : 'none';
}
document.addEventListener('click', function(e) {
  var wrap = document.getElementById('user-menu-wrap');
  if (wrap && !wrap.contains(e.target)) {
    var d = document.getElementById('user-dropdown');
    if (d) d.style.display = 'none';
  }
});
</script>
