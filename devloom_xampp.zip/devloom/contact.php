<?php
require_once __DIR__ . '/config/db.php';

$pageTitle  = 'Contact Us';
$activePage = 'contact';
include __DIR__ . '/includes/header.php';
?>

<style>
.contact-hero{text-align:center;padding:56px 0 40px;}
.contact-hero h1{font-size:clamp(1.8rem,4vw,2.8rem);font-weight:900;margin-bottom:10px;}
.contact-hero p{color:#64748b;font-size:1rem;max-width:480px;margin:0 auto;}

.contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start;margin-bottom:60px;}
@media(max-width:800px){.contact-grid{grid-template-columns:1fr;}}

/* Info cards */
.info-stack{display:flex;flex-direction:column;gap:14px;}
.info-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:16px;padding:22px 20px;display:flex;gap:16px;align-items:flex-start;transition:border-color .2s;}
.info-card:hover{border-color:rgba(16,185,129,.25);}
.info-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.info-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#475569;font-family:monospace;margin-bottom:4px;}
.info-val{font-size:15px;font-weight:700;color:#e2e8f0;margin-bottom:2px;}
.info-sub{font-size:12px;color:#64748b;line-height:1.5;}

/* Live badge */
.live-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.2);border-radius:999px;padding:4px 12px;font-size:12px;font-weight:700;color:#10b981;margin-top:6px;}
.live-dot{width:7px;height:7px;border-radius:50%;background:#10b981;box-shadow:0 0 0 3px rgba(16,185,129,.2);animation:pulse 1.8s infinite;}
@keyframes pulse{0%,100%{box-shadow:0 0 0 3px rgba(16,185,129,.2)}50%{box-shadow:0 0 0 6px rgba(16,185,129,.05)}}

/* Contact form */
.contact-form-box{background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);border-radius:20px;padding:32px 28px;}
.contact-form-box h2{font-size:1.1rem;font-weight:800;color:#f1f5f9;margin:0 0 6px;}
.contact-form-box p{font-size:13px;color:#475569;margin:0 0 24px;}

/* Section divider */
.or-divider{display:flex;align-items:center;gap:12px;margin:28px 0;}
.or-divider span{font-size:12px;color:#334155;white-space:nowrap;}
.or-divider::before,.or-divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.06);}

/* Social links */
.social-row{display:flex;gap:10px;flex-wrap:wrap;}
.social-btn{display:flex;align-items:center;gap:7px;padding:9px 16px;border-radius:10px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);color:#94a3b8;font-size:13px;font-weight:600;text-decoration:none;transition:all .2s;}
.social-btn:hover{background:rgba(255,255,255,.07);color:#f1f5f9;border-color:rgba(255,255,255,.15);}

/* Map placeholder */
.map-box{background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);border-radius:16px;overflow:hidden;height:200px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;margin-top:14px;}
.map-box span{font-size:2rem;}
.map-box p{font-size:13px;color:#475569;text-align:center;margin:0;}
.map-link{font-size:13px;font-weight:700;color:#10b981;text-decoration:none;}
.map-link:hover{text-decoration:underline;}
</style>

<div class="container">
  <div class="contact-hero animate-up">
    <h1 class="heading-lg mb-8">Get in <span class="text-green">Touch</span></h1>
    <p>We're always here to help. Reach out through any channel and we'll respond fast.</p>
  </div>

  <div class="contact-grid animate-up-2">

    <!-- LEFT: Info cards -->
    <div class="info-stack">

      <div class="info-card">
        <div class="info-icon" style="background:rgba(16,185,129,.1);">📧</div>
        <div>
          <div class="info-label">Email Us</div>
          <div class="info-val">
            <a href="mailto:admin@devloom.io" style="color:#10b981;text-decoration:none;">admin@devloom.io</a>
          </div>
          <div class="info-sub">For project enquiries, support, and billing questions.<br>We reply within a few hours.</div>
        </div>
      </div>

      <div class="info-card">
        <div class="info-icon" style="background:rgba(96,165,250,.1);">⏰</div>
        <div>
          <div class="info-label">Availability</div>
          <div class="info-val">24 × 7, Every Day</div>
          <div class="info-sub">Our team monitors messages round the clock — no waiting till Monday.</div>
          <div class="live-badge"><span class="live-dot"></span> Currently Online</div>
        </div>
      </div>

      <div class="info-card">
        <div class="info-icon" style="background:rgba(245,158,11,.1);">📍</div>
        <div>
          <div class="info-label">Location</div>
          <div class="info-val">Trivandrum, Kerala</div>
          <div class="info-sub">Kerala, India — 695 001<br>Serving clients globally.</div>
        </div>
      </div>

      <div class="info-card">
        <div class="info-icon" style="background:rgba(167,139,250,.1);">💬</div>
        <div>
          <div class="info-label">Platform Chat</div>
          <div class="info-val">In-App Messaging</div>
          <div class="info-sub">Logged-in users can message the team directly from the dashboard with file sharing.</div>
          <?php if (isLoggedIn()): ?>
          <a href="/devloom/messages.php" class="btn btn-outline btn-sm" style="margin-top:10px;display:inline-block;">Open Messages →</a>
          <?php else: ?>
          <a href="/devloom/auth.php" class="btn btn-outline btn-sm" style="margin-top:10px;display:inline-block;">Sign In to Chat →</a>
          <?php endif; ?>
        </div>
      </div>

      <!-- Map -->
      <div class="map-box">
        <span>🗺️</span>
        <p>Trivandrum, Kerala, India</p>
        <a href="https://maps.google.com/?q=Trivandrum,Kerala,India" target="_blank" rel="noopener" class="map-link">Open in Google Maps →</a>
      </div>

    </div>

    <!-- RIGHT: Contact form -->
    <div>
      <div class="contact-form-box">
        <h2>Send Us a Message</h2>
        <p>Not registered yet? Drop a message below and we'll get back to you on email.</p>

        <?php
        $cfSuccess = false;
        $cfError   = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cf_name'])) {
            $cfName    = trim($_POST['cf_name'] ?? '');
            $cfEmail   = trim($_POST['cf_email'] ?? '');
            $cfSubject = trim($_POST['cf_subject'] ?? '');
            $cfMessage = trim($_POST['cf_message'] ?? '');
            if (!$cfName || !$cfEmail || !$cfMessage) {
                $cfError = 'Please fill in all required fields.';
            } elseif (!filter_var($cfEmail, FILTER_VALIDATE_EMAIL)) {
                $cfError = 'Please enter a valid email address.';
            } else {
                // Store in DB — 'contacts' is the correct table (matches admin panel query)
                try {
                    $pdo->prepare("INSERT INTO contacts (name, email, subject, message, created_at) VALUES (?,?,?,?,NOW())")
                        ->execute([$cfName, $cfEmail, $cfSubject, $cfMessage]);
                } catch (PDOException $e) { /* table optional */ }
                // Send email notification
                $to      = ADMIN_EMAIL;
                $subject = '[Devloom Contact] ' . ($cfSubject ?: 'New enquiry from ' . $cfName);
                $body    = "Name: $cfName\nEmail: $cfEmail\nSubject: $cfSubject\n\nMessage:\n$cfMessage";
                $headers = "From: noreply@devloom.io\r\nReply-To: $cfEmail";
                @mail($to, $subject, $body, $headers);
                $cfSuccess = true;
            }
        }
        ?>

        <?php if ($cfSuccess): ?>
        <div class="alert alert-success" style="margin-bottom:0;">
          ✅ Message sent! We'll reply to <strong><?= e($cfEmail) ?></strong> shortly.
        </div>
        <?php else: ?>
        <?php if ($cfError): ?><div class="alert alert-error"><?= e($cfError) ?></div><?php endif; ?>

        <form method="POST">
          <div class="form-group">
            <label class="form-label">Full Name *</label>
            <input type="text" name="cf_name" class="form-control" placeholder="Your name"
              value="<?= e($_POST['cf_name'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email Address *</label>
            <input type="email" name="cf_email" class="form-control" placeholder="you@example.com"
              value="<?= e($_POST['cf_email'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Subject</label>
            <input type="text" name="cf_subject" class="form-control" placeholder="e.g. Project enquiry, support..."
              value="<?= e($_POST['cf_subject'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Message *</label>
            <textarea name="cf_message" class="form-control" rows="5"
              placeholder="Tell us what you need..." required><?= e($_POST['cf_message'] ?? '') ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-full">Send Message →</button>
        </form>

        <div class="or-divider"><span>or reach us directly</span></div>

        <div class="social-row">
          <a href="mailto:admin@devloom.io" class="social-btn">
            <span>📧</span> admin@devloom.io
          </a>
        </div>
        <?php endif; ?>
      </div>

      <!-- FAQ strip -->
      <div style="margin-top:20px;display:flex;flex-direction:column;gap:10px;">
        <?php
        $faqs = [
          ['How long does a project take?', 'Timelines depend on scope — we set a clear deadline before starting. Most projects range from 1–4 weeks.'],
          ['Is there a free consultation?', 'Yes. Submit your project details and we\'ll review it and send a quote at no charge.'],
          ['What tech stacks do you work with?', 'PHP, Laravel, React, Next.js, Node.js, Flutter, Python, MySQL, and more.'],
        ];
        foreach ($faqs as [$q, $a]):
        ?>
        <details style="background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:14px 18px;cursor:pointer;">
          <summary style="font-size:13px;font-weight:700;color:#e2e8f0;list-style:none;display:flex;justify-content:space-between;align-items:center;">
            <?= $q ?>
            <span style="font-size:16px;color:#475569;margin-left:10px;">+</span>
          </summary>
          <p style="font-size:13px;color:#64748b;line-height:1.7;margin:10px 0 0;"><?= $a ?></p>
        </details>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
