<?php
require_once __DIR__ . '/config/db.php';
requireUser();

$userId = currentUserId();
$stmtU  = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmtU->execute([$userId]);
$user = $stmtU->fetch();

/* ── Helper: save uploaded attachments for a message ───────── */
function saveMessageAttachments(PDO $pdo, int $msgId): void {
    if (empty($_FILES['attachments']['name'][0])) return;
    $uploadDir = UPLOAD_PATH_MESSAGES;
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    foreach ($_FILES['attachments']['tmp_name'] as $i => $tmp) {
        if (!$tmp || !is_uploaded_file($tmp)) continue;
        $fileEntry = [
            'name'     => $_FILES['attachments']['name'][$i],
            'tmp_name' => $tmp,
            'size'     => $_FILES['attachments']['size'][$i] ?? 0,
        ];
        if (!isAllowedUpload($fileEntry, ALLOWED_UPLOAD_EXTS)) continue; // skip disallowed/oversized files
        $origName = $_FILES['attachments']['name'][$i];
        $size     = $_FILES['attachments']['size'][$i];
        $mime     = mime_content_type($tmp);
        $ext      = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        $fname    = 'msg_' . $msgId . '_' . time() . '_' . $i . ($ext ? '.' . $ext : '');
        move_uploaded_file($tmp, $uploadDir . $fname);
        $pdo->prepare("INSERT INTO message_attachments (message_id,filename,original_name,file_size,mime_type) VALUES (?,?,?,?,?)")
            ->execute([$msgId, $fname, $origName, $size, $mime]);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'send_message') {
        $body = trim($_POST['body'] ?? '');
        $hasFile = !empty($_FILES['attachments']['name'][0]);
        if ($body || $hasFile) {
            $pdo->prepare("INSERT INTO user_messages (user_id,sender,subject,body) VALUES (?,?,?,?)")
                ->execute([$userId, 'user', '', $body]);
            $msgId = (int)$pdo->lastInsertId();
            if ($hasFile) saveMessageAttachments($pdo, $msgId);
        }
        header('Location: /devloom/messages.php'); exit;
    }

    if ($action === 'delete_message') {
        $mid = (int)($_POST['msg_id'] ?? 0);
        $chk = $pdo->prepare("SELECT id FROM user_messages WHERE id=? AND user_id=? AND sender='user'");
        $chk->execute([$mid, $userId]);
        if ($chk->fetch()) {
            // Delete attachment files from disk
            $attStmt = $pdo->prepare("SELECT filename FROM message_attachments WHERE message_id=?");
            $attStmt->execute([$mid]);
            foreach ($attStmt->fetchAll() as $att) {
                $fp = UPLOAD_PATH_MESSAGES . $att['filename'];
                if (file_exists($fp)) unlink($fp);
            }
            $pdo->prepare("DELETE FROM user_messages WHERE id=? AND user_id=?")->execute([$mid, $userId]);
        }
        header('Location: /devloom/messages.php'); exit;
    }
}

// Count unread admin replies BEFORE marking as read
$unreadAdminStmt = $pdo->prepare("SELECT COUNT(*) FROM user_messages WHERE user_id=? AND sender='admin' AND is_read=0");
$unreadAdminStmt->execute([$userId]);
$newAdminReplies = (int)$unreadAdminStmt->fetchColumn();

// Mark admin messages as read
$pdo->prepare("UPDATE user_messages SET is_read=1 WHERE user_id=? AND sender='admin' AND is_read=0")->execute([$userId]);

// Fetch all messages + their attachments
$stmtM = $pdo->prepare("SELECT * FROM user_messages WHERE user_id=? ORDER BY created_at ASC");
$stmtM->execute([$userId]);
$messages = $stmtM->fetchAll();

$attachments = [];
if ($messages) {
    $mids = array_column($messages, 'id');
    $ph   = implode(',', array_fill(0, count($mids), '?'));
    $attQ = $pdo->prepare("SELECT * FROM message_attachments WHERE message_id IN ($ph) ORDER BY id ASC");
    $attQ->execute($mids);
    foreach ($attQ->fetchAll() as $a) {
        $attachments[$a['message_id']][] = $a;
    }
}

$pageTitle  = 'Messages';
$activePage = 'messages';
include __DIR__ . '/includes/header.php';

/* ── File icon helper ─────────────────────────────────────────── */
function msgFileIcon(string $ext): string {
    return [
        'pdf'=>'📄','doc'=>'📝','docx'=>'📝','xls'=>'📊','xlsx'=>'📊',
        'ppt'=>'📊','pptx'=>'📊','csv'=>'📊','zip'=>'🗜','rar'=>'🗜',
        '7z'=>'🗜','txt'=>'📃','mp4'=>'🎬','mp3'=>'🎵','jpg'=>'🖼',
        'jpeg'=>'🖼','png'=>'🖼','gif'=>'🖼','webp'=>'🖼','svg'=>'🖼',
    ][$ext] ?? '📎';
}
function formatFileSize(int $bytes): string {
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes/1024,1) . ' KB';
    return round($bytes/1048576,1) . ' MB';
}
?>

<div class="container-sm" style="padding-top:32px;padding-bottom:0;">

  <!-- Page Header -->
  <div class="page-header" style="margin-bottom:16px;">
    <div>
      <h1 class="heading-md">💬 Messages</h1>
      <p class="text-muted" style="margin-top:4px;font-size:14px;">Direct chat with admin</p>
    </div>
    <a href="/devloom/dashboard.php" class="btn btn-ghost btn-sm">← Dashboard</a>
  </div>

  <?php if ($newAdminReplies > 0): ?>
  <div class="alert alert-success" style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
    <span style="font-size:20px;">🔔</span>
    <span><strong><?= $newAdminReplies ?> new repl<?= $newAdminReplies > 1 ? 'ies' : 'y' ?> from Admin!</strong> Scroll down to read.</span>
  </div>
  <?php endif; ?>

  <!-- Chat Window -->
  <div style="
    background:rgba(255,255,255,.02);
    border:1px solid rgba(255,255,255,.09);
    border-radius:16px;
    display:flex;
    flex-direction:column;
    height:calc(100vh - 200px);
    min-height:480px;
    overflow:hidden;
  ">

    <!-- Chat Header with persistent search -->
    <div style="padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.02);flex-shrink:0;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
        <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#ef4444);display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;">🛡</div>
        <div style="flex:1;">
          <div style="font-weight:700;font-size:14px;color:#f1f5f9;">Admin Support</div>
          <div style="font-size:11px;color:var(--muted);">Devloom Team · replies appear here</div>
        </div>
      </div>
      <!-- Persistent search bar -->
      <div style="position:relative;">
        <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);font-size:14px;color:var(--muted);pointer-events:none;">🔍</span>
        <input
          type="text"
          id="msg-search"
          placeholder="Search messages…"
          oninput="filterMessages(this.value)"
          style="
            width:100%;box-sizing:border-box;
            background:rgba(255,255,255,.06);
            border:1px solid rgba(255,255,255,.1);
            border-radius:10px;color:#e2e8f0;
            font-size:13px;padding:8px 70px 8px 36px;
            outline:none;font-family:inherit;
            transition:border-color .2s;
          "
          onfocus="this.style.borderColor='rgba(16,185,129,.45)'"
          onblur="this.style.borderColor='rgba(255,255,255,.1)'"
        >
        <span id="search-count" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);font-size:11px;color:var(--muted);"></span>
      </div>
    </div>

    <!-- Messages Area -->
    <div id="chat-messages" style="flex:1;overflow-y:auto;padding:18px 18px 10px;display:flex;flex-direction:column;gap:14px;">
      <?php if (!$messages): ?>
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:12px;opacity:.4;">
        <div style="font-size:52px;">💬</div>
        <p class="text-muted" style="font-size:14px;">No messages yet — send the first one!</p>
      </div>
      <?php else: ?>
      <?php foreach ($messages as $msg):
        $isFromUser = ($msg['sender'] === 'user');
        $msgAtts    = $attachments[$msg['id']] ?? [];
      ?>
      <div class="chat-msg"
           data-msg="<?= htmlspecialchars($msg['body'], ENT_QUOTES) ?>"
           data-original="<?= htmlspecialchars($msg['body'], ENT_QUOTES) ?>"
           style="display:flex;flex-direction:column;<?= $isFromUser ? 'align-items:flex-end' : 'align-items:flex-start' ?>;">

        <!-- Sender label -->
        <div style="display:flex;align-items:center;gap:5px;margin-bottom:4px;<?= $isFromUser ? 'flex-direction:row-reverse' : '' ?>">
          <div style="width:22px;height:22px;border-radius:50%;background:<?= $isFromUser ? 'linear-gradient(135deg,#10b981,#14b8a6)' : 'linear-gradient(135deg,#f59e0b,#ef4444)' ?>;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;flex-shrink:0;">
            <?= $isFromUser ? e($user['avatar']) : '🛡' ?>
          </div>
          <span style="font-size:11px;color:var(--muted);">
            <?= $isFromUser ? 'You' : 'Admin' ?> · <?= date('d M, h:i A', strtotime($msg['created_at'])) ?>
            <?php if ($msg['edited']): ?><em style="opacity:.7;">(edited)</em><?php endif; ?>
          </span>
        </div>

        <!-- Bubble + delete -->
        <div style="position:relative;max-width:80%;display:flex;align-items:flex-start;gap:6px;<?= $isFromUser ? 'flex-direction:row-reverse' : '' ?>">
          <div style="display:flex;flex-direction:column;gap:6px;max-width:100%;">

            <?php if ($msg['body']): ?>
            <div class="msg-bubble" style="
              padding:10px 15px;
              border-radius:<?= $isFromUser ? '16px 16px 4px 16px' : '16px 16px 16px 4px' ?>;
              <?= $isFromUser
                ? 'background:linear-gradient(135deg,rgba(16,185,129,.18),rgba(20,184,166,.1));border:1px solid rgba(16,185,129,.28);color:#d1fae5;'
                : 'background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#e2e8f0;'
              ?>
              font-size:14px;line-height:1.72;white-space:pre-wrap;word-break:break-word;
            "><?= e($msg['body']) ?></div>
            <?php endif; ?>

            <?php foreach ($msgAtts as $att):
              $attExt  = strtolower(pathinfo($att['filename'], PATHINFO_EXTENSION));
              $isImg   = in_array($attExt, ['jpg','jpeg','png','gif','webp','bmp','svg']);
              $viewUrl = '/devloom/serve_message_file.php?f=' . urlencode($att['filename']);
              $dlUrl   = $viewUrl . '&dl=1';
              $dispName = $att['original_name'] ?: $att['filename'];
              $icon    = msgFileIcon($attExt);
            ?>
            <div style="
              border-radius:10px;overflow:hidden;
              border:1px solid <?= $isFromUser ? 'rgba(16,185,129,.3)' : 'rgba(255,255,255,.12)' ?>;
              background:<?= $isFromUser ? 'rgba(16,185,129,.07)' : 'rgba(255,255,255,.04)' ?>;
              min-width:180px;max-width:260px;
            ">
              <?php if ($isImg): ?>
              <a href="<?= e($viewUrl) ?>" target="_blank">
                <img src="<?= e($viewUrl) ?>" alt="<?= e($dispName) ?>"
                     style="width:100%;max-height:180px;object-fit:cover;display:block;"
                     onerror="this.style.display='none'">
              </a>
              <?php else: ?>
              <div style="padding:12px 14px;display:flex;align-items:center;gap:10px;">
                <span style="font-size:28px;flex-shrink:0;"><?= $icon ?></span>
                <div style="min-width:0;">
                  <div style="font-size:12px;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="<?= e($dispName) ?>"><?= e($dispName) ?></div>
                  <?php if ($att['file_size']): ?>
                  <div style="font-size:11px;color:var(--muted);margin-top:2px;"><?= formatFileSize((int)$att['file_size']) ?></div>
                  <?php endif; ?>
                </div>
              </div>
              <?php endif; ?>
              <div style="padding:6px 10px;display:flex;gap:6px;border-top:1px solid rgba(255,255,255,.07);">
                <a href="<?= e($viewUrl) ?>" target="_blank" style="flex:1;text-align:center;background:rgba(16,185,129,.12);color:#6ee7b7;border:1px solid rgba(16,185,129,.2);border-radius:6px;padding:4px 6px;font-size:11px;font-weight:600;text-decoration:none;">🔍 View</a>
                <a href="<?= e($dlUrl) ?>" download="<?= e($dispName) ?>" style="flex:1;text-align:center;background:rgba(99,102,241,.12);color:#a5b4fc;border:1px solid rgba(99,102,241,.2);border-radius:6px;padding:4px 6px;font-size:11px;font-weight:600;text-decoration:none;">⬇ Save</a>
              </div>
            </div>
            <?php endforeach; ?>
          </div>

          <?php if ($isFromUser): ?>
          <form method="POST" style="margin:0;padding-top:4px;" onsubmit="return confirm('Delete this message?');"><?= csrf_field() ?>
            <input type="hidden" name="action"  value="delete_message">
            <input type="hidden" name="msg_id"  value="<?= $msg['id'] ?>">
            <button type="submit" title="Delete" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.15);color:#f87171;width:20px;height:20px;border-radius:50%;cursor:pointer;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;flex-shrink:0;">✕</button>
          </form>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Compose Bar -->
    <div style="padding:10px 14px;border-top:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.18);flex-shrink:0;">

      <!-- File preview strip -->
      <div id="file-preview" style="display:none;margin-bottom:8px;display:none;flex-wrap:wrap;gap:6px;padding:6px 4px;"></div>

      <form method="POST" id="chat-form" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:flex-end;"><?= csrf_field() ?>
        <input type="hidden" name="action" value="send_message">
        <input type="file" name="attachments[]" id="file-input" multiple style="display:none;" onchange="previewFiles(this)">

        <!-- Attach button -->
        <button type="button" onclick="document.getElementById('file-input').click()" title="Attach files" style="
          background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
          border-radius:10px;color:#94a3b8;
          width:42px;height:42px;cursor:pointer;font-size:18px;
          display:flex;align-items:center;justify-content:center;
          flex-shrink:0;transition:all .2s;
        " onmouseover="this.style.background='rgba(16,185,129,.15)';this.style.color='#6ee7b7'" onmouseout="this.style.background='rgba(255,255,255,.07)';this.style.color='#94a3b8'">📎</button>

        <textarea
          name="body"
          id="chat-input"
          rows="1"
          placeholder="Type a message or attach a file…"
          style="
            flex:1;background:rgba(255,255,255,.06);
            border:1px solid rgba(255,255,255,.12);
            border-radius:12px;color:#e2e8f0;font-size:14px;
            padding:10px 14px;resize:none;
            min-height:42px;max-height:120px;
            font-family:inherit;line-height:1.5;outline:none;transition:border-color .2s;
          "
          onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();this.form.submit();}"
          oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,120)+'px';"
          onfocus="this.style.borderColor='rgba(16,185,129,.5)'"
          onblur="this.style.borderColor='rgba(255,255,255,.12)'"
        ></textarea>

        <button type="submit" title="Send (Enter)" style="
          background:linear-gradient(135deg,#10b981,#14b8a6);border:none;
          border-radius:12px;color:#fff;width:42px;height:42px;
          cursor:pointer;font-size:20px;display:flex;align-items:center;justify-content:center;
          flex-shrink:0;transition:opacity .2s;
        " onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">➤</button>
      </form>
      <p style="font-size:11px;color:var(--muted);margin-top:5px;padding-left:2px;">Enter to send &nbsp;·&nbsp; Shift+Enter for new line &nbsp;·&nbsp; 📎 to attach files (any format)</p>
    </div>

  </div>
  <div style="height:30px;"></div>
</div>

<script>
// Scroll to bottom
const chatBox = document.getElementById('chat-messages');
if (chatBox) chatBox.scrollTop = chatBox.scrollHeight;

// Search / filter messages
function filterMessages(query) {
  const q = query.trim().toLowerCase();
  const msgs = document.querySelectorAll('.chat-msg');
  const countEl = document.getElementById('search-count');
  let visible = 0;

  msgs.forEach(el => {
    const text     = (el.getAttribute('data-msg') || '').toLowerCase();
    const bubble   = el.querySelector('.msg-bubble');
    const original = el.getAttribute('data-original') || '';

    if (!q) {
      el.style.display = '';
      if (bubble) bubble.textContent = original;
    } else if (text.includes(q)) {
      el.style.display = '';
      visible++;
      if (bubble) {
        const regex = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + ')', 'gi');
        bubble.innerHTML = original.replace(regex, '<mark style="background:rgba(16,185,129,.4);color:#d1fae5;border-radius:2px;padding:0 2px;">$1</mark>');
      }
    } else {
      el.style.display = 'none';
    }
  });

  countEl.textContent = q ? (visible + ' result' + (visible !== 1 ? 's' : '')) : '';
}

// File preview strip
function previewFiles(input) {
  const strip = document.getElementById('file-preview');
  strip.innerHTML = '';
  if (!input.files.length) { strip.style.display = 'none'; return; }
  strip.style.display = 'flex';
  Array.from(input.files).forEach(f => {
    const chip = document.createElement('div');
    chip.style.cssText = 'background:rgba(16,185,129,.12);border:1px solid rgba(16,185,129,.25);border-radius:20px;padding:4px 10px;font-size:12px;color:#6ee7b7;display:flex;align-items:center;gap:5px;max-width:180px;';
    chip.innerHTML = '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + f.name + '</span>';
    strip.appendChild(chip);
  });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
