<?php
require_once __DIR__ . '/config/db.php';
$pageTitle  = 'Get the App';
$activePage = 'get-app';
include __DIR__ . '/includes/header.php';

$apkPath   = __DIR__ . '/downloads/devloom.apk';
$apkUrl    = '/devloom/downloads/devloom.apk';
$apkExists = file_exists($apkPath) && filesize($apkPath) > 0;
$apkSizeMb = $apkExists ? round(filesize($apkPath) / 1024 / 1024, 1) : 0;

// Absolute URL, so the QR code works when scanned from a phone on the same network.
$scheme    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host      = $_SERVER['HTTP_HOST'] ?? 'localhost';
$absApkUrl = $scheme . '://' . $host . $apkUrl;
?>
<style>
/* ── Layout ── */
.gapp-wrap{max-width:1100px;margin:0 auto;padding:0 24px 90px;}

/* ── Hero: two columns, copy left / device right ── */
.gapp-hero{display:grid;grid-template-columns:1.1fr 0.9fr;gap:56px;align-items:center;padding:56px 0 40px;}
@media (max-width:860px){.gapp-hero{grid-template-columns:1fr;gap:40px;padding-top:32px;}}

.gapp-eyebrow{
  display:inline-flex;align-items:center;gap:8px;
  font-family:var(--font-head);font-weight:700;font-size:12px;letter-spacing:.08em;text-transform:uppercase;
  color:var(--teal,#14b8a6);background:rgba(20,184,166,.08);border:1px solid rgba(20,184,166,.25);
  padding:6px 14px;border-radius:999px;margin-bottom:22px;
}
.gapp-hero h1{
  font-family:var(--font-head);font-weight:800;letter-spacing:-0.03em;line-height:1.04;
  font-size:clamp(2.2rem,4.6vw,3.4rem);color:var(--text);margin-bottom:18px;
}
.gapp-hero h1 span{color:var(--green,#10b981);}
.gapp-hero p.lede{font-size:1.05rem;line-height:1.7;color:var(--muted,#94a3b8);max-width:480px;margin-bottom:32px;}

.gapp-cta-row{display:flex;flex-wrap:wrap;gap:14px;align-items:center;}
.gapp-btn-primary{
  display:inline-flex;align-items:center;gap:10px;
  background:linear-gradient(135deg,var(--green,#10b981),var(--teal,#14b8a6));
  color:#04140d;font-weight:800;font-family:var(--font-head);
  padding:15px 28px;border-radius:14px;text-decoration:none;font-size:15px;border:none;cursor:pointer;
  box-shadow:0 8px 24px -8px rgba(16,185,129,.5);transition:transform .15s ease;
}
.gapp-btn-primary:hover{transform:translateY(-2px);}
.gapp-btn-ghost{
  display:inline-flex;align-items:center;gap:8px;color:var(--text);font-weight:600;font-size:14px;
  text-decoration:none;padding:15px 6px;border-bottom:1px solid transparent;
}
.gapp-btn-ghost:hover{border-color:var(--border);}
.gapp-hint{font-size:12.5px;color:var(--subtle,#64748b);margin-top:16px;max-width:460px;line-height:1.6;}

/* ── Device mockup: the signature element ── */
.gapp-device-stage{position:relative;display:flex;justify-content:center;}
.gapp-phone{
  width:230px;height:468px;border-radius:34px;background:#04140d;
  border:6px solid #0d1f16;box-shadow:0 30px 70px -20px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.04);
  position:relative;overflow:hidden;
}
.gapp-phone::before{ /* notch */
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:80px;height:18px;background:#04140d;border-bottom-left-radius:12px;border-bottom-right-radius:12px;z-index:3;
}
.gapp-phone-screen{position:absolute;inset:0;padding:34px 14px 14px;display:flex;flex-direction:column;gap:10px;}
.gapp-phone-topbar{display:flex;align-items:center;gap:8px;margin-bottom:6px;}
.gapp-phone-mark{width:22px;height:22px;border-radius:7px;background:rgba(16,185,129,.12);display:flex;align-items:center;justify-content:center;gap:1.5px;padding:4px;}
.gapp-phone-mark i{display:block;width:2.5px;border-radius:2px;background:var(--green,#10b981);}
.gapp-phone-title{font-family:var(--font-head);font-weight:800;font-size:12px;color:var(--text);}
.gapp-phone-row{height:11px;border-radius:5px;background:rgba(255,255,255,.06);}
.gapp-phone-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:10px;display:flex;flex-direction:column;gap:6px;}
.gapp-phone-stats{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
.gapp-phone-stat-num{font-family:var(--font-head);font-weight:800;font-size:15px;color:var(--teal,#14b8a6);}
.gapp-phone-stat-label{font-size:8.5px;color:var(--subtle,#64748b);}
.gapp-phone-bars{display:flex;align-items:flex-end;gap:5px;height:38px;margin-top:auto;}
.gapp-phone-bars i{flex:1;border-radius:3px;background:linear-gradient(180deg,var(--teal,#14b8a6),var(--green,#10b981));animation:gappBarPulse 2.2s ease-in-out infinite;}
.gapp-phone-bars i:nth-child(1){height:40%;animation-delay:0s;}
.gapp-phone-bars i:nth-child(2){height:85%;animation-delay:.15s;}
.gapp-phone-bars i:nth-child(3){height:60%;animation-delay:.3s;}
.gapp-phone-bars i:nth-child(4){height:100%;animation-delay:.45s;}
.gapp-phone-bars i:nth-child(5){height:50%;animation-delay:.6s;}
@keyframes gappBarPulse{0%,100%{opacity:.55;transform:scaleY(.85);}50%{opacity:1;transform:scaleY(1);}}
@media (prefers-reduced-motion:reduce){.gapp-phone-bars i{animation:none;}}

.gapp-badge-float{
  position:absolute;background:var(--surface,rgba(255,255,255,.06));border:1px solid var(--border);
  backdrop-filter:blur(6px);border-radius:12px;padding:9px 13px;font-size:12px;font-weight:700;
  color:var(--text);display:flex;align-items:center;gap:7px;box-shadow:0 12px 30px -10px rgba(0,0,0,.5);
}
.gapp-badge-float .dot{width:7px;height:7px;border-radius:50%;background:var(--green,#10b981);box-shadow:0 0 0 3px rgba(16,185,129,.2);}
.gapp-badge-1{top:8%;right:-6%;}
.gapp-badge-2{bottom:14%;left:-10%;}
@media (max-width:520px){.gapp-badge-1,.gapp-badge-2{display:none;}}

/* ── Feature strip ── */
.gapp-features{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--border);border:1px solid var(--border);border-radius:18px;overflow:hidden;margin:8px 0 52px;}
@media (max-width:720px){.gapp-features{grid-template-columns:1fr;}}
.gapp-feature{background:#060f0a;padding:26px 24px;}
.gapp-feature-mark{display:flex;align-items:flex-end;gap:3px;height:20px;margin-bottom:14px;}
.gapp-feature-mark i{width:4px;border-radius:2px;background:var(--teal,#14b8a6);}
.gapp-feature h3{font-family:var(--font-head);font-weight:700;font-size:15px;color:var(--text);margin-bottom:6px;}
.gapp-feature p{font-size:13px;color:var(--muted,#94a3b8);line-height:1.6;}

/* ── Platform switcher ── */
.gapp-switcher{display:inline-flex;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:12px;padding:4px;margin-bottom:24px;}
.gapp-switch-btn{
  font-family:var(--font-head);font-weight:700;font-size:13px;padding:9px 20px;border-radius:9px;
  background:transparent;border:none;color:var(--muted,#94a3b8);cursor:pointer;transition:all .15s ease;
}
.gapp-switch-btn.active{background:var(--green,#10b981);color:#04140d;}

.gapp-card{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:18px;padding:32px;}
.gapp-card h2{font-family:var(--font-head);font-weight:700;font-size:19px;color:var(--text);margin-bottom:4px;}
.gapp-card .gapp-card-sub{font-size:13px;color:var(--subtle,#64748b);margin-bottom:24px;}

.gapp-meta{color:var(--subtle,#64748b);font-size:12.5px;margin-top:12px;line-height:1.6;}
.gapp-steps{margin:20px 0 0;padding-left:0;list-style:none;counter-reset:gstep;}
.gapp-steps li{counter-increment:gstep;position:relative;padding-left:38px;color:#cbd5e1;font-size:13.5px;line-height:1.7;margin-bottom:14px;}
.gapp-steps li::before{
  content:counter(gstep);position:absolute;left:0;top:-1px;width:24px;height:24px;border-radius:7px;
  background:rgba(16,185,129,.12);color:var(--green,#10b981);font-family:var(--font-head);font-weight:800;font-size:12px;
  display:flex;align-items:center;justify-content:center;
}
.gapp-note{background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.22);border-radius:12px;padding:14px 16px;color:#fbbf24;font-size:12.5px;margin-top:22px;line-height:1.6;}
.gapp-qr{display:flex;align-items:center;gap:18px;flex-wrap:wrap;margin-top:20px;padding-top:20px;border-top:1px solid var(--border);}
.gapp-qr img{border-radius:10px;background:#fff;padding:7px;}
.gapp-qr strong{color:var(--text);font-size:13.5px;}
</style>

<div class="gapp-wrap">

  <!-- Hero -->
  <section class="gapp-hero">
    <div>
      <span class="gapp-eyebrow">● Available now</span>
      <h1>Take Devloom<br>with <span>you</span>.</h1>
      <p class="lede">
        Placement prep, flashcards, and messages — installed on your home screen like
        any other app. No Play Store review, no waiting.
      </p>

      <div class="gapp-cta-row">
        <button id="pwa-install-btn" class="gapp-btn-primary" style="display:none;" onclick="devloomInstallApp()">
          ⬇ Install now
        </button>
        <a href="#platform-instructions" class="gapp-btn-ghost">See install steps ↓</a>
      </div>
      <p class="gapp-hint" id="pwa-install-hint">
        The button above installs Devloom instantly if your browser supports it (Chrome, Edge on Android).
        Don't see it? Your browser needs the manual steps below — that's normal, not an error.
      </p>
    </div>

    <div class="gapp-device-stage">
      <div class="gapp-badge-float gapp-badge-1"><span class="dot"></span> Push notifications</div>
      <div class="gapp-badge-float gapp-badge-2"><span class="dot"></span> Works offline</div>
      <div class="gapp-phone">
        <div class="gapp-phone-screen">
          <div class="gapp-phone-topbar">
            <div class="gapp-phone-mark"><i style="height:40%;"></i><i style="height:100%;"></i><i style="height:65%;"></i></div>
            <span class="gapp-phone-title">Devloom</span>
          </div>
          <div class="gapp-phone-row" style="width:70%;"></div>
          <div class="gapp-phone-row" style="width:45%;opacity:.6;"></div>
          <div class="gapp-phone-stats">
            <div class="gapp-phone-card">
              <span class="gapp-phone-stat-num">128</span>
              <span class="gapp-phone-stat-label">MCQs done</span>
            </div>
            <div class="gapp-phone-card">
              <span class="gapp-phone-stat-num">6</span>
              <span class="gapp-phone-stat-label">Day streak</span>
            </div>
          </div>
          <div class="gapp-phone-card" style="flex:1;">
            <span class="gapp-phone-stat-label" style="margin-bottom:2px;">This week</span>
            <div class="gapp-phone-bars"><i></i><i></i><i></i><i></i><i></i></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Feature strip -->
  <section class="gapp-features">
    <div class="gapp-feature">
      <div class="gapp-feature-mark"><i style="height:40%;"></i><i style="height:100%;background:var(--green,#10b981);"></i><i style="height:65%;"></i></div>
      <h3>Installs in seconds</h3>
      <p>One tap adds a real icon to your home screen — no APK file, no app store queue.</p>
    </div>
    <div class="gapp-feature">
      <div class="gapp-feature-mark"><i style="height:70%;"></i><i style="height:45%;background:var(--green,#10b981);"></i><i style="height:100%;"></i></div>
      <h3>Push notifications</h3>
      <p>Get pinged the moment an admin replies or a project update lands — no need to keep a tab open.</p>
    </div>
    <div class="gapp-feature">
      <div class="gapp-feature-mark"><i style="height:100%;"></i><i style="height:60%;background:var(--green,#10b981);"></i><i style="height:80%;"></i></div>
      <h3>Works with patchy data</h3>
      <p>Already-visited screens keep working even when your connection drops.</p>
    </div>
  </section>

  <!-- Platform-specific instructions -->
  <section id="platform-instructions">
    <div class="gapp-switcher" role="tablist">
      <button class="gapp-switch-btn active" id="tab-btn-android" onclick="gappSwitchTab('android')">Android</button>
      <button class="gapp-switch-btn" id="tab-btn-iphone" onclick="gappSwitchTab('iphone')">iPhone</button>
    </div>

    <!-- Android panel -->
    <div id="tab-android" class="gapp-card">
      <h2>Set up on Android</h2>
      <p class="gapp-card-sub">Two ways to get there — pick whichever's easier.</p>

      <ol class="gapp-steps">
        <li>Tap <strong>Install now</strong> at the top of this page (works in Chrome or Edge).</li>
        <li>Confirm the install prompt your browser shows.</li>
        <li>Open Devloom from your home screen and log in.</li>
        <li>Allow notifications when asked, so replies and updates reach you.</li>
      </ol>

      <div class="gapp-qr">
        <?php if ($apkExists): ?>
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=<?= urlencode($absApkUrl) ?>" width="120" height="120" alt="QR code to download the Devloom APK">
          <div>
            <strong>Prefer a standalone APK instead?</strong>
            <p class="gapp-meta">
              <a href="<?= e($apkUrl) ?>" download style="color:var(--green,#10b981);font-weight:700;">Download the APK</a>
              (<?= $apkSizeMb ?> MB) or scan this code on your phone. Android 8.0+. Not from Google Play, so
              Android will warn it's from an "unknown source" — that's expected for direct installs.
            </p>
          </div>
        <?php else: ?>
          <div>
            <strong style="color:var(--subtle,#64748b);">Standalone APK not uploaded yet</strong>
            <p class="gapp-meta">The one-tap install above works today regardless. The site admin can add a
            native APK later — see <code>devloom-mobile/README.md</code> for build steps.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- iPhone panel -->
    <div id="tab-iphone" class="gapp-card" style="display:none;">
      <h2>Set up on iPhone</h2>
      <p class="gapp-card-sub">Apple doesn't offer a one-tap prompt, so this is a manual (but quick) step.</p>

      <ol class="gapp-steps">
        <li>Open this page in <strong>Safari</strong> — other browsers on iOS can't install apps.</li>
        <li>Tap the <strong>Share</strong> icon in the toolbar.</li>
        <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
        <li>Open Devloom from your home screen and log in.</li>
      </ol>

      <div class="gapp-note">
        ⚠ iOS limits background notifications for home-screen apps compared to Android. You'll still get
        alerts while Devloom is open or recently used.
      </div>
    </div>
  </section>

</div>

<script>
function gappSwitchTab(which) {
  document.getElementById('tab-android').style.display = which === 'android' ? '' : 'none';
  document.getElementById('tab-iphone').style.display   = which === 'iphone'  ? '' : 'none';
  document.getElementById('tab-btn-android').classList.toggle('active', which === 'android');
  document.getElementById('tab-btn-iphone').classList.toggle('active', which === 'iphone');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
