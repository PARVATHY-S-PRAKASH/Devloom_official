<?php
require_once __DIR__ . '/../config/db.php';
requireAdmin();

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_project') {
        $pid      = (int)$_POST['project_id'];
        $payment  = $_POST['payment']  !== '' ? (float)$_POST['payment']  : null;
        $duration = trim($_POST['duration'] ?? '');
        $status   = $_POST['status']   ?? 'pending';
        $note     = trim($_POST['code_note'] ?? '');
        $noteReady = $note ? 1 : 0;
        $paid     = isset($_POST['paid']) ? 1 : 0;

        $pdo->prepare("UPDATE projects SET payment=?,duration=?,status=?,code_note=?,note_ready=?,paid=? WHERE id=?")
            ->execute([$payment, $duration ?: null, $status, $note ?: null, $noteReady, $paid, $pid]);

        // Push a mobile notification to the project owner, if the mobile app is set up (safe no-op otherwise).
        if (file_exists(__DIR__ . '/../mobile_api/bootstrap.php')) {
            require_once __DIR__ . '/../mobile_api/bootstrap.php';
            $ownerStmt = $pdo->prepare("SELECT user_id, title FROM projects WHERE id=?");
            $ownerStmt->execute([$pid]);
            if ($owner = $ownerStmt->fetch()) {
                mobile_notify_user($pdo, (int)$owner['user_id'], 'Project updated', 'Status of "' . $owner['title'] . '" is now ' . statusLabel($status) . '.');
            }
        }

        // File upload — images + common document/archive types only
        $fileType = 'screenshot';
        if (!empty($_FILES['screenshots']['name'][0])) {
            foreach ($_FILES['screenshots']['tmp_name'] as $i => $tmp) {
                if (!$tmp || !is_uploaded_file($tmp)) continue;
                $fileEntry = [
                    'name'     => $_FILES['screenshots']['name'][$i],
                    'tmp_name' => $tmp,
                    'size'     => $_FILES['screenshots']['size'][$i] ?? 0,
                ];
                if (!isAllowedUpload($fileEntry, ALLOWED_UPLOAD_EXTS)) continue; // skip disallowed/oversized files
                $origName = $_FILES['screenshots']['name'][$i];
                $ext      = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                $fname    = 'ss_' . $pid . '_' . time() . '_' . $i . ($ext ? '.' . $ext : '');
                if (!is_dir(UPLOAD_PATH)) mkdir(UPLOAD_PATH, 0755, true);
                move_uploaded_file($tmp, UPLOAD_PATH . $fname);
                try {
                    $pdo->prepare("INSERT INTO screenshots (project_id, filename, original_name, file_type) VALUES (?,?,?,?)")
                        ->execute([$pid, $fname, $origName, 'screenshot']);
                } catch (PDOException $columErr) {
                    // Fallback if migration hasn't run yet
                    $pdo->prepare("INSERT INTO screenshots (project_id, filename) VALUES (?,?)")
                        ->execute([$pid, $fname]);
                }
            }
        }

        flash('success', 'Project updated successfully.');
        header('Location: /devloom/admin/index.php');
        exit;
    }

    if ($action === 'delete_screenshot') {
        $sid = (int)$_POST['screenshot_id'];
        $row = $pdo->prepare("SELECT filename FROM screenshots WHERE id=?");
        $row->execute([$sid]);
        $ss = $row->fetch();
        if ($ss) {
            @unlink(UPLOAD_PATH . $ss['filename']);
            $pdo->prepare("DELETE FROM screenshots WHERE id=?")->execute([$sid]);
        }
        flash('success', 'File removed.');
        header('Location: /devloom/admin/index.php');
        exit;
    }

    if ($action === 'mark_paid') {
        $pid = (int)$_POST['project_id'];
        $pdo->prepare("UPDATE projects SET paid=1 WHERE id=?")->execute([$pid]);
        flash('success', 'Project marked as paid.');
        header('Location: /devloom/admin/index.php');
        exit;
    }

    if ($action === 'reply_message') {
        $uid  = (int)$_POST['user_id'];
        $body = trim($_POST['body'] ?? '');
        $hasFile = !empty($_FILES['attachments']['name'][0]);
        if ($uid && ($body || $hasFile)) {
            $pdo->prepare("INSERT INTO user_messages (user_id,sender,subject,body,is_read) VALUES (?,?,?,?,0)")
                ->execute([$uid, 'admin', '', $body]);
            $msgId = (int)$pdo->lastInsertId();

            // Push a mobile notification for the new message, if the mobile app is set up (safe no-op otherwise).
            if (file_exists(__DIR__ . '/../mobile_api/bootstrap.php')) {
                require_once __DIR__ . '/../mobile_api/bootstrap.php';
                mobile_notify_user($pdo, $uid, 'New message from Devloom', $body ?: 'You have a new attachment.');
            }
            if ($hasFile) {
                $uploadDir = UPLOAD_PATH_MESSAGES;
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                foreach ($_FILES['attachments']['tmp_name'] as $i => $tmp) {
                    if (!$tmp || !is_uploaded_file($tmp)) continue;
                    $fileEntry = [
                        'name'     => $_FILES['attachments']['name'][$i],
                        'tmp_name' => $tmp,
                        'size'     => $_FILES['attachments']['size'][$i] ?? 0,
                    ];
                    if (!isAllowedUpload($fileEntry, ALLOWED_UPLOAD_EXTS)) continue;
                    $origName = $_FILES['attachments']['name'][$i];
                    $size     = $_FILES['attachments']['size'][$i];
                    $mime     = mime_content_type($tmp);
                    $ext      = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                    $fname    = 'msg_' . $msgId . '_' . time() . '_' . $i . ($ext ? '.' . $ext : '');
                    move_uploaded_file($tmp, $uploadDir . $fname);
                    $pdo->prepare("INSERT INTO message_attachments (message_id,filename,original_name,file_size,mime_type) VALUES (?,?,?,?,?)")
                        ->execute([$msgId, $fname, $origName, $size, $mime]);
                }
            }
            flash('success', 'Reply sent.');
        }
        header('Location: /devloom/admin/index.php#tab-messages');
        exit;
    }

    if ($action === 'delete_user_message') {
        $mid = (int)$_POST['msg_id'];
        $pdo->prepare("DELETE FROM user_messages WHERE id=?")->execute([$mid]);
        flash('success', 'Message deleted.');
        header('Location: /devloom/admin/index.php');
        exit;
    }

    // ── Upload Payment QR for a project (one-time, replaces old one) ──
    if ($action === 'upload_payment_qr') {
        $pid    = (int)$_POST['project_id'];
        $note   = trim($_POST['qr_note'] ?? '');
        $amount = $_POST['qr_amount'] !== '' ? (float)$_POST['qr_amount'] : null;
        if ($pid && !empty($_FILES['qr_image']['tmp_name']) && is_uploaded_file($_FILES['qr_image']['tmp_name'])) {
            $qrDir = UPLOAD_PATH_QR;
            if (!is_dir($qrDir)) mkdir($qrDir, 0755, true);
            $ext   = strtolower(pathinfo($_FILES['qr_image']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['png','jpg','jpeg','gif','webp'])) {
                flash('error', 'QR must be an image (PNG/JPG/GIF/WEBP).');
            } else {
                try {
                    // Delete old QR file if exists
                    $old = $pdo->prepare("SELECT filename FROM payment_qr WHERE project_id=?");
                    $old->execute([$pid]);
                    $oldRow = $old->fetch();
                    if ($oldRow) @unlink($qrDir . $oldRow['filename']);
                    $fname = 'qr_' . $pid . '_' . time() . '.' . $ext;
                    move_uploaded_file($_FILES['qr_image']['tmp_name'], $qrDir . $fname);
                    $pdo->prepare("INSERT INTO payment_qr (project_id,filename,amount,note,used) VALUES (?,?,?,?,0)
                                   ON DUPLICATE KEY UPDATE filename=VALUES(filename),amount=VALUES(amount),note=VALUES(note),used=0,uploaded_at=NOW()")
                        ->execute([$pid, $fname, $amount, $note]);
                    flash('success', 'Payment QR uploaded! Client can now see and use it once.');
                } catch (PDOException $e) {
                    flash('error', 'Table missing — please run database/migrate.sql first.');
                }
            }
        } else {
            flash('error', 'Please select a QR image to upload.');
        }
        header('Location: /devloom/admin/index.php#tab-projects');
        exit;
    }

    // ── Admin revokes a QR ──
    if ($action === 'revoke_payment_qr') {
        $pid = (int)$_POST['project_id'];
        $qrDir = UPLOAD_PATH_QR;
        try {
            $row = $pdo->prepare("SELECT filename FROM payment_qr WHERE project_id=?");
            $row->execute([$pid]);
            $r = $row->fetch();
            if ($r) {
                @unlink($qrDir . $r['filename']);
                $pdo->prepare("DELETE FROM payment_qr WHERE project_id=?")->execute([$pid]);
                flash('success', 'QR code revoked and deleted.');
            }
        } catch (PDOException $e) {
            flash('error', 'Table missing — please run database/migrate.sql first.');
        }
        header('Location: /devloom/admin/index.php#tab-projects');
        exit;
    }
}

// ── Data fetch ────────────────────────────────────────────────
$projects = $pdo->query("
    SELECT p.*, u.name as user_name, u.username as user_username, u.email as user_email, u.avatar as user_avatar
    FROM projects p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.created_at DESC
")->fetchAll();

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

$screenshots = [];
if ($projects) {
    $ids   = array_column($projects, 'id');
    $ph    = implode(',', array_fill(0, count($ids), '?'));
    $stmtS = $pdo->prepare("SELECT * FROM screenshots WHERE project_id IN ($ph)");
    $stmtS->execute($ids);
    foreach ($stmtS->fetchAll() as $ss) {
        $screenshots[$ss['project_id']][] = $ss;
    }
}

$contacts = $pdo->query("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 20")->fetchAll();

$userMsgs = $pdo->query("
    SELECT m.*, u.name as user_name, u.username as user_username, u.avatar as user_avatar, u.email as user_email
    FROM user_messages m
    JOIN users u ON u.id = m.user_id
    ORDER BY m.user_id, m.created_at ASC
")->fetchAll();

$unreadMsg = $pdo->query("SELECT COUNT(*) FROM user_messages WHERE sender='user' AND is_read=0")->fetchColumn();

// Mark user messages as read now that admin is viewing
$pdo->query("UPDATE user_messages SET is_read=1 WHERE sender='user' AND is_read=0");

// Fetch all message attachments indexed by message_id
$msgAttachments = [];
if ($userMsgs) {
    $mids = array_column($userMsgs, 'id');
    $ph   = implode(',', array_fill(0, count($mids), '?'));
    $attQ = $pdo->prepare("SELECT * FROM message_attachments WHERE message_id IN ($ph) ORDER BY id ASC");
    $attQ->execute($mids);
    foreach ($attQ->fetchAll() as $a) { $msgAttachments[$a['message_id']][] = $a; }
}

$noteReqs = count(array_filter($projects, fn($p) => $p['requested_note'] && !$p['note_ready']));

// Fetch all QR codes indexed by project_id
$qrCodes = [];
try {
    if ($projects) {
        $ids = array_column($projects, 'id');
        $ph  = implode(',', array_fill(0, count($ids), '?'));
        $qrQ = $pdo->prepare("SELECT * FROM payment_qr WHERE project_id IN ($ph)");
        $qrQ->execute($ids);
        foreach ($qrQ->fetchAll() as $qr) { $qrCodes[$qr['project_id']] = $qr; }
    }
} catch (PDOException $e) {
    // payment_qr table not yet created — run migrate.sql to add it
}

// Group messages by user_id
$msgsByUser = [];
foreach ($userMsgs as $m) { $msgsByUser[$m['user_id']][] = $m; }

// Also make userMsgs accessible per user for client cards
$userMsgsFlat = $userMsgs;

$flashOk  = flash('success');
$flashErr = flash('error');

$statusOptions = ['pending','in-progress','review','completed'];

$pageTitle  = 'Admin Panel';
$activePage = 'admin';
include __DIR__ . '/../includes/header.php';

/* ── File helpers for message attachments ─────────────────── */
function adminMsgFileIcon(string $ext): string {
    return ['pdf'=>'📄','doc'=>'📝','docx'=>'📝','xls'=>'📊','xlsx'=>'📊',
            'ppt'=>'📊','pptx'=>'📊','csv'=>'📊','zip'=>'🗜','rar'=>'🗜',
            '7z'=>'🗜','txt'=>'📃','mp4'=>'🎬','mp3'=>'🎵','jpg'=>'🖼',
            'jpeg'=>'🖼','png'=>'🖼','gif'=>'🖼','webp'=>'🖼','svg'=>'🖼',
           ][$ext] ?? '📎';
}
function adminFormatSize(int $bytes): string {
    if ($bytes < 1024)    return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes/1024,1) . ' KB';
    return round($bytes/1048576,1) . ' MB';
}
?>

<div class="container" style="padding-top:40px;padding-bottom:60px;">

  <?php if ($flashErr): ?><div class="alert alert-error"><?= e($flashErr) ?></div><?php endif; ?>
  <?php if ($flashOk):  ?><div class="alert alert-success"><?= e($flashOk) ?></div><?php endif; ?>

  <!-- Page Header -->
  <div class="page-header">
    <div class="flex gap-16" style="align-items:center;">
      <div class="avatar admin">🛡</div>
      <div>
        <h1 class="heading-md">Admin Panel</h1>
        <p class="text-muted" style="margin-top:4px;font-size:14px;">Manage clients, projects, messages and files</p>
      </div>
    </div>
    <?php if ($noteReqs): ?>
    <span class="badge badge-amber" style="font-size:13px;padding:8px 16px;">🤖 <?= $noteReqs ?> AI Note <?= $noteReqs>1?'Requests':'Request' ?> Pending</span>
    <?php endif; ?>
  </div>

  <!-- Stats -->
  <div class="grid-4 mb-32">
    <?php foreach ([
      ['Total Users',    count($users),     '#10b981'],
      ['Total Projects', count($projects),  '#60a5fa'],
      ['Completed',      count(array_filter($projects,fn($p)=>$p['status']==='completed')), '#34d399'],
      ['Unread Messages',$unreadMsg,        '#f59e0b'],
    ] as [$l,$v,$c]): ?>
    <div class="card stat-card">
      <div class="stat-num" style="color:<?= $c ?>"><?= $v ?></div>
      <div class="stat-label"><?= $l ?></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Global Admin Search -->
  <div style="margin-bottom:20px;position:relative;">
    <input
      type="text"
      id="admin-global-search"
      placeholder="🔍  Search projects, clients, emails, tech stacks…"
      oninput="adminGlobalSearch(this.value)"
      style="
        width:100%;box-sizing:border-box;
        background:rgba(255,255,255,.06);
        border:1.5px solid rgba(255,255,255,.12);
        border-radius:14px;color:#e2e8f0;font-size:14px;
        padding:12px 48px 12px 18px;outline:none;
        transition:border-color .2s,box-shadow .2s;font-family:inherit;
      "
      onfocus="this.style.borderColor='rgba(16,185,129,.5)';this.style.boxShadow='0 0 0 3px rgba(16,185,129,.08)'"
      onblur="this.style.borderColor='rgba(255,255,255,.12)';this.style.boxShadow='none'"
    >
    <span id="admin-global-count" style="position:absolute;right:16px;top:50%;transform:translateY(-50%);font-size:11px;color:var(--muted);pointer-events:none;"></span>
  </div>

  <!-- Tabs -->
  <div class="tabs" data-tabbtns="admin">
    <button class="tab-btn admin-tab active" onclick="switchTab('admin','tab-projects',this)">All Projects</button>
    <button class="tab-btn admin-tab"        onclick="switchTab('admin','tab-users',this)">Clients</button>
    <button class="tab-btn admin-tab"        onclick="switchTab('admin','tab-messages',this)">
      Messages <?php if ($unreadMsg): ?><span class="badge badge-amber" style="padding:1px 7px;font-size:10px;"><?= $unreadMsg ?></span><?php endif; ?>
    </button>
    <button class="tab-btn admin-tab"        onclick="switchTab('admin','tab-payment-qr',this)">
      💳 Payment QR <?php $pendingQrCount = count(array_filter($projects, fn($p) => !$p['paid'] && $p['payment'] && !isset($qrCodes[$p['id']]))); if ($pendingQrCount): ?><span class="badge badge-red" style="padding:1px 7px;font-size:10px;"><?= $pendingQrCount ?></span><?php endif; ?>
    </button>
    <button class="tab-btn admin-tab"        onclick="switchTab('admin','tab-contacts',this)">
      📬 Enquiries <?php if (count(array_filter($contacts, fn($c) => !$c['is_read']))): ?><span class="badge badge-red" style="padding:1px 7px;font-size:10px;"><?= count(array_filter($contacts, fn($c) => !$c['is_read'])) ?></span><?php endif; ?>
    </button>
  </div>

  <!-- Tab: All Projects -->
  <div id="tab-projects" data-tabgroup="admin" class="active">
    <?php foreach ($projects as $p):
      $shots = $screenshots[$p['id']] ?? [];
    ?>
    <div class="card mb-12 admin-project-card" data-search="<?= htmlspecialchars(strtolower($p['title'].' '.$p['description'].' '.$p['tech_stack'].' '.$p['user_name'].' '.$p['user_email'].' '.$p['status']), ENT_QUOTES) ?>">
      <div class="flex-between flex-wrap gap-12">
        <div class="flex gap-12" style="align-items:center;flex:1;min-width:200px;">
          <div class="nav-avatar admin" style="width:40px;height:40px;font-size:13px;flex-shrink:0;"><?= e($p['user_avatar']) ?></div>
          <div>
            <div class="flex gap-8 flex-wrap mb-4" style="align-items:center;">
              <span class="heading-sm"><?= e($p['title']) ?></span>
              <span class="badge <?= statusClass($p['status']) ?>"><?= statusLabel($p['status']) ?></span>
              <?php if ($p['requested_note'] && !$p['note_ready']): ?>
              <span class="badge badge-amber">🤖 AI Note Requested</span>
              <?php endif; ?>
            </div>
            <span class="text-muted" style="font-size:13px;"><?= e($p['user_name']) ?> · <?= e($p['user_email']) ?> · <?= date('d M Y', strtotime($p['created_at'])) ?></span>
            <?php if ($p['description']): ?>
            <p style="margin-top:8px;font-size:13px;color:#94a3b8;line-height:1.6;max-width:520px;"><?= e($p['description']) ?></p>
            <?php endif; ?>
            <?php if ($p['tech_stack']): ?>
            <span class="badge badge-blue" style="margin-top:6px;"><?= e($p['tech_stack']) ?></span>
            <?php endif; ?>
          </div>
        </div>
        <div class="flex gap-8 flex-wrap" style="align-items:center;">
          <?php if ($p['payment']): ?><span class="badge badge-green">₹<?= number_format($p['payment'],0) ?></span><?php else: ?><span class="badge badge-muted">No Quote</span><?php endif; ?>
          <span class="badge <?= $p['paid']?'badge-green':'badge-red' ?>"><?= $p['paid']?'Paid':'Unpaid' ?></span>
          <button class="btn btn-amber btn-sm" onclick="openModal('edit-<?= $p['id'] ?>')">⚙ Manage</button>
        </div>
      </div>

      <!-- File previews in project card -->
      <?php if ($shots): ?>
      <div class="flex gap-8 mt-12 flex-wrap" style="align-items:center;">
        <span style="font-size:12px;color:var(--muted);">📎 Files:</span>
        <?php foreach ($shots as $ss):
          $fileUrl = filePublicUrl($ss['filename']);
          $isImg   = isImageFile($ss['filename']);
          $icon    = fileIcon($ss['filename']);
          $dispName = fileDisplayName($ss);
        ?>
        <?php if ($isImg): ?>
        <a href="<?= e($fileUrl) ?>" target="_blank" title="<?= e($dispName) ?>"
           style="display:inline-flex;align-items:center;gap:5px;background:rgba(99,102,241,.12);border:1px solid rgba(99,102,241,.25);border-radius:8px;padding:4px 10px;text-decoration:none;color:#a5b4fc;font-size:12px;">
          <img src="<?= e($fileUrl) ?>" alt="<?= e($dispName) ?>"
               style="width:24px;height:24px;object-fit:cover;border-radius:4px;vertical-align:middle;"
               onerror="this.style.display='none';this.nextSibling.style.display='inline';">
          <span style="display:none;">🖼</span>
          <?= e(strlen($dispName) > 20 ? substr($dispName,0,18).'…' : $dispName) ?>
        </a>
        <?php else: ?>
        <a href="<?= e($fileUrl) ?>" target="_blank" title="<?= e($dispName) ?>"
           style="display:inline-flex;align-items:center;gap:5px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.2);border-radius:8px;padding:4px 10px;text-decoration:none;color:#6ee7b7;font-size:12px;">
          <?= $icon ?> <?= e(strlen($dispName) > 20 ? substr($dispName,0,18).'…' : $dispName) ?>
        </a>
        <?php endif; ?>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Edit Project Modal -->
    <div class="modal-overlay" id="edit-<?= $p['id'] ?>">
      <div class="modal-box" style="max-width:640px;">
        <div class="modal-header">
          <span class="modal-title">⚙ Manage: <?= e($p['title']) ?></span>
          <button class="modal-close" onclick="closeModal('edit-<?= $p['id'] ?>')">✕</button>
        </div>

        <form method="POST" enctype="multipart/form-data"><?= csrf_field() ?>
          <input type="hidden" name="action"     value="update_project">
          <input type="hidden" name="project_id" value="<?= $p['id'] ?>">

          <!-- Project Details (read-only) -->
          <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:16px;margin-bottom:20px;">
            <p style="font-size:11px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px;">📋 Project Details from Client</p>
            <p style="font-size:14px;color:#e2e8f0;line-height:1.7;margin-bottom:10px;"><?= e($p['description']) ?></p>
            <?php if ($p['tech_stack']): ?>
            <span class="badge badge-blue">Tech: <?= e($p['tech_stack']) ?></span>
            <?php endif; ?>
            <span class="badge badge-muted" style="margin-left:6px;">Submitted: <?= date('d M Y', strtotime($p['created_at'])) ?></span>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Payment (₹)</label>
              <input type="number" name="payment" class="form-control" value="<?= $p['payment'] ?>" placeholder="45000">
            </div>
            <div class="form-group">
              <label class="form-label">Duration</label>
              <input type="text" name="duration" class="form-control" value="<?= e($p['duration']??'') ?>" placeholder="4 weeks">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Status</label>
              <select name="status" class="form-control">
                <?php foreach ($statusOptions as $s): ?>
                <option value="<?= $s ?>" <?= $p['status']===$s?'selected':'' ?>><?= statusLabel($s) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group" style="display:flex;align-items:flex-end;">
              <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding-bottom:11px;">
                <input type="checkbox" name="paid" <?= $p['paid']?'checked':'' ?> style="width:16px;height:16px;accent-color:var(--green);">
                <span class="form-label" style="margin:0;">Mark as Paid</span>
              </label>
            </div>
          </div>

          <!-- File upload (screenshots + project files) -->
          <div class="form-group">
            <label class="form-label">📎 Upload Files</label>
            <input type="file" name="screenshots[]" multiple class="form-control" style="padding:8px;" accept="image/*,.pdf,.zip,.rar,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.mp4,.mp3">
            <p style="font-size:11px;color:var(--muted);margin-top:5px;">Accepted: images, PDF, ZIP, Word, Excel, PowerPoint, and more.</p>

            <?php if ($shots): ?>
            <div style="margin-top:12px;">
              <p style="font-size:11px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;">Uploaded Files</p>
              <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;">
                <?php foreach ($shots as $ss):
                  $fileUrl  = filePublicUrl($ss['filename']);
                  $isImg    = isImageFile($ss['filename']);
                  $icon     = fileIcon($ss['filename']);
                  $dispName = fileDisplayName($ss);
                ?>
                <div style="position:relative;border-radius:8px;overflow:hidden;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);">
                  <?php if ($isImg): ?>
                  <img src="<?= e($fileUrl) ?>" alt="<?= e($dispName) ?>"
                       style="width:100%;height:80px;object-fit:cover;display:block;"
                       onerror="this.parentNode.querySelector('.no-img').style.display='flex';this.style.display='none';">
                  <div class="no-img" style="display:none;height:80px;align-items:center;justify-content:center;font-size:28px;background:rgba(255,255,255,.04);">🖼</div>
                  <?php else: ?>
                  <div style="height:80px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;background:rgba(255,255,255,.03);">
                    <span style="font-size:28px;"><?= $icon ?></span>
                    <span style="font-size:10px;color:var(--muted);text-transform:uppercase;"><?= strtoupper(pathinfo($ss['filename'],PATHINFO_EXTENSION)) ?></span>
                  </div>
                  <?php endif; ?>
                  <div style="padding:5px 6px;display:flex;align-items:center;justify-content:space-between;gap:4px;">
                    <a href="<?= e($fileUrl) ?>" target="_blank"
                       style="color:#94a3b8;font-size:11px;text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;"
                       title="<?= e($dispName) ?>">🔍 <?= e(strlen($dispName)>14?substr($dispName,0,12).'…':$dispName) ?></a>
                    <button type="button"
                      onclick="if(confirm('Delete this file?')){document.getElementById('del-ss-form-<?= $ss['id'] ?>').submit();}"
                      style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.2);color:#f87171;border-radius:5px;cursor:pointer;font-size:11px;padding:2px 6px;">✕</button>
                  </div>
                </div>
                <?php endforeach; ?>
              </div>
            </div>
            <?php endif; ?>
          </div>

          <!-- AI Code Note -->
          <div class="form-group">
            <div class="flex-between mb-8">
              <label class="form-label" style="margin:0;">🤖 AI Code Note for Client</label>
              <button type="button" id="aiBtn_<?= $p['id'] ?>" class="btn btn-purple btn-sm"
                onclick="generateAINote(<?= $p['id'] ?>, <?= json_encode($p['title']) ?>, <?= json_encode($p['tech_stack']) ?>, <?= json_encode($p['description']) ?>)">
                ✨ Generate with Claude AI
              </button>
            </div>
            <?php if ($p['requested_note'] && !$p['note_ready']): ?>
            <div class="alert alert-warn" style="margin-bottom:8px;">⚠ Client has requested this note.</div>
            <?php endif; ?>
            <textarea id="codeNote_<?= $p['id'] ?>" name="code_note" class="form-control form-mono" rows="6"
              placeholder="AI-generated or manually written project explanation for the client..."><?= e($p['code_note']??'') ?></textarea>
          </div>

          <div class="flex gap-8">
            <button type="submit" class="btn btn-primary" style="flex:1;">Save Changes ✓</button>
            <button type="button" class="btn btn-ghost" onclick="closeModal('edit-<?= $p['id'] ?>')">Cancel</button>
          </div>
        </form>

        <!-- Payment QR Upload (separate form, below main form) -->
        <?php $existingQr = $qrCodes[$p['id']] ?? null; ?>
        <div style="margin-top:20px;padding-top:20px;border-top:1px solid rgba(255,255,255,.08);">
          <div style="font-size:12px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:14px;">
            💳 Payment QR Code for Client
          </div>

          <?php if ($existingQr): ?>
          <!-- Show existing QR -->
          <div style="display:flex;align-items:flex-start;gap:16px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:16px;margin-bottom:14px;">
            <img src="/devloom/uploads/qr/<?= e($existingQr['filename']) ?>"
                 alt="Payment QR"
                 style="width:110px;height:110px;object-fit:contain;border-radius:8px;background:#fff;padding:6px;flex-shrink:0;">
            <div style="flex:1;">
              <div style="font-size:13px;color:#10b981;font-weight:700;margin-bottom:6px;">✅ QR Active<?= $existingQr['used'] ? ' <span style="color:#f87171;">(Already Used)</span>' : '' ?></div>
              <?php if ($existingQr['amount']): ?>
              <div style="font-size:13px;color:#e2e8f0;margin-bottom:4px;">Amount: <strong style="color:#34d399;">₹<?= number_format($existingQr['amount'],0) ?></strong></div>
              <?php endif; ?>
              <?php if ($existingQr['note']): ?>
              <div style="font-size:12px;color:#94a3b8;margin-bottom:6px;"><?= e($existingQr['note']) ?></div>
              <?php endif; ?>
              <div style="font-size:11px;color:var(--muted);">Uploaded <?= date('d M Y, h:i A', strtotime($existingQr['uploaded_at'])) ?></div>
              <?php if ($existingQr['used']): ?>
              <div style="margin-top:8px;font-size:12px;color:#f59e0b;">⚠ This QR has been used by the client. Upload a new one if needed.</div>
              <?php endif; ?>
            </div>
          </div>
          <!-- Revoke form -->
          <form method="POST" style="margin-bottom:12px;" onsubmit="return confirm('Delete this QR? Client will no longer see it.');"><?= csrf_field() ?>
            <input type="hidden" name="action" value="revoke_payment_qr">
            <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-sm" style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.25);color:#f87171;font-size:12px;">🗑 Revoke & Delete QR</button>
          </form>
          <?php endif; ?>

          <!-- Upload/Replace QR form -->
          <form method="POST" enctype="multipart/form-data"><?= csrf_field() ?>
            <input type="hidden" name="action" value="upload_payment_qr">
            <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label" style="font-size:12px;">QR Image (PNG/JPG)</label>
                <input type="file" name="qr_image" accept="image/*" class="form-control" style="padding:8px;" required>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-size:12px;">Amount (₹) shown on QR page</label>
                <input type="number" name="qr_amount" class="form-control" value="<?= $p['payment'] ?>" placeholder="<?= $p['payment'] ?? '45000' ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:12px;">Note for client (optional)</label>
              <input type="text" name="qr_note" class="form-control" placeholder="e.g. Scan to pay via GPay / PhonePe" value="<?= $existingQr ? e($existingQr['note']) : '' ?>">
            </div>
            <button type="submit" class="btn btn-primary btn-sm" style="width:100%;">
              <?= $existingQr ? '🔄 Replace QR Code' : '📤 Upload Payment QR' ?>
            </button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Standalone file-delete forms (outside modal to avoid nested <form>) -->
  <?php foreach ($projects as $p):
    $shots = $screenshots[$p['id']] ?? [];
    foreach ($shots as $ss): ?>
  <form id="del-ss-form-<?= $ss['id'] ?>" method="POST" style="display:none;">
    <?= csrf_field() ?>
    <input type="hidden" name="action"        value="delete_screenshot">
    <input type="hidden" name="screenshot_id" value="<?= $ss['id'] ?>">
  </form>
  <?php endforeach; endforeach; ?>

  <!-- Tab: Clients -->
  <div id="tab-users" data-tabgroup="admin">
    <div class="grid-2">
      <?php foreach ($users as $u):
        $uProjects   = array_values(array_filter($projects, fn($p) => $p['user_id'] == $u['id']));
        $uCompleted  = count(array_filter($uProjects, fn($p) => $p['status'] === 'completed'));
        $uInprog     = count(array_filter($uProjects, fn($p) => $p['status'] === 'in-progress'));
        $uRevenue    = array_sum(array_column(array_filter($uProjects, fn($p) => $p['paid']), 'payment'));
        $uMsgs       = array_filter($userMsgs, fn($m) => $m['user_id'] == $u['id']);
        $uReviews    = $pdo->prepare("SELECT * FROM reviews WHERE user_id = ? ORDER BY created_at DESC");
        $uReviews->execute([$u['id']]);
        $uReviewList = $uReviews->fetchAll();
        $avgRating   = $uReviewList ? round(array_sum(array_column($uReviewList,'rating')) / count($uReviewList), 1) : null;
      ?>
      <!-- Client Card -->
      <div class="card" style="cursor:pointer;transition:border-color .2s,transform .15s;" 
           onclick="openModal('client-<?= $u['id'] ?>')"
           onmouseenter="this.style.borderColor='rgba(16,185,129,.4)';this.style.transform='translateY(-2px)'"
           onmouseleave="this.style.borderColor='';this.style.transform=''">
        <div class="flex gap-12 mb-16" style="align-items:center;">
          <div class="avatar" style="width:50px;height:50px;font-size:17px;flex-shrink:0;"><?= e($u['avatar']) ?></div>
          <div style="flex:1;min-width:0;">
            <div class="heading-sm" style="font-size:15px;"><?= e($u['name']) ?></div>
            <div class="text-muted" style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($u['username'] ?? '-') ?><?= !empty($u['email']) ? ' · ' . e($u['email']) : '' ?></div>
          </div>
          <?php if ($avgRating): ?>
          <div style="text-align:right;">
            <div style="font-size:16px;color:#f59e0b;font-weight:700;"><?= $avgRating ?> ★</div>
            <div style="font-size:10px;color:var(--muted);"><?= count($uReviewList) ?> review<?= count($uReviewList)!=1?'s':'' ?></div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Stats row -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px;">
          <div style="text-align:center;background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.15);border-radius:8px;padding:8px 4px;">
            <div style="font-size:18px;font-weight:800;color:#10b981;"><?= count($uProjects) ?></div>
            <div style="font-size:10px;color:var(--muted);">Projects</div>
          </div>
          <div style="text-align:center;background:rgba(96,165,250,.08);border:1px solid rgba(96,165,250,.15);border-radius:8px;padding:8px 4px;">
            <div style="font-size:18px;font-weight:800;color:#60a5fa;"><?= $uCompleted ?></div>
            <div style="font-size:10px;color:var(--muted);">Done</div>
          </div>
          <div style="text-align:center;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.15);border-radius:8px;padding:8px 4px;">
            <div style="font-size:14px;font-weight:800;color:#f59e0b;"><?= $uRevenue ? '₹'.number_format($uRevenue,0) : '—' ?></div>
            <div style="font-size:10px;color:var(--muted);">Earned</div>
          </div>
        </div>

        <div class="flex gap-8 flex-wrap" style="align-items:center;justify-content:space-between;">
          <span class="badge badge-muted" style="font-size:11px;">Joined <?= date('d M Y', strtotime($u['created_at'])) ?></span>
          <span style="font-size:12px;color:#10b981;font-weight:600;">View All Projects →</span>
        </div>
      </div>

      <!-- Client Detail Modal -->
      <div class="modal-overlay" id="client-<?= $u['id'] ?>">
        <div class="modal-box" style="max-width:720px;">
          <div class="modal-header">
            <div style="display:flex;align-items:center;gap:12px;">
              <div class="avatar" style="width:40px;height:40px;font-size:14px;"><?= e($u['avatar']) ?></div>
              <div>
                <span class="modal-title"><?= e($u['name']) ?></span>
                <div style="font-size:12px;color:var(--muted);margin-top:2px;"><?= e($u['email']) ?> · Joined <?= date('d M Y', strtotime($u['created_at'])) ?></div>
              </div>
            </div>
            <button class="modal-close" onclick="closeModal('client-<?= $u['id'] ?>')">✕</button>
          </div>

          <!-- Summary stats -->
          <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:24px;">
            <?php foreach ([
              ['Projects',  count($uProjects),  '#60a5fa'],
              ['Completed', $uCompleted,        '#10b981'],
              ['In Progress',$uInprog,          '#f59e0b'],
              ['Revenue',   $uRevenue ? '₹'.number_format($uRevenue,0) : '—', '#34d399'],
            ] as [$lbl,$val,$col]): ?>
            <div style="text-align:center;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:12px 8px;">
              <div style="font-size:20px;font-weight:800;color:<?= $col ?>;"><?= $val ?></div>
              <div style="font-size:11px;color:var(--muted);"><?= $lbl ?></div>
            </div>
            <?php endforeach; ?>
          </div>

          <!-- All projects -->
          <h4 style="font-size:13px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;">📋 All Projects</h4>
          <?php if ($uProjects): ?>
          <div style="display:flex;flex-direction:column;gap:8px;max-height:300px;overflow-y:auto;margin-bottom:20px;">
            <?php foreach ($uProjects as $up):
              $upShots = $screenshots[$up['id']] ?? [];
            ?>
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:12px 14px;">
              <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                <div>
                  <div style="font-weight:600;font-size:14px;color:#f1f5f9;margin-bottom:3px;"><?= e($up['title']) ?></div>
                  <div style="font-size:12px;color:var(--muted);"><?= date('d M Y', strtotime($up['created_at'])) ?><?= $up['tech_stack'] ? ' · '.e($up['tech_stack']) : '' ?></div>
                </div>
                <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
                  <span class="badge <?= statusClass($up['status']) ?>"><?= statusLabel($up['status']) ?></span>
                  <?php if ($up['payment']): ?>
                  <span class="badge badge-green">₹<?= number_format($up['payment'],0) ?></span>
                  <?php endif; ?>
                  <?php if ($upShots): ?>
                  <span class="badge badge-muted">📎 <?= count($upShots) ?> file<?= count($upShots)!=1?'s':'' ?></span>
                  <?php endif; ?>
                  <button class="btn btn-amber btn-sm" onclick="closeModal('client-<?= $u['id'] ?>');openModal('edit-<?= $up['id'] ?>')">⚙ Manage</button>
                </div>
              </div>
              <?php if ($up['description']): ?>
              <p style="font-size:12px;color:#64748b;margin-top:8px;line-height:1.6;"><?= e(strlen($up['description'])>120 ? substr($up['description'],0,120).'…' : $up['description']) ?></p>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
          <?php else: ?>
          <p class="text-muted" style="font-size:13px;margin-bottom:20px;">No projects submitted yet.</p>
          <?php endif; ?>

          <!-- Reviews by this client -->
          <?php if ($uReviewList): ?>
          <h4 style="font-size:13px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;">⭐ Client Reviews</h4>
          <div style="display:flex;flex-direction:column;gap:8px;max-height:200px;overflow-y:auto;">
            <?php
            $adminFaceMap  = [1=>'😞',2=>'😐',3=>'🙂',4=>'😊',5=>'🤩'];
            $adminFaceText = [1=>'Terrible',2=>'Below Avg',3=>'Okay',4=>'Good',5=>'Excellent'];
            foreach ($uReviewList as $rv):
              $stars  = str_repeat('★', $rv['rating']) . str_repeat('☆', 5 - $rv['rating']);
              $rcols  = ['','#ef4444','#f97316','#eab308','#22c55e','#10b981'];
              $rcol   = $rcols[$rv['rating']] ?? '#10b981';
              $rFace  = $adminFaceMap[$rv['rating']] ?? '⭐';
              $rFtext = $adminFaceText[$rv['rating']] ?? '';
            ?>
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:12px 14px;border-left:3px solid <?= $rcol ?>;">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
                <span style="font-size:22px;"><?= $rFace ?></span>
                <div>
                  <div style="display:flex;align-items:center;gap:6px;">
                    <span style="color:<?= $rcol ?>;font-size:13px;"><?= $stars ?></span>
                    <span style="font-size:10px;font-weight:700;color:<?= $rcol ?>;text-transform:uppercase;"><?= $rFtext ?></span>
                  </div>
                  <span style="font-size:11px;color:var(--muted);"><?= date('d M Y', strtotime($rv['created_at'])) ?></span>
                </div>
              </div>
              <p style="font-size:13px;color:#cbd5e1;line-height:1.6;"><?= e($rv['description']) ?></p>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <div style="margin-top:20px;">
            <button class="btn btn-ghost btn-full" onclick="closeModal('client-<?= $u['id'] ?>')">Close</button>
          </div>
        </div>
      </div>

      <?php endforeach; ?>
    </div>
  </div>

  <!-- Tab: Messages -->
  <div id="tab-messages" data-tabgroup="admin">
    <!-- Admin Message Search -->
    <div style="margin-bottom:16px;position:relative;">
      <input
        type="text"
        id="admin-msg-search"
        placeholder="🔍  Search by user name, email or message content…"
        oninput="adminFilterMessages(this.value)"
        style="
          width:100%;box-sizing:border-box;
          background:rgba(255,255,255,.05);
          border:1px solid rgba(255,255,255,.12);
          border-radius:12px;
          color:#e2e8f0;font-size:14px;
          padding:10px 16px;outline:none;
          transition:border-color .2s;font-family:inherit;
        "
        onfocus="this.style.borderColor='rgba(245,158,11,.5)'"
        onblur="this.style.borderColor='rgba(255,255,255,.12)'"
      >
      <span id="admin-search-count" style="position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:11px;color:var(--muted);display:none;"></span>
    </div>
    <?php if (!$msgsByUser): ?>
    <div class="card text-center" style="padding:48px;">
      <div style="font-size:40px;margin-bottom:12px;">📭</div>
      <p class="text-muted">No messages from users yet.</p>
    </div>
    <?php else: ?>
    <?php foreach ($msgsByUser as $uid => $thread):
      $firstMsg = $thread[0];
      $unreadInThread = count(array_filter($thread, fn($m) => $m['sender']==='user' && !$m['is_read']));
    ?>
    <div class="card mb-16 admin-thread-card" data-search="<?= htmlspecialchars(strtolower($firstMsg['user_name'].' '.$firstMsg['user_email'].' '.implode(' ', array_column($thread, 'body'))), ENT_QUOTES) ?>" style="padding:0;overflow:hidden;">

      <!-- User Header -->
      <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:12px;background:rgba(255,255,255,.02);">
        <div style="display:flex;align-items:center;gap:12px;">
          <div class="nav-avatar" style="width:38px;height:38px;font-size:13px;flex-shrink:0;"><?= e($firstMsg['user_avatar']) ?></div>
          <div>
            <div style="font-weight:700;font-size:14px;color:#f1f5f9;"><?= e($firstMsg['user_name']) ?></div>
            <div style="font-size:12px;color:var(--muted);"><?= e($firstMsg['user_email']) ?> · <?= count($thread) ?> message<?= count($thread)!==1?'s':'' ?></div>
          </div>
        </div>
        <?php if ($unreadInThread): ?>
        <span class="badge badge-amber" style="font-size:11px;">🔔 <?= $unreadInThread ?> new</span>
        <?php else: ?>
        <span class="badge badge-blue" style="font-size:11px;">User #<?= $uid ?></span>
        <?php endif; ?>
      </div>

      <!-- Chat Thread -->
      <div id="admin-thread-<?= $uid ?>" style="display:flex;flex-direction:column;gap:10px;max-height:360px;overflow-y:auto;padding:16px 20px;">
        <?php foreach ($thread as $msg):
          $isAdmin    = ($msg['sender'] === 'admin');
          $msgAtts    = $msgAttachments[$msg['id']] ?? [];
        ?>
        <div style="display:flex;flex-direction:column;<?= $isAdmin ? 'align-items:flex-end' : 'align-items:flex-start' ?>;">
          <div style="display:flex;align-items:center;gap:5px;margin-bottom:4px;<?= $isAdmin ? 'flex-direction:row-reverse' : '' ?>">
            <div style="width:22px;height:22px;border-radius:50%;background:<?= $isAdmin ? 'linear-gradient(135deg,#f59e0b,#ef4444)' : 'linear-gradient(135deg,#10b981,#14b8a6)' ?>;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;flex-shrink:0;">
              <?= $isAdmin ? '🛡' : e($firstMsg['user_avatar']) ?>
            </div>
            <span style="font-size:11px;color:var(--muted);">
              <?= $isAdmin ? '🛡 Admin (you)' : '👤 '.$firstMsg['user_name'] ?>
              · <?= date('d M, h:i A', strtotime($msg['created_at'])) ?>
            </span>
          </div>
          <div style="display:flex;align-items:flex-start;gap:6px;max-width:82%;<?= $isAdmin ? 'flex-direction:row-reverse' : '' ?>">
            <div style="display:flex;flex-direction:column;gap:5px;max-width:100%;">
              <?php if ($msg['body']): ?>
              <div style="
                padding:10px 15px;
                border-radius:<?= $isAdmin ? '14px 14px 4px 14px' : '14px 14px 14px 4px' ?>;
                <?= $isAdmin
                  ? 'background:rgba(245,158,11,.13);border:1px solid rgba(245,158,11,.28);color:#fef3c7;'
                  : 'background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.22);color:#d1fae5;'
                ?>
                font-size:13px;line-height:1.72;white-space:pre-wrap;word-break:break-word;
              "><?= e($msg['body']) ?></div>
              <?php endif; ?>

              <?php foreach ($msgAtts as $att):
                $aExt    = strtolower(pathinfo($att['filename'], PATHINFO_EXTENSION));
                $aIsImg  = in_array($aExt, ['jpg','jpeg','png','gif','webp','bmp','svg']);
                $aView   = '/devloom/serve_message_file.php?f=' . urlencode($att['filename']);
                $aDl     = $aView . '&dl=1';
                $aName   = $att['original_name'] ?: $att['filename'];
                $aIcon   = adminMsgFileIcon($aExt);
              ?>
              <div style="border-radius:10px;overflow:hidden;border:1px solid <?= $isAdmin ? 'rgba(245,158,11,.3)' : 'rgba(16,185,129,.3)' ?>;background:<?= $isAdmin ? 'rgba(245,158,11,.06)' : 'rgba(16,185,129,.06)' ?>;min-width:180px;max-width:240px;">
                <?php if ($aIsImg): ?>
                <a href="<?= e($aView) ?>" target="_blank">
                  <img src="<?= e($aView) ?>" alt="<?= e($aName) ?>" style="width:100%;max-height:160px;object-fit:cover;display:block;" onerror="this.style.display='none'">
                </a>
                <?php else: ?>
                <div style="padding:10px 12px;display:flex;align-items:center;gap:8px;">
                  <span style="font-size:24px;flex-shrink:0;"><?= $aIcon ?></span>
                  <div style="min-width:0;">
                    <div style="font-size:12px;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="<?= e($aName) ?>"><?= e($aName) ?></div>
                    <?php if ($att['file_size']): ?>
                    <div style="font-size:11px;color:var(--muted);"><?= adminFormatSize((int)$att['file_size']) ?></div>
                    <?php endif; ?>
                  </div>
                </div>
                <?php endif; ?>
                <div style="padding:5px 8px;display:flex;gap:5px;border-top:1px solid rgba(255,255,255,.07);">
                  <a href="<?= e($aView) ?>" target="_blank" style="flex:1;text-align:center;background:rgba(16,185,129,.12);color:#6ee7b7;border:1px solid rgba(16,185,129,.2);border-radius:5px;padding:3px 5px;font-size:11px;font-weight:600;text-decoration:none;">🔍 View</a>
                  <a href="<?= e($aDl) ?>" download="<?= e($aName) ?>" style="flex:1;text-align:center;background:rgba(99,102,241,.12);color:#a5b4fc;border:1px solid rgba(99,102,241,.2);border-radius:5px;padding:3px 5px;font-size:11px;font-weight:600;text-decoration:none;">⬇ Save</a>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <form method="POST" style="margin:0;padding-top:3px;" onsubmit="return confirm('Delete?');"><?= csrf_field() ?>
              <input type="hidden" name="action"  value="delete_user_message">
              <input type="hidden" name="msg_id"  value="<?= $msg['id'] ?>">
              <button type="submit" title="Delete" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.15);color:#f87171;width:20px;height:20px;border-radius:50%;cursor:pointer;font-size:10px;display:flex;align-items:center;justify-content:center;padding:0;flex-shrink:0;">✕</button>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Inline Reply Bar -->
      <div style="padding:10px 14px;border-top:1px solid var(--border);background:rgba(0,0,0,.12);">
        <!-- File preview strip -->
        <div id="admin-preview-<?= $uid ?>" style="display:none;flex-wrap:wrap;gap:5px;padding:4px 0 8px;"></div>

        <form method="POST" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:flex-end;"><?= csrf_field() ?>
          <input type="hidden" name="action"  value="reply_message">
          <input type="hidden" name="user_id" value="<?= $uid ?>">
          <input type="file" name="attachments[]" id="admin-file-<?= $uid ?>" multiple style="display:none;"
                 onchange="adminPreviewFiles(this, <?= $uid ?>)">

          <!-- Attach button -->
          <button type="button"
                  onclick="document.getElementById('admin-file-<?= $uid ?>').click()"
                  title="Attach files (any format)"
                  style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:9px;color:#94a3b8;width:38px;height:38px;cursor:pointer;font-size:17px;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;"
                  onmouseover="this.style.background='rgba(245,158,11,.18)';this.style.color='#fbbf24'"
                  onmouseout="this.style.background='rgba(255,255,255,.07)';this.style.color='#94a3b8'">📎</button>

          <textarea
            name="body"
            rows="1"
            placeholder="Reply to <?= e($firstMsg['user_name']) ?>…"
            style="
              flex:1;
              background:rgba(255,255,255,.06);
              border:1px solid rgba(255,255,255,.1);
              border-radius:10px;
              color:#e2e8f0;
              font-size:13px;
              padding:9px 13px;
              resize:none;
              min-height:38px;
              max-height:100px;
              font-family:inherit;
              line-height:1.5;
              outline:none;
              transition:border-color .2s;
            "
            onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();this.form.submit();}"
            oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px';"
            onfocus="this.style.borderColor='rgba(245,158,11,.5)'"
            onblur="this.style.borderColor='rgba(255,255,255,.1)'"
          ></textarea>
          <button type="submit" title="Send reply (Enter)" style="
            background:linear-gradient(135deg,#f59e0b,#ef4444);
            border:none;border-radius:10px;color:#fff;
            width:38px;height:38px;
            cursor:pointer;font-size:18px;
            display:flex;align-items:center;justify-content:center;
            flex-shrink:0;
          ">➤</button>
        </form>
        <p style="font-size:11px;color:var(--muted);margin-top:4px;padding-left:2px;">Enter to send · Shift+Enter for new line · 📎 attach any file (PDF, ZIP, image, doc…)</p>
      </div>

    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Tab: Payment QR Manager -->
  <div id="tab-payment-qr" data-tabgroup="admin">
    <div style="margin-bottom:20px;">
      <h3 style="font-size:16px;font-weight:700;color:#e2e8f0;margin-bottom:6px;">💳 Payment QR Code Manager</h3>
      <p style="font-size:13px;color:var(--muted);">Upload a one-time QR code per project. The client sees it once on their dashboard to scan and pay. After they view it, it's marked as used.</p>
    </div>
    <div style="display:flex;flex-direction:column;gap:14px;">
      <?php foreach ($projects as $p):
        if (!$p['payment']) continue; // only show projects with a quote
        $qr = $qrCodes[$p['id']] ?? null;
      ?>
      <div class="card" style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:16px 20px;">
        <!-- Project info -->
        <div style="display:flex;align-items:center;gap:10px;flex:1;min-width:200px;">
          <div class="nav-avatar" style="width:36px;height:36px;font-size:12px;flex-shrink:0;"><?= e($p['user_avatar']) ?></div>
          <div>
            <div style="font-size:14px;font-weight:700;color:#e2e8f0;"><?= e($p['title']) ?></div>
            <div style="font-size:12px;color:var(--muted);"><?= e($p['user_name']) ?> · ₹<?= number_format($p['payment'],0) ?></div>
          </div>
        </div>

        <!-- QR Status -->
        <div style="flex:1;min-width:180px;">
          <?php if ($p['paid']): ?>
            <span class="badge badge-green">✅ Already Paid</span>
          <?php elseif ($qr): ?>
            <div style="display:flex;align-items:center;gap:10px;">
              <img src="/devloom/uploads/qr/<?= e($qr['filename']) ?>" alt="QR" style="width:50px;height:50px;object-fit:contain;background:#fff;border-radius:6px;padding:3px;">
              <div>
                <div style="font-size:12px;color:<?= $qr['used'] ? '#f87171' : '#10b981' ?>;font-weight:700;"><?= $qr['used'] ? '⚠ QR Used' : '🟢 QR Active' ?></div>
                <div style="font-size:11px;color:var(--muted);">Uploaded <?= date('d M Y', strtotime($qr['uploaded_at'])) ?></div>
              </div>
            </div>
          <?php else: ?>
            <span class="badge badge-red">❌ No QR Uploaded</span>
          <?php endif; ?>
        </div>

        <!-- Action: Quick upload button -->
        <?php if (!$p['paid']): ?>
        <button class="btn btn-amber btn-sm" onclick="openModal('qr-quick-<?= $p['id'] ?>')">
          <?= $qr ? '🔄 Replace QR' : '📤 Upload QR' ?>
        </button>
        <?php endif; ?>
      </div>

      <!-- Quick QR upload modal -->
      <div class="modal-overlay" id="qr-quick-<?= $p['id'] ?>">
        <div class="modal-box" style="max-width:480px;">
          <div class="modal-header">
            <span class="modal-title">💳 Upload QR — <?= e($p['title']) ?></span>
            <button class="modal-close" onclick="closeModal('qr-quick-<?= $p['id'] ?>')">✕</button>
          </div>
          <?php if ($qr): ?>
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.18);border-radius:10px;padding:12px;">
            <img src="/devloom/uploads/qr/<?= e($qr['filename']) ?>" alt="QR" style="width:70px;height:70px;object-fit:contain;background:#fff;border-radius:6px;padding:4px;">
            <div>
              <div style="font-size:13px;color:#10b981;font-weight:700;">Current QR <?= $qr['used'] ? '(Used)' : '(Active)' ?></div>
              <?php if ($qr['amount']): ?><div style="font-size:12px;color:#94a3b8;">₹<?= number_format($qr['amount'],0) ?></div><?php endif; ?>
            </div>
          </div>
          <?php endif; ?>
          <form method="POST" enctype="multipart/form-data"><?= csrf_field() ?>
            <input type="hidden" name="action" value="upload_payment_qr">
            <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
            <div class="form-group">
              <label class="form-label">QR Code Image *</label>
              <input type="file" name="qr_image" accept="image/*" class="form-control" style="padding:8px;" required>
              <p style="font-size:11px;color:var(--muted);margin-top:4px;">PNG recommended. Client will see this to scan and pay.</p>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Amount (₹)</label>
                <input type="number" name="qr_amount" class="form-control" value="<?= $p['payment'] ?>" placeholder="Amount">
              </div>
              <div class="form-group">
                <label class="form-label">Note for client</label>
                <input type="text" name="qr_note" class="form-control" placeholder="Pay via GPay / PhonePe">
              </div>
            </div>
            <div class="flex gap-8">
              <button type="submit" class="btn btn-primary" style="flex:1;">📤 Upload QR Code</button>
              <button type="button" class="btn btn-ghost" onclick="closeModal('qr-quick-<?= $p['id'] ?>')">Cancel</button>
            </div>
          </form>
          <?php if ($qr): ?>
          <form method="POST" style="margin-top:12px;" onsubmit="return confirm('Revoke and delete this QR?');"><?= csrf_field() ?>
            <input type="hidden" name="action" value="revoke_payment_qr">
            <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-sm" style="width:100%;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.2);color:#f87171;">🗑 Revoke QR</button>
          </form>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Tab: Contact Enquiries -->
  <div id="tab-contacts" data-tabgroup="admin">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:10px;">
      <div>
        <h3 style="font-size:16px;font-weight:700;color:#e2e8f0;margin-bottom:4px;">📬 Contact Form Enquiries</h3>
        <p style="font-size:13px;color:var(--muted);">Messages submitted via the public contact form.</p>
      </div>
      <?php
        $unreadContacts = count(array_filter($contacts, fn($c) => !$c['is_read']));
        if ($unreadContacts):
          // Mark all as read when admin views tab
          $pdo->query("UPDATE contacts SET is_read=1 WHERE is_read=0");
      ?>
      <span style="font-size:12px;font-weight:700;color:#fbbf24;"><?= $unreadContacts ?> new</span>
      <?php endif; ?>
    </div>
    <?php if (!$contacts): ?>
    <div class="card text-center" style="padding:48px;">
      <div style="font-size:40px;margin-bottom:12px;">📭</div>
      <p class="text-muted">No contact form submissions yet.</p>
    </div>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;gap:12px;">
      <?php foreach ($contacts as $c): ?>
      <div class="card" style="padding:18px 22px;border-left:3px solid <?= $c['is_read'] ? 'rgba(255,255,255,.08)' : '#f59e0b' ?>;">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#10b981);display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:800;color:#fff;flex-shrink:0;"><?= strtoupper(substr($c['name'],0,1)) ?></div>
            <div>
              <div style="font-weight:700;font-size:14px;color:#f1f5f9;"><?= e($c['name']) ?><?php if (!$c['is_read']): ?> <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#f59e0b;margin-left:6px;"></span><?php endif; ?></div>
              <div style="font-size:12px;color:#64748b;margin-top:1px;"><a href="mailto:<?= e($c['email']) ?>" style="color:#10b981;text-decoration:none;"><?= e($c['email']) ?></a></div>
            </div>
          </div>
          <div style="font-size:11px;color:#475569;white-space:nowrap;"><?= date('d M Y, h:i A', strtotime($c['created_at'])) ?></div>
        </div>
        <?php if ($c['subject']): ?>
        <div style="font-size:12px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px;"><?= e($c['subject']) ?></div>
        <?php endif; ?>
        <div style="font-size:14px;color:#cbd5e1;line-height:1.7;background:rgba(0,0,0,.2);border-radius:8px;padding:12px 14px;"><?= nl2br(e($c['message'])) ?></div>
        <div style="margin-top:12px;">
          <a href="mailto:<?= e($c['email']) ?>?subject=Re: <?= urlencode($c['subject'] ?: 'Your enquiry') ?>&body=Hi <?= urlencode($c['name']) ?>,%0A%0A"
             class="btn btn-outline btn-sm" style="font-size:12px;">✉️ Reply via Email</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

</div><!-- /container -->

<script>
// Auto-scroll all admin chat threads to bottom
document.querySelectorAll('[id^="admin-thread-"]').forEach(function(el) {
  el.scrollTop = el.scrollHeight;
});

// Auto-open messages tab if URL hash says so
if (window.location.hash === '#tab-messages') {
  document.querySelectorAll('.admin-tab').forEach(function(b,i) {
    b.classList.toggle('active', i===2);
  });
  document.querySelectorAll('[data-tabgroup="admin"]').forEach(function(el,i) {
    el.classList.toggle('active', i===2);
  });
}

// ── Global Admin Search ──────────────────────────────────────
function adminGlobalSearch(query) {
  const q = query.trim().toLowerCase();
  const countEl = document.getElementById('admin-global-count');

  if (!q) {
    // Reset all
    document.querySelectorAll('.admin-project-card').forEach(el => el.style.display = '');
    document.querySelectorAll('.admin-thread-card').forEach(el => el.style.display = '');
    countEl.style.display = 'none';
    return;
  }

  let total = 0;

  // Search projects
  const projCards = document.querySelectorAll('.admin-project-card');
  let projFound = 0;
  projCards.forEach(card => {
    const hay = (card.getAttribute('data-search') || '').toLowerCase();
    const show = hay.includes(q);
    card.style.display = show ? '' : 'none';
    if (show) { projFound++; total++; }
  });

  // Search message threads
  const threadCards = document.querySelectorAll('.admin-thread-card');
  let msgFound = 0;
  threadCards.forEach(card => {
    const hay = (card.getAttribute('data-search') || '').toLowerCase();
    const show = hay.includes(q);
    card.style.display = show ? '' : 'none';
    if (show) { msgFound++; total++; }
  });

  countEl.textContent = total + ' result' + (total !== 1 ? 's' : '') +
    ' (' + projFound + ' project' + (projFound !== 1 ? 's' : '') + ', ' +
    msgFound + ' thread' + (msgFound !== 1 ? 's' : '') + ')';
  countEl.style.display = 'inline';

  // If there are only project results, switch to projects tab
  if (projFound > 0 && msgFound === 0) {
    document.querySelectorAll('.admin-tab').forEach((b,i) => b.classList.toggle('active', i===0));
    document.querySelectorAll('[data-tabgroup="admin"]').forEach((el,i) => el.classList.toggle('active', i===0));
  } else if (msgFound > 0 && projFound === 0) {
    document.querySelectorAll('.admin-tab').forEach((b,i) => b.classList.toggle('active', i===2));
    document.querySelectorAll('[data-tabgroup="admin"]').forEach((el,i) => el.classList.toggle('active', i===2));
  }
}

// Admin message search — filters user thread cards (legacy, kept for messages tab input)
function adminFilterMessages(query) {
  adminGlobalSearch(query);
}

// Admin reply file preview chips
function adminPreviewFiles(input, uid) {
  const strip = document.getElementById('admin-preview-' + uid);
  strip.innerHTML = '';
  if (!input.files.length) { strip.style.display = 'none'; return; }
  strip.style.display = 'flex';
  Array.from(input.files).forEach(function(f) {
    const chip = document.createElement('div');
    chip.style.cssText = 'background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.28);border-radius:20px;padding:3px 10px;font-size:11px;color:#fbbf24;display:flex;align-items:center;gap:4px;max-width:160px;';
    chip.innerHTML = '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + f.name + '</span>';
    strip.appendChild(chip);
  });
}
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
