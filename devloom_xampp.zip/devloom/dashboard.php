<?php
require_once __DIR__ . '/config/db.php';
requireUser();

$userId = currentUserId();

$stmtU = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmtU->execute([$userId]);
$user = $stmtU->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'submit_project') {
        $title = trim($_POST['title'] ?? '');
        $desc  = trim($_POST['description'] ?? '');
        $tech  = trim($_POST['tech_stack'] ?? '');
        if ($title && $desc) {
            $pdo->prepare("INSERT INTO projects (user_id,title,description,tech_stack) VALUES (?,?,?,?)")
                ->execute([$userId, $title, $desc, $tech]);
            flash('success', 'Project submitted! Admin will review and set a quote soon.');
        } else {
            flash('error', 'Title and description are required.');
        }
        header('Location: /devloom/dashboard.php'); exit;
    }

    if ($action === 'edit_project') {
        $pid   = (int)($_POST['project_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $desc  = trim($_POST['description'] ?? '');
        $tech  = trim($_POST['tech_stack'] ?? '');
        $chk   = $pdo->prepare("SELECT id FROM projects WHERE id=? AND user_id=? AND status='pending'");
        $chk->execute([$pid, $userId]);
        if ($chk->fetch() && $title && $desc) {
            $pdo->prepare("UPDATE projects SET title=?,description=?,tech_stack=? WHERE id=? AND user_id=?")
                ->execute([$title, $desc, $tech, $pid, $userId]);
            flash('success', 'Project details updated.');
        } else {
            flash('error', 'Cannot edit — project is no longer pending.');
        }
        header('Location: /devloom/dashboard.php'); exit;
    }

    if ($action === 'delete_project') {
        $pid = (int)($_POST['project_id'] ?? 0);
        $chk = $pdo->prepare("SELECT id FROM projects WHERE id=? AND user_id=? AND status='pending'");
        $chk->execute([$pid, $userId]);
        if ($chk->fetch()) {
            $pdo->prepare("DELETE FROM projects WHERE id=? AND user_id=?")->execute([$pid, $userId]);
            flash('success', 'Project deleted.');
        } else {
            flash('error', 'Cannot delete — project is no longer pending.');
        }
        header('Location: /devloom/dashboard.php'); exit;
    }

    if ($action === 'submit_review') {
        $pid     = (int)($_POST['project_id'] ?? 0);
        $rating  = max(1, min(5, (int)($_POST['rating'] ?? 5)));
        $comment = trim($_POST['comment'] ?? '');
        $attachPhoto = !empty($_POST['attach_profile_photo']);
        $profilePhotoPath = trim($_POST['profile_photo_path'] ?? '');
        $reviewPhoto = ($attachPhoto && $profilePhotoPath) ? $profilePhotoPath : '';

        // Verify project belongs to user and is completed
        $chk = $pdo->prepare("SELECT id FROM projects WHERE id=? AND user_id=? AND status='completed'");
        $chk->execute([$pid, $userId]);
        if ($chk->fetch() && $comment) {
            // Check if review already exists for this project
            $existing = $pdo->prepare("SELECT id FROM reviews WHERE user_id=? AND project_id=?");
            $existing->execute([$userId, $pid]);
            if ($existing->fetch()) {
                try {
                    $pdo->prepare("UPDATE reviews SET rating=?, description=?, review_photo=? WHERE user_id=? AND project_id=?")
                        ->execute([$rating, $comment, $reviewPhoto, $userId, $pid]);
                } catch (PDOException $e) {
                    // review_photo column may not exist yet — run migration
                    $pdo->prepare("UPDATE reviews SET rating=?, description=? WHERE user_id=? AND project_id=?")
                        ->execute([$rating, $comment, $userId, $pid]);
                }
                flash('success', 'Review updated! Thank you for your feedback.');
            } else {
                try {
                    $pdo->prepare("INSERT INTO reviews (user_id, project_id, rating, description, review_photo) VALUES (?,?,?,?,?)")
                        ->execute([$userId, $pid, $rating, $comment, $reviewPhoto]);
                } catch (PDOException $e) {
                    $pdo->prepare("INSERT INTO reviews (user_id, project_id, rating, description) VALUES (?,?,?,?)")
                        ->execute([$userId, $pid, $rating, $comment]);
                }
                flash('success', 'Review submitted! Thank you for your feedback. ⭐');
            }
        } else {
            flash('error', 'Please write a comment and ensure the project is completed.');
        }
        header('Location: /devloom/dashboard.php'); exit;
    }

    if ($action === 'request_note') {
        $pid = (int)($_POST['project_id'] ?? 0);
        $pdo->prepare("UPDATE projects SET requested_note=1 WHERE id=? AND user_id=?")->execute([$pid, $userId]);
        flash('success', 'AI note requested! Admin will generate it soon.');
        header('Location: /devloom/dashboard.php'); exit;
    }

    if ($action === 'mark_qr_viewed') {
        $pid = (int)($_POST['project_id'] ?? 0);
        try {
            $pdo->prepare("UPDATE payment_qr SET used=1 WHERE project_id=? AND used=0")->execute([$pid]);
        } catch (PDOException $e) { /* table not yet created */ }
        flash('success', 'Payment noted! Admin will mark your project as paid once confirmed.');
        header('Location: /devloom/dashboard.php'); exit;
    }

    if ($action === 'request_qr') {
        $pid = (int)($_POST['project_id'] ?? 0);
        $pdo->prepare("UPDATE projects SET qr_requested=1 WHERE id=? AND user_id=?")->execute([$pid, $userId]);
        flash('success', 'QR code requested! Admin will upload it shortly.');
        header('Location: /devloom/payment.php?project_id=' . $pid); exit;
    }
}

$stmtP = $pdo->prepare("SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC");
$stmtP->execute([$userId]);
$projects = $stmtP->fetchAll();

$screenshots = [];
if ($projects) {
    $ids   = array_column($projects, 'id');
    $ph    = implode(',', array_fill(0, count($ids), '?'));
    $stmtS = $pdo->prepare("SELECT * FROM screenshots WHERE project_id IN ($ph)");
    $stmtS->execute($ids);
    foreach ($stmtS->fetchAll() as $ss) {
        $screenshots[$ss['project_id']][] = $ss;
    }
}

// Fetch QR codes for this user's projects
$myQrCodes = [];
try {
    if ($projects) {
        $ids = array_column($projects, 'id');
        $ph  = implode(',', array_fill(0, count($ids), '?'));
        $qrS = $pdo->prepare("SELECT * FROM payment_qr WHERE project_id IN ($ph)");
        $qrS->execute($ids);
        foreach ($qrS->fetchAll() as $qr) { $myQrCodes[$qr['project_id']] = $qr; }
    }
} catch (PDOException $e) {
    // payment_qr table not yet created — run migrate.sql to add it
}

$total     = count($projects);
$completed = count(array_filter($projects, fn($p) => $p['status'] === 'completed'));
$inprog    = count(array_filter($projects, fn($p) => $p['status'] === 'in-progress'));
$pendingC  = count(array_filter($projects, fn($p) => $p['status'] === 'pending'));

$unreadStmt = $pdo->prepare("SELECT COUNT(*) FROM user_messages WHERE user_id=? AND sender='admin' AND is_read=0");
$unreadStmt->execute([$userId]);
$unreadCount = $unreadStmt->fetchColumn();

// Fetch reviews for this user
$stmtR = $pdo->prepare("SELECT r.*, p.title as project_title FROM reviews r LEFT JOIN projects p ON p.id = r.project_id WHERE r.user_id = ? ORDER BY r.created_at DESC");
$stmtR->execute([$userId]);
$myReviews = $stmtR->fetchAll();

// Index reviews by project_id for quick lookup
$reviewedProjectIds = [];
$existingReviewPhoto = [];
foreach ($myReviews as $rv) {
    if ($rv['project_id']) {
        $reviewedProjectIds[$rv['project_id']] = $rv['rating'];
        $existingReviewPhoto[$rv['project_id']] = $rv['review_photo'] ?? '';
    }
}

$flashErr = flash('error');
$flashOk  = flash('success');
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
include __DIR__ . '/includes/header.php';
?>

<style>
/* ── Professional Dashboard Styles ── */

/* Main content */
.db-main{padding:32px 36px 72px;min-width:0;max-width:1100px;margin:0 auto;}
@media(max-width:700px){.db-main{padding:20px 16px 60px;}}

/* Top bar */
.db-topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:32px;flex-wrap:wrap;gap:16px;}
.db-user-info{display:flex;align-items:center;gap:14px;}
.db-avatar{width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#10b981,#0d9488);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:#fff;flex-shrink:0;}
.db-name{font-size:1.25rem;font-weight:800;color:#f1f5f9;margin:0;}
.db-meta{font-size:12px;color:#475569;margin:2px 0 0;font-family:monospace;}

/* KPI row */
.kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:32px;}
@media(max-width:800px){.kpi-row{grid-template-columns:repeat(2,1fr);}}
@media(max-width:400px){.kpi-row{grid-template-columns:1fr 1fr;}}
.kpi{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:20px 18px;position:relative;overflow:hidden;}
.kpi::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;background:var(--kc);}
.kpi-val{font-size:2rem;font-weight:900;color:var(--kc);line-height:1;margin-bottom:4px;font-family:var(--font-head);}
.kpi-label{font-size:11px;color:#475569;font-weight:700;text-transform:uppercase;letter-spacing:.08em;}
.kpi-icon{position:absolute;top:16px;right:16px;font-size:1.4rem;opacity:.15;}

/* Section header */
.sec-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px;}
.sec-title{font-size:13px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.1em;font-family:monospace;display:flex;align-items:center;gap:7px;}
.sec-title::before{content:'';display:block;width:3px;height:14px;background:#10b981;border-radius:2px;}

/* Projects table */
.proj-table{width:100%;border-collapse:collapse;}
.proj-table th{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#334155;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.06);text-align:left;white-space:nowrap;}
.proj-table td{padding:14px 14px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle;font-size:13px;color:#94a3b8;}
.proj-table tr:last-child td{border-bottom:none;}
.proj-table tr:hover td{background:rgba(255,255,255,.02);}
.proj-title-cell{color:#e2e8f0;font-weight:600;max-width:200px;}
.proj-title-cell small{display:block;color:#475569;font-size:11px;font-weight:400;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:190px;}
.proj-actions{display:flex;gap:6px;flex-wrap:wrap;}

/* Empty state */
.empty-state{text-align:center;padding:56px 24px;background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.08);border-radius:16px;}
.empty-state .es-ico{font-size:3rem;margin-bottom:14px;}

/* Inbox banner */
.inbox-banner{background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.18);border-radius:12px;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:24px;flex-wrap:wrap;}
.inbox-dot{width:8px;height:8px;border-radius:50%;background:#10b981;flex-shrink:0;box-shadow:0 0 0 3px rgba(16,185,129,.2);}

/* Panel card */
.db-panel{background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);border-radius:16px;overflow:hidden;margin-bottom:28px;}
.db-panel-head{padding:14px 20px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;justify-content:space-between;gap:10px;}
.db-panel-body{padding:20px;}
</style>

<div class="db-grid-bg"></div>
<div class="container" style="padding-top:40px;padding-bottom:60px;">
<div class="db-main">

<!-- ══ MAIN ══ -->

  <?php if ($flashErr): ?><div class="alert alert-error animate-up" style="margin-bottom:20px;"><?= e($flashErr) ?></div><?php endif; ?>
  <?php if ($flashOk):  ?><div class="alert alert-success animate-up" style="margin-bottom:20px;"><?= e($flashOk) ?></div><?php endif; ?>

  <!-- Top bar -->
  <div class="db-topbar animate-up">
    <div class="db-user-info">
      <div class="db-avatar"><?= e($user['avatar']) ?></div>
      <div>
        <p class="db-name"><?php
          $hour = (int)date('H');
          if ($hour < 12)                     echo 'Good Morning ☀️';
          elseif ($hour < 17)                 echo 'Good Afternoon 🌅';
          elseif ($hour < 21)                 echo 'Good Evening 🌙';
          else                                 echo 'Good Night 🌛';
        ?>, <?= e(explode(' ',$user['name'])[0]) ?></p>
        <p class="db-meta"><?= date('l, d M Y') ?></p>
      </div>
    </div>
    <button class="btn btn-primary" onclick="openModal('modal-submit')" style="padding:10px 22px;font-size:13px;">
      + New Project
    </button>
  </div>

  <!-- KPI row -->
  <div class="kpi-row">
    <div class="kpi reveal delay-1" style="--kc:#10b981">
      <div class="kpi-val"><?= $total ?></div>
      <div class="kpi-label">Total Projects</div>
      <span class="kpi-icon">📁</span>
    </div>
    <div class="kpi reveal delay-2" style="--kc:#34d399">
      <div class="kpi-val"><?= $completed ?></div>
      <div class="kpi-label">Completed</div>
      <span class="kpi-icon">✅</span>
    </div>
    <div class="kpi reveal delay-3" style="--kc:#60a5fa">
      <div class="kpi-val"><?= $inprog ?></div>
      <div class="kpi-label">In Progress</div>
      <span class="kpi-icon">⚙️</span>
    </div>
    <div class="kpi reveal delay-4" style="--kc:#f59e0b">
      <div class="kpi-val"><?= $pendingC ?></div>
      <div class="kpi-label">Pending</div>
      <span class="kpi-icon">⏳</span>
    </div>
  </div>

  <!-- Unread message banner -->
  <?php if($unreadCount>0): ?>
  <div class="inbox-banner">
    <div style="display:flex;align-items:center;gap:10px;">
      <div class="inbox-dot"></div>
      <span style="font-size:13px;color:#cbd5e1;">You have <strong style="color:#10b981;"><?= $unreadCount ?> unread message<?= $unreadCount>1?'s':'' ?></strong> from the team.</span>
    </div>
    <a href="/devloom/messages.php" class="btn btn-primary btn-sm">Open Messages →</a>
  </div>
  <?php endif; ?>

  <!-- Projects panel -->
  <div id="projects" class="db-panel reveal">
    <div class="db-panel-head">
      <div class="sec-title">My Projects</div>
      <div style="display:flex;gap:8px;align-items:center;">
        <span style="font-size:12px;color:#334155;"><?= $total ?> total</span>
        <button class="btn btn-primary btn-sm" onclick="openModal('modal-submit')">+ Submit</button>
      </div>
    </div>

    <?php if (!$projects): ?>
    <div class="db-panel-body">
      <div class="empty-state">
        <div class="es-ico">📂</div>
        <h3 style="color:#e2e8f0;margin-bottom:8px;font-size:1rem;">No Projects Yet</h3>
        <p class="text-muted" style="font-size:13px;margin-bottom:18px;">Submit your first project and the team will review it shortly.</p>
        <button class="btn btn-primary" onclick="openModal('modal-submit')">+ Submit a Project</button>
      </div>
    </div>
    <?php else: ?>
    <div style="overflow-x:auto;">
      <table class="proj-table">
        <thead>
          <tr>
            <th>Project</th>
            <th>Status</th>
            <th>Payment</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($projects as $p):
          $shots     = $screenshots[$p['id']] ?? [];
          $isPending = ($p['status'] === 'pending');
        ?>
        <tr>
          <td>
            <div class="proj-title-cell">
              <?= e($p['title']) ?>
              <small><?= e($p['description']) ?></small>
            </div>
          </td>
          <td>
            <span class="badge <?= statusClass($p['status']) ?>"><?= statusLabel($p['status']) ?></span>
          </td>
          <td>
            <?php if ($p['paid']): ?>
              <span class="badge badge-green" style="font-size:11px;">✓ Paid</span>
            <?php elseif ($p['payment']): ?>
              <span style="color:#f59e0b;font-size:13px;font-weight:600;">₹<?= number_format($p['payment'],0) ?></span>
            <?php else: ?>
              <span style="color:#334155;font-size:12px;">—</span>
            <?php endif; ?>
          </td>
          <td style="white-space:nowrap;"><?= date('d M Y', strtotime($p['created_at'])) ?></td>
          <td>
            <div class="proj-actions">
              <?php if ($shots): ?>
              <button class="btn btn-ghost btn-sm" onclick="openModal('shots-<?= $p['id'] ?>')">📎 Files</button>
              <?php endif; ?>

              <?php if ($p['status']==='completed' && !$p['requested_note'] && !$p['note_ready']): ?>
              <form method="POST" style="margin:0;">
                <input type="hidden" name="action" value="request_note">
                <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
                <button class="btn btn-outline btn-sm">🤖 AI Note</button>
              </form>
              <?php elseif ($p['note_ready']): ?>
              <button class="btn btn-primary btn-sm" onclick="openModal('note-<?= $p['id'] ?>')">📖 Note</button>
              <?php elseif ($p['requested_note']): ?>
              <span class="badge badge-amber" style="font-size:11px;">Requested</span>
              <?php endif; ?>

              <?php if (!$p['paid'] && $p['payment']): ?>
              <a href="/devloom/payment.php?project_id=<?= $p['id'] ?>" class="btn btn-sm" style="background:rgba(16,185,129,.12);color:#10b981;border:1px solid rgba(16,185,129,.25);font-size:12px;text-decoration:none;">💳 Pay</a>
              <?php endif; ?>

              <?php if ($isPending): ?>
              <button class="btn btn-ghost btn-sm" onclick="openModal('edit-proj-<?= $p['id'] ?>')">Edit</button>
              <form method="POST" style="margin:0;" onsubmit="return confirm('Delete this project?');">
                <input type="hidden" name="action" value="delete_project">
                <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
                <button class="btn btn-sm" style="background:rgba(239,68,68,.08);color:#f87171;border:1px solid rgba(239,68,68,.2);font-size:12px;">Del</button>
              </form>
              <?php endif; ?>

              <?php if ($p['status']==='completed'): ?>
              <button class="btn btn-sm" onclick="openModal('review-<?= $p['id'] ?>')"
                style="background:rgba(234,179,8,.08);color:#fbbf24;border:1px solid rgba(234,179,8,.25);font-size:12px;">
                <?= isset($reviewedProjectIds[$p['id']]) ? '✏️ Edit Review' : '⭐ Rate' ?>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>

        <!-- Modals (screenshots, notes, edit) live outside table for DOM validity -->
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($myReviews): ?>
  <!-- Reviews -->
  <div class="sec-hdr" style="margin-top:8px;"><span class="sec-title">My Reviews</span></div>
  <div class="grid-2">
    <?php
    $faceMap = [1=>'😞',2=>'😐',3=>'🙂',4=>'😊',5=>'🤩'];
    $faceText= [1=>'Terrible',2=>'Below Avg',3=>'Okay',4=>'Good',5=>'Excellent'];
    foreach ($myReviews as $rv):
      $stars = str_repeat('★', $rv['rating']) . str_repeat('☆', 5 - $rv['rating']);
      $colors = ['','#ef4444','#f97316','#eab308','#22c55e','#10b981'];
      $col    = $colors[$rv['rating']] ?? '#10b981';
      $face   = $faceMap[$rv['rating']] ?? '⭐';
      $ftext  = $faceText[$rv['rating']] ?? '';
    ?>
    <div class="card" style="border-left:3px solid <?= $col ?>;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
        <span style="font-size:32px;line-height:1;"><?= $face ?></span>
        <div>
          <div style="display:flex;align-items:center;gap:6px;">
            <span style="font-size:14px;color:<?= $col ?>;letter-spacing:1px;"><?= $stars ?></span>
            <span style="font-size:11px;font-weight:700;color:<?= $col ?>;text-transform:uppercase;letter-spacing:.06em;"><?= $ftext ?></span>
          </div>
          <span style="font-size:11px;color:var(--muted);"><?= date('d M Y', strtotime($rv['created_at'])) ?></span>
        </div>
      </div>
      <?php if ($rv['project_title']): ?>
      <span class="badge badge-blue" style="margin-bottom:8px;"><?= e($rv['project_title']) ?></span>
      <?php endif; ?>
      <p style="font-size:13px;color:#cbd5e1;line-height:1.7;"><?= e($rv['description']) ?></p>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div>
</div>

<!-- ══ MODALS ══ -->
<?php foreach ($projects as $p):
  $shots     = $screenshots[$p['id']] ?? [];
  $isPending = ($p['status'] === 'pending');
?>

<?php if ($shots): ?>
<div class="modal-overlay" id="shots-<?= $p['id'] ?>">
  <div class="modal-box" style="max-width:700px;">
    <div class="modal-header">
      <span class="modal-title">📎 Files — <?= e($p['title']) ?></span>
      <button class="modal-close" onclick="closeModal('shots-<?= $p['id'] ?>')">✕</button>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;">
      <?php foreach ($shots as $ss):
        $fileUrl  = filePublicUrl($ss['filename']);
        $isImg    = isImageFile($ss['filename']);
        $icon     = fileIcon($ss['filename']);
        $dispName = fileDisplayName($ss);
      ?>
      <div style="border-radius:10px;overflow:hidden;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);">
        <?php if ($isImg): ?>
        <div style="aspect-ratio:16/9;overflow:hidden;background:rgba(0,0,0,.2);">
          <img src="<?= e($fileUrl) ?>" alt="<?= e($dispName) ?>" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'">
        </div>
        <?php else: ?>
        <div style="aspect-ratio:16/9;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:rgba(255,255,255,.04);">
          <span style="font-size:36px;"><?= $icon ?></span>
          <span style="font-size:10px;color:var(--muted);font-family:monospace;"><?= strtoupper(pathinfo($ss['filename'],PATHINFO_EXTENSION)) ?></span>
        </div>
        <?php endif; ?>
        <div style="padding:8px 10px;">
          <p style="font-size:11px;color:#cbd5e1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:6px;"><?= e($dispName) ?></p>
          <div style="display:flex;gap:6px;">
            <a href="<?= e($fileUrl) ?>" target="_blank" style="flex:1;text-align:center;background:rgba(16,185,129,.1);color:#6ee7b7;border:1px solid rgba(16,185,129,.2);border-radius:6px;padding:4px 8px;font-size:11px;text-decoration:none;font-weight:600;">View</a>
            <a href="<?= e($fileUrl) ?>&dl=1" download="<?= e($dispName) ?>" style="flex:1;text-align:center;background:rgba(99,102,241,.1);color:#a5b4fc;border:1px solid rgba(99,102,241,.2);border-radius:6px;padding:4px 8px;font-size:11px;text-decoration:none;font-weight:600;">Save</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($p['note_ready'] && $p['code_note']): ?>
<div class="modal-overlay" id="note-<?= $p['id'] ?>">
  <div class="modal-box">
    <div class="modal-header">
      <span class="modal-title">🤖 AI Code Walkthrough</span>
      <button class="modal-close" onclick="closeModal('note-<?= $p['id'] ?>')">✕</button>
    </div>
    <div class="code-note"><?= e($p['code_note']) ?></div>
    <p class="text-muted mt-12" style="font-size:12px;">Generated by Claude AI · <a href="/devloom/messages.php">Message admin</a> for clarifications.</p>
  </div>
</div>
<?php endif; ?>

<?php if ($isPending): ?>
<div class="modal-overlay" id="edit-proj-<?= $p['id'] ?>">
  <div class="modal-box">
    <div class="modal-header">
      <span class="modal-title">✏ Edit Project</span>
      <button class="modal-close" onclick="closeModal('edit-proj-<?= $p['id'] ?>')">✕</button>
    </div>
    <div class="alert alert-info">ℹ You can edit details only while status is Pending.</div>
    <form method="POST">
      <input type="hidden" name="action" value="edit_project">
      <input type="hidden" name="project_id" value="<?= $p['id'] ?>">
      <div class="form-group">
        <label class="form-label">Project Title *</label>
        <input type="text" name="title" class="form-control" value="<?= e($p['title']) ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description *</label>
        <textarea name="description" class="form-control" rows="4" required><?= e($p['description']) ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Tech Stack</label>
        <input type="text" name="tech_stack" class="form-control" value="<?= e($p['tech_stack']) ?>">
      </div>
      <div class="flex gap-8">
        <button type="submit" class="btn btn-primary" style="flex:1;">Save Changes</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('edit-proj-<?= $p['id'] ?>')">Cancel</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php if ($p['status']==='completed'): ?>
<?php
  $pid_r = $p['id'];
  $existingRating = isset($reviewedProjectIds[$pid_r]) ? (int)$reviewedProjectIds[$pid_r] : 5;
  $existingComment = '';
  if (isset($reviewedProjectIds[$pid_r])) {
      foreach ($myReviews as $_rv) {
          if ((int)$_rv['project_id'] === (int)$pid_r) {
              $existingComment = $_rv['description'];
              break;
          }
      }
  }
  $faces = [
    1 => ['emoji'=>'😞','label'=>'Terrible'],
    2 => ['emoji'=>'😐','label'=>'Below Avg'],
    3 => ['emoji'=>'🙂','label'=>'Okay'],
    4 => ['emoji'=>'😊','label'=>'Good'],
    5 => ['emoji'=>'🤩','label'=>'Excellent'],
  ];
?>
<div class="modal-overlay" id="review-<?= $pid_r ?>">
  <div class="modal-box" style="max-width:480px;">
    <div class="modal-header">
      <span class="modal-title">⭐ Rate Your Experience</span>
      <button class="modal-close" onclick="closeModal('review-<?= $pid_r ?>')">✕</button>
    </div>
    <p style="font-size:13px;color:var(--muted);margin-bottom:18px;">How was your experience with <strong style="color:#e2e8f0;"><?= e($p['title']) ?></strong>?</p>
    <form method="POST">
      <input type="hidden" name="action" value="submit_review">
      <input type="hidden" name="project_id" value="<?= $pid_r ?>">
      <input type="hidden" name="rating" id="ratingVal-<?= $pid_r ?>" value="<?= $existingRating ?>">

      <!-- Emoji face rating selector -->
      <div style="margin-bottom:22px;">
        <label class="form-label" style="margin-bottom:12px;">Your Rating</label>
        <div style="display:flex;gap:8px;justify-content:center;">
          <?php foreach($faces as $fval => $fdata): ?>
          <button type="button"
            id="face-<?= $pid_r ?>-<?= $fval ?>"
            onclick="selectRating(<?= $pid_r ?>, <?= $fval ?>)"
            style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;padding:12px 6px;border-radius:12px;cursor:pointer;transition:all .18s;border:2px solid <?= $fval===$existingRating ? '#10b981' : 'rgba(255,255,255,.1)' ?>;background:<?= $fval===$existingRating ? 'rgba(16,185,129,.12)' : 'rgba(255,255,255,.03)' ?>;">
            <span style="font-size:26px;line-height:1;"><?= $fdata['emoji'] ?></span>
            <span style="font-size:9px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;"><?= $fdata['label'] ?></span>
          </button>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Your Feedback *</label>
        <textarea name="comment" class="form-control" rows="3" placeholder="Share your experience working with us..." required><?= e($existingComment) ?></textarea>
      </div>

      <!-- Photo attachment: use profile picture -->
      <?php
        $hasPhoto = !empty($user['profile_photo']);
        $photoUrlR = $hasPhoto ? '/devloom/uploads/avatars/' . e(basename($user['profile_photo'])) : '';
      ?>
      <div class="form-group" style="margin-bottom:18px;">
        <label class="form-label" style="margin-bottom:8px;">Attach Photo (optional)</label>
        <?php if ($hasPhoto): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;">
          <img src="<?= $photoUrlR ?>" alt="Profile photo" style="width:44px;height:44px;border-radius:50%;object-fit:cover;flex-shrink:0;">
          <div style="flex:1;">
            <div style="font-size:13px;font-weight:600;color:#e2e8f0;">Use your profile picture</div>
            <div style="font-size:11px;color:var(--muted);">Attach this photo to your review</div>
          </div>
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;">
            <input type="checkbox" name="attach_profile_photo" value="1" id="attachPhoto-<?= $pid_r ?>"
              style="width:16px;height:16px;accent-color:#10b981;"
              <?= !empty($existingReviewPhoto[$pid_r]) ? 'checked' : '' ?>>
            <span style="font-size:12px;color:#94a3b8;">Attach</span>
          </label>
        </div>
        <?php else: ?>
        <div style="padding:12px;background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.08);border-radius:12px;text-align:center;">
          <span style="font-size:12px;color:var(--muted);">No profile photo set. <a href="/devloom/profile.php" style="color:#10b981;">Add one in your profile</a> to attach it here.</span>
        </div>
        <?php endif; ?>
        <input type="hidden" name="profile_photo_path" value="<?= e($user['profile_photo'] ?? '') ?>">
      </div>

      <div class="flex gap-8">
        <button type="submit" class="btn btn-primary" style="flex:1;">
          <?= $existingComment ? 'Update Review →' : 'Submit Review →' ?>
        </button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('review-<?= $pid_r ?>')">Cancel</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php endforeach; ?>

<!-- Submit Modal -->
<div class="modal-overlay" id="modal-submit">
  <div class="modal-box">
    <div class="modal-header">
      <span class="modal-title">📁 Submit New Project</span>
      <button class="modal-close" onclick="closeModal('modal-submit')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="submit_project">
      <div class="form-group">
        <label class="form-label">Project Title *</label>
        <input type="text" name="title" class="form-control" placeholder="e.g., E-Commerce Website" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description *</label>
        <textarea name="description" class="form-control" rows="4" placeholder="Describe what you need built in detail..." required></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Tech Stack (optional)</label>
        <input type="text" name="tech_stack" class="form-control" placeholder="e.g., React, Node.js, MongoDB">
      </div>
      <p class="text-muted mb-16" style="font-size:13px;">Admin will review and set budget and timeline.</p>
      <button type="submit" class="btn btn-primary btn-full">Submit Project →</button>
    </form>
  </div>
</div>

<script>
function scrollToProjects(){
  document.getElementById('projects')?.scrollIntoView({behavior:'smooth', block:'start'});
  return false;
}

function selectRating(pid, val) {
  document.getElementById('ratingVal-' + pid).value = val;
  for (let i = 1; i <= 5; i++) {
    const btn = document.getElementById('face-' + pid + '-' + i);
    if (!btn) continue;
    if (i === val) {
      btn.style.borderColor = '#10b981';
      btn.style.background  = 'rgba(16,185,129,.1)';
      btn.style.transform   = 'scale(1.05)';
    } else {
      btn.style.borderColor = 'rgba(255,255,255,.08)';
      btn.style.background  = 'rgba(255,255,255,.03)';
      btn.style.transform   = '';
    }
  }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
