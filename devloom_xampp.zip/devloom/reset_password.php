<?php
/**
 * reset_password.php — Forgot password via username + phone number
 * Works for guests; logged-in users are sent to change_password.php
 */
require_once __DIR__ . '/config/db.php';

// Logged-in users should use change_password.php
if (isLoggedIn() && !isAdmin()) {
    header('Location: /devloom/change_password.php');
    exit;
}

$error   = '';
$success = '';
$step    = 1; // 1 = enter username+phone, 2 = set new password

// ── Step 2 POST: set new password ────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset_step2') {
    csrf_check();
    $uid       = (int)($_SESSION['pwd_reset_uid']  ?? 0);
    $resetTime = (int)($_SESSION['pwd_reset_time'] ?? 0);
    $newPass   = $_POST['new_password']     ?? '';
    $confPass  = $_POST['confirm_password'] ?? '';

    if (!$uid || (time() - $resetTime) > 900) {
        unset($_SESSION['pwd_reset_uid'], $_SESSION['pwd_reset_time']);
        $error = 'Session expired. Please start over.';
        $step  = 1;
    } elseif (strlen($newPass) < 6) {
        $error = 'Password must be at least 6 characters.';
        $step  = 2;
    } elseif ($newPass !== $confPass) {
        $error = 'Passwords do not match.';
        $step  = 2;
    } else {
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
            ->execute([password_hash($newPass, PASSWORD_DEFAULT), $uid]);
        unset($_SESSION['pwd_reset_uid'], $_SESSION['pwd_reset_time']);
        $success = 'Password reset successfully! You can now sign in.';
        $step = 1;
    }
}

// ── Step 1 POST: verify username + phone number ────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset_step1') {
    csrf_check();
    $username = strtolower(trim($_POST['username'] ?? ''));
    $phone    = preg_replace('/\D/', '', trim($_POST['phone'] ?? '')); // digits only

    if (!$username || !$phone) {
        $error = 'Please fill in both fields.';
        $step  = 1;
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = 'Username not found.';
            $step  = 1;
        } elseif (empty($user['phone'])) {
            $error = 'No phone number is saved for this account. Please contact admin.';
            $step  = 1;
        } elseif (preg_replace('/\D/', '', $user['phone']) !== $phone) {
            $error = 'Phone number does not match our records.';
            $step  = 1;
        } else {
            $_SESSION['pwd_reset_uid']  = $user['id'];
            $_SESSION['pwd_reset_time'] = time();
            $step = 2;
        }
    }
}

// Restore step 2 if session still valid
if ($step === 1 && isset($_SESSION['pwd_reset_uid']) && (time() - ($_SESSION['pwd_reset_time'] ?? 0)) < 900) {
    $step = 2;
}

$pageTitle  = 'Reset Password';
$activePage = 'auth';
include __DIR__ . '/includes/header.php';
?>

<div class="container-sm" style="padding-top:60px;padding-bottom:80px;max-width:440px;">

  <div class="text-center" style="margin-bottom:28px;">
    <h1 class="heading-md">🔑 Forgot Password</h1>
    <p class="text-muted" style="font-size:14px;margin-top:6px;">
      <?= $step === 2 ? 'Step 2: Set your new password' : 'Step 1: Verify your identity' ?>
    </p>
  </div>

  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

  <?php if ($step === 1 && !$success): ?>
  <div class="card">
    <form method="POST" autocomplete="off"><?= csrf_field() ?>
      <input type="hidden" name="action" value="reset_step1">

      <div class="form-group">
        <label class="form-label">Username <span style="color:var(--red)">*</span></label>
        <input type="text" name="username" class="form-control"
               value="<?= e($_POST['username'] ?? '') ?>"
               placeholder="Your login username" required autocomplete="off"
               oninput="this.value=this.value.toLowerCase()">
      </div>

      <div class="form-group">
        <label class="form-label">Phone Number <span style="color:var(--red)">*</span></label>
        <input type="tel" name="phone" class="form-control"
               placeholder="Phone number saved in your profile" required autocomplete="off"
               value="<?= e($_POST['phone'] ?? '') ?>">
        <small style="color:var(--muted);font-size:11px;margin-top:4px;display:block;">
          Enter the phone number you saved in your profile settings.
        </small>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;">Verify Identity →</button>
    </form>

    <div style="margin-top:16px;text-align:center;font-size:13px;color:var(--muted);">
      Remember your password? <a href="/devloom/auth.php" style="color:#10b981;">Sign in</a>
    </div>
  </div>

  <?php elseif ($step === 2): ?>
  <div class="card">
    <form method="POST" autocomplete="off" id="pw-form"><?= csrf_field() ?>
      <input type="hidden" name="action" value="reset_step2">

      <div class="form-group">
        <label class="form-label">New Password <span style="color:var(--red)">*</span></label>
        <div style="position:relative;">
          <input type="password" name="new_password" id="pw-new" class="form-control"
                 placeholder="Min. 6 characters" required autocomplete="new-password"
                 style="padding-right:44px;" oninput="checkStrength(this.value)">
          <button type="button" onclick="togglePw('pw-new','eye-new')" id="eye-new"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;cursor:pointer;color:var(--muted);font-size:16px;display:flex;align-items:center;justify-content:center;">👁</button>
        </div>
        <div id="strength-bar" style="margin-top:6px;height:4px;border-radius:2px;background:var(--border);overflow:hidden;">
          <div id="strength-fill" style="height:100%;width:0;transition:width .3s,background .3s;border-radius:2px;"></div>
        </div>
        <div id="strength-label" style="font-size:11px;color:var(--muted);margin-top:3px;"></div>
      </div>

      <div class="form-group">
        <label class="form-label">Confirm Password <span style="color:var(--red)">*</span></label>
        <div style="position:relative;">
          <input type="password" name="confirm_password" id="pw-confirm" class="form-control"
                 placeholder="Repeat your new password" required autocomplete="new-password"
                 style="padding-right:44px;" oninput="checkMatch()">
          <button type="button" onclick="togglePw('pw-confirm','eye-confirm')" id="eye-confirm"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;cursor:pointer;color:var(--muted);font-size:16px;display:flex;align-items:center;justify-content:center;">👁</button>
        </div>
        <div id="match-label" style="font-size:11px;margin-top:3px;"></div>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;">Reset Password →</button>
    </form>
  </div>
  <?php endif; ?>

  <?php if ($success): ?>
  <div style="text-align:center;margin-top:16px;">
    <a href="/devloom/auth.php" class="btn btn-primary">Sign In Now →</a>
  </div>
  <?php endif; ?>

</div>

<script>
function togglePw(inputId, btnId) {
  var pw = document.getElementById(inputId);
  var eye = document.getElementById(btnId);
  if (!pw) return;
  pw.type = pw.type === 'password' ? 'text' : 'password';
  if (eye) eye.innerHTML = pw.type === 'text' ? '&#x1F648;' : '&#x1F441;';
}
function checkStrength(val) {
  var fill = document.getElementById('strength-fill');
  var label = document.getElementById('strength-label');
  if (!fill) return;
  var score = 0;
  if (val.length >= 6)  score++;
  if (val.length >= 10) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  var colors = ['#ef4444','#f97316','#f59e0b','#10b981','#10b981'];
  var labels = ['Very weak','Weak','Fair','Strong','Very strong'];
  var widths = ['20%','40%','60%','80%','100%'];
  if (val.length === 0) { fill.style.width = '0'; label.textContent = ''; return; }
  var idx = Math.min(score - 1, 4);
  if (idx < 0) idx = 0;
  fill.style.width = widths[idx];
  fill.style.background = colors[idx];
  label.style.color = colors[idx];
  label.textContent = labels[idx];
}
function checkMatch() {
  var pw1 = document.getElementById('pw-new').value;
  var pw2 = document.getElementById('pw-confirm').value;
  var label = document.getElementById('match-label');
  if (!pw2) { label.textContent = ''; return; }
  if (pw1 === pw2) {
    label.style.color = '#10b981';
    label.textContent = '✓ Passwords match';
  } else {
    label.style.color = '#ef4444';
    label.textContent = '✗ Passwords do not match';
  }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
