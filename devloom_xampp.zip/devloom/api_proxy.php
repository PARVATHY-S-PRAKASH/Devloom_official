<?php
require_once __DIR__ . '/config/db.php';
requireLogin(); // Only logged-in users can use API

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$body = file_get_contents('php://input');
$data = json_decode($body, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Only allow claude-sonnet model, cap tokens
$data['model'] = 'claude-sonnet-4-6';
if (!isset($data['max_tokens']) || $data['max_tokens'] > 1000) {
    $data['max_tokens'] = 1000;
}

// Priority: server-side key → client-provided key header
$apiKey = '';
if (defined('ANTHROPIC_API_KEY') && ANTHROPIC_API_KEY !== 'YOUR_API_KEY_HERE') {
    $apiKey = ANTHROPIC_API_KEY;
} elseif (!empty($_SERVER['HTTP_X_API_KEY'])) {
    $apiKey = trim($_SERVER['HTTP_X_API_KEY']);
}

if (!$apiKey || strpos($apiKey, 'sk-ant-') !== 0) {
    http_response_code(401);
    echo json_encode([
        'error' => 'api_key_missing',
        'message' => 'No API key configured. Add your Anthropic key in config/db.php or enter it in the UI.'
    ]);
    exit;
}

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($data),
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . $apiKey,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_TIMEOUT        => 60,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response = curl_exec($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    http_response_code(500);
    echo json_encode(['error' => 'cURL error: ' . $curlError]);
    exit;
}

http_response_code($httpCode);
echo $response;
