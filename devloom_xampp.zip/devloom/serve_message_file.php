<?php
/**
 * serve_message_file.php — Serves chat message attachments securely.
 * Usage: /devloom/serve_message_file.php?f=filename.pdf
 *        /devloom/serve_message_file.php?f=filename.pdf&dl=1  (force download)
 *
 * Access rules:
 *  - Logged-in users can only access files from their own messages.
 *  - Admins can access any chat attachment.
 */
require_once __DIR__ . '/config/db.php';

if (!isLoggedIn()) {
    http_response_code(403); exit('Access denied. Please log in.');
}

$filename = basename($_GET['f'] ?? '');
if (!$filename || strpos($filename, '..') !== false) {
    http_response_code(400); exit('Bad request');
}

if (isAdmin()) {
    // Admin: confirm file is in message_attachments table
    $stmt = $pdo->prepare("SELECT ma.id, ma.original_name, ma.mime_type FROM message_attachments ma WHERE ma.filename = ? LIMIT 1");
    $stmt->execute([$filename]);
} else {
    // User: only their own messages
    $stmt = $pdo->prepare("
        SELECT ma.id, ma.original_name, ma.mime_type
        FROM message_attachments ma
        INNER JOIN user_messages um ON um.id = ma.message_id
        WHERE ma.filename = ? AND um.user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$filename, currentUserId()]);
}

$row = $stmt->fetch();
if (!$row) {
    http_response_code(404); exit('File not found');
}

$filePath = __DIR__ . '/uploads/messages/' . $filename;
if (!file_exists($filePath)) {
    http_response_code(404); exit('File not found on disk');
}

$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$mimeMap = [
    'jpg' => 'image/jpeg',  'jpeg' => 'image/jpeg',
    'png' => 'image/png',   'gif'  => 'image/gif',
    'webp'=> 'image/webp',  'bmp'  => 'image/bmp',
    'svg' => 'image/svg+xml',
    'pdf' => 'application/pdf',
    'zip' => 'application/zip',
    'rar' => 'application/x-rar-compressed',
    'doc' => 'application/msword',
    'docx'=> 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls' => 'application/vnd.ms-excel',
    'xlsx'=> 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt' => 'application/vnd.ms-powerpoint',
    'pptx'=> 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'txt' => 'text/plain',
    'csv' => 'text/csv',
    'mp4' => 'video/mp4',
    'mp3' => 'audio/mpeg',
];
$mime = $mimeMap[$ext] ?? ($row['mime_type'] ?: 'application/octet-stream');

$displayName = $row['original_name'] ?: $filename;
$forceDownload = isset($_GET['dl']);
$inlineTypes   = ['jpg','jpeg','png','gif','webp','bmp','svg','pdf'];
$inline = !$forceDownload && in_array($ext, $inlineTypes);

header('Content-Type: '        . $mime);
header('Content-Length: '      . filesize($filePath));
header('Cache-Control: private, max-age=3600');
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . addslashes($displayName) . '"');

readfile($filePath);
exit;
