<?php
require_once __DIR__ . '/config/db.php';
requireUser();

$userId  = currentUserId();
$error   = flash('error');
$success = flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password']     ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        $error = 'User not found. Please sign in again.';
    } elseif (!$current) {
        $error = 'Please enter your current password.';
    } elseif (!password_verify($current, $user['password'])) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $error = 'New passwords do not match.';
    } elseif ($new === $current) {
        $error = 'New password must be different from your current password.';
    } else {
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
            ->execute([password_hash($new, PASSWORD_DEFAULT), $userId]);
        flash('success', 'Password changed successfully! 🔐');
        header('Location: /devloom/dashboard.php'); exit;
    }
}

$pageTitle  = 'Change Password';
$activePage = 'dashboard';
include __DIR__ . '/includes/header.php';
?>

<div class="container-sm" style="padding-top:40px;padding-bottom:80px;">

  <div class="page-header" style="margin-bottom:28px;">
    <div>
      <h1 class="heading-md">🔒 Change Password</h1>
      <p class="text-muted" style="margin-top:4px;font-size:14px;">Update your account password securely</p>
    </div>
    <a href="/devloom/profile.php" class="btn btn-ghost btn-sm">← My Profile</a>
  </div>

  <div class="card" style="max-width:480px;">

    <?php if ($error):   ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

    <form method="POST" autocomplete="on" id="pw-form"><?= csrf_field() ?>

      <div class="form-group">
        <label class="form-label">Current Password <span style="color:var(--red)">*</span></label>
        <div style="position:relative;">
          <input type="password" name="current_password" id="pw-current" class="form-control"
                 placeholder="Your current password" required autocomplete="current-password"
                 style="padding-right:44px;">
          <button type="button" onclick="togglePw('pw-current','eye-current')"
                  id="eye-current" title="Show/hide"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                         cursor:pointer;color:var(--muted);font-size:16px;display:flex;align-items:center;justify-content:center;">👁</button>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">New Password <span style="color:var(--red)">*</span></label>
        <div style="position:relative;">
          <input type="password" name="new_password" id="pw-new" class="form-control"
                 placeholder="Min. 6 characters" required autocomplete="new-password"
                 style="padding-right:44px;" oninput="checkStrength(this.value)">
          <button type="button" onclick="togglePw('pw-new','eye-new')"
                  id="eye-new" title="Show/hide"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                         cursor:pointer;color:var(--muted);font-size:16px;display:flex;align-items:center;justify-content:center;">👁</button>
        </div>
        <div id="strength-bar" style="margin-top:6px;height:4px;border-radius:2px;background:var(--border);overflow:hidden;">
          <div id="strength-fill" style="height:100%;width:0;transition:width .3s,background .3s;border-radius:2px;"></div>
        </div>
        <div id="strength-label" style="font-size:11px;color:var(--muted);margin-top:3px;"></div>
      </div>

      <div class="form-group">
        <label class="form-label">Confirm New Password <span style="color:var(--red)">*</span></label>
        <div style="position:relative;">
          <input type="password" name="confirm_password" id="pw-confirm" class="form-control"
                 placeholder="Repeat your new password" required autocomplete="new-password"
                 style="padding-right:44px;" oninput="checkMatch()">
          <button type="button" onclick="togglePw('pw-confirm','eye-confirm')"
                  id="eye-confirm" title="Show/hide"
                  style="position:absolute;right:0;top:0;bottom:0;width:40px;background:none;border:none;
                         cursor:pointer;color:var(--muted);font-size:16px;display:flex;align-items:center;justify-content:center;">👁</button>
        </div>
        <div id="match-label" style="font-size:11px;margin-top:3px;"></div>
      </div>

      <div style="display:flex;gap:12px;margin-top:8px;">
        <a href="/devloom/profile.php" class="btn btn-ghost" style="flex:1;justify-content:center;">Cancel</a>
        <button type="submit" class="btn btn-primary" style="flex:2;">Update Password →</button>
      </div>

    </form>

    <div class="alert alert-info" style="margin-top:20px;margin-bottom:0;">
      <strong>💡 Tips for a strong password:</strong><br>
      Use 8+ characters with a mix of uppercase, lowercase, numbers, and symbols.
    </div>
  </div>

  <div style="margin-top:16px;">
    <a href="/devloom/dashboard.php" class="btn btn-ghost btn-sm">← Back to Dashboard</a>
  </div>
</div>

<script>
function togglePw(inputId, btnId) {
  var pw  = document.getElementById(inputId);
  var eye = document.getElementById(btnId);
  if (!pw) return;
  pw.type = pw.type === 'password' ? 'text' : 'password';
  if (eye) eye.innerHTML = pw.type === 'text' ? '&#x1F648;' : '&#x1F441;';
}
function checkStrength(val) {
  var fill  = document.getElementById('strength-fill');
  var label = document.getElementById('strength-label');
  if (!fill) return;
  var score = 0;
  if (val.length >= 6)  score++;
  if (val.length >= 10) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  var colors = ['#ef4444','#f97316','#f59e0b','#10b981','#10b981'];
  var labels = ['Very weak','Weak','Fair','Strong','Very strong'];
  var widths = ['20%','40%','60%','80%','100%'];
  if (val.length === 0) { fill.style.width = '0'; label.textContent = ''; return; }
  var idx = Math.min(score - 1, 4);
  if (idx < 0) idx = 0;
  fill.style.width      = widths[idx];
  fill.style.background = colors[idx];
  label.style.color     = colors[idx];
  label.textContent     = labels[idx];
}
function checkMatch() {
  var pw1   = document.getElementById('pw-new').value;
  var pw2   = document.getElementById('pw-confirm').value;
  var label = document.getElementById('match-label');
  if (!pw2) { label.textContent = ''; return; }
  if (pw1 === pw2) {
    label.style.color = '#10b981';
    label.textContent = '✓ Passwords match';
  } else {
    label.style.color = '#ef4444';
    label.textContent = '✗ Passwords do not match';
  }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
