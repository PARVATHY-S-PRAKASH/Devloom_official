# Devloom — AWS Production Deployment Guide

## Architecture Overview

```
Internet
   │
   ▼
[Route 53]  ← DNS + Health Checks
   │
   ▼
[CloudFront CDN]  ← Static assets (CSS/JS/images) cached globally
   │
   ▼
[Application Load Balancer (ALB)]  ← HTTPS termination, path routing
   │           │
   ▼           ▼
[EC2 / ECS Target Group]   (Auto Scaling Group — min 2, max 10)
   │
   ▼
[Amazon RDS MySQL]  ← Multi-AZ, encrypted, automated backups
   │
   ▼
[Amazon S3]         ← Uploaded files (QR codes, screenshots, messages)
   │
   ▼
[Amazon SQS]        ← Async tasks (email notifications, AI note jobs)
   │
   ▼
[AWS Lambda]        ← SQS consumer: sends emails, calls Claude API
```

---

## 1. VPC & Networking

Create a VPC with:
- **2 Public Subnets** (ALB, NAT Gateway) — e.g. `10.0.1.0/24`, `10.0.2.0/24`
- **2 Private Subnets** (EC2/ECS, RDS) — e.g. `10.0.10.0/24`, `10.0.11.0/24`
- **Internet Gateway** attached to public subnets
- **NAT Gateway** in one public subnet (private instances need outbound internet for Composer/PHP)

```
aws ec2 create-vpc --cidr-block 10.0.0.0/16 --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=devloom-vpc}]'
```

**Security Groups:**

| SG Name              | Inbound Rules                                  | Outbound |
|----------------------|------------------------------------------------|----------|
| `sg-alb`             | 80 (HTTP), 443 (HTTPS) from 0.0.0.0/0          | All      |
| `sg-app`             | 80 from `sg-alb` only                          | All      |
| `sg-rds`             | 3306 from `sg-app` only                        | None     |
| `sg-lambda`          | None                                           | All      |

---

## 2. Unique ID (UUID) for Users & Projects

Replace auto-increment IDs with UUIDs for security and distributed safety.

**Run this migration on RDS:**

```sql
-- Add UUID columns
ALTER TABLE users    ADD COLUMN uuid CHAR(36) UNIQUE DEFAULT NULL;
ALTER TABLE projects ADD COLUMN uuid CHAR(36) UNIQUE DEFAULT NULL;

-- Backfill existing rows
UPDATE users    SET uuid = UUID() WHERE uuid IS NULL;
UPDATE projects SET uuid = UUID() WHERE uuid IS NULL;
```

**In `config/db.php`, add a UUID generator:**

```php
function generateUUID(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}
```

**Use UUID in project/user creation:**

```php
$uuid = generateUUID();
$pdo->prepare("INSERT INTO projects (uuid, user_id, title, ...) VALUES (?,?,?,...)");
```

Public-facing URLs should use UUID instead of numeric ID:
- `/project/3a7b9c12-...` instead of `/project/42`

---

## 3. Amazon RDS (Managed MySQL)

```bash
aws rds create-db-instance \
  --db-instance-identifier devloom-db \
  --db-instance-class db.t3.medium \
  --engine mysql \
  --engine-version 8.0 \
  --master-username devloom_admin \
  --master-user-password "YourStrongPass#2025" \
  --allocated-storage 20 \
  --storage-type gp3 \
  --multi-az \
  --vpc-security-group-ids sg-XXXX \
  --db-subnet-group-name devloom-db-subnet-group \
  --backup-retention-period 7 \
  --storage-encrypted \
  --no-publicly-accessible
```

Update `config/db.php`:

```php
define('DB_HOST', getenv('DB_HOST'));  // RDS endpoint from .env / SSM
define('DB_USER', getenv('DB_USER'));
define('DB_PASS', getenv('DB_PASS'));
define('DB_NAME', 'devloom');
```

Store credentials in **AWS Systems Manager Parameter Store** (SSM):

```bash
aws ssm put-parameter --name /devloom/db_host --value "devloom-db.xxxx.rds.amazonaws.com" --type SecureString
aws ssm put-parameter --name /devloom/db_pass --value "YourStrongPass#2025" --type SecureString
```

---

## 4. Amazon S3 (File Storage for Uploads)

Replace local `uploads/` folder with S3.

**Create bucket:**

```bash
aws s3api create-bucket \
  --bucket devloom-uploads \
  --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1

# Block public access
aws s3api put-public-access-block \
  --bucket devloom-uploads \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
```

**PHP upload to S3** (install AWS SDK: `composer require aws/aws-sdk-php`):

```php
use Aws\S3\S3Client;

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => 'ap-south-1',
    // Credentials auto-loaded from EC2 Instance Role
]);

// Upload QR code
$s3->putObject([
    'Bucket'      => 'devloom-uploads',
    'Key'         => 'qr/' . $fname,
    'SourceFile'  => $tmpFile,
    'ContentType' => 'image/png',
]);

// Generate pre-signed URL (60 min expiry, private)
$cmd = $s3->getCommand('GetObject', ['Bucket' => 'devloom-uploads', 'Key' => 'qr/' . $fname]);
$url = (string) $s3->createPresignedRequest($cmd, '+60 minutes')->getUri();
```

**IAM Role for EC2** (attach to EC2 instance profile):

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["s3:GetObject","s3:PutObject","s3:DeleteObject"],
    "Resource": "arn:aws:s3:::devloom-uploads/*"
  }]
}
```

---

## 5. Amazon SQS (Message Queue)

Use SQS for async tasks: email notifications, AI code note generation, payment confirmation emails.

**Create queues:**

```bash
# Standard queue for notifications
aws sqs create-queue --queue-name devloom-notifications --region ap-south-1

# FIFO queue for payment confirmations (exactly-once processing)
aws sqs create-queue \
  --queue-name devloom-payments.fifo \
  --attributes FifoQueue=true,ContentBasedDeduplication=true
```

**Push to SQS from PHP** (when admin uploads a QR or marks project paid):

```php
use Aws\Sqs\SqsClient;

$sqs = new SqsClient(['version'=>'latest','region'=>'ap-south-1']);

// Enqueue: notify client that QR is ready
$sqs->sendMessage([
    'QueueUrl'    => 'https://sqs.ap-south-1.amazonaws.com/ACCOUNT/devloom-notifications',
    'MessageBody' => json_encode([
        'type'       => 'qr_uploaded',
        'project_id' => $pid,
        'user_email' => $userEmail,
        'amount'     => $amount,
    ]),
]);
```

**Lambda Consumer** (processes SQS messages):

```python
# lambda/notify_handler.py
import json, boto3

ses = boto3.client('ses', region_name='ap-south-1')

def handler(event, context):
    for record in event['Records']:
        msg = json.loads(record['body'])
        if msg['type'] == 'qr_uploaded':
            ses.send_email(
                Source='noreply@devloom.io',
                Destination={'ToAddresses': [msg['user_email']]},
                Message={
                    'Subject': {'Data': f"Payment QR Ready — {msg['project_id']}"},
                    'Body':    {'Text': {'Data': f"Your payment QR for ₹{msg['amount']} is ready. Login to pay."}}
                }
            )
```

Connect Lambda to SQS trigger in AWS Console: Lambda → Add trigger → SQS → select queue.

---

## 6. Application Load Balancer (ALB)

```bash
# Create ALB
aws elbv2 create-load-balancer \
  --name devloom-alb \
  --subnets subnet-PUBLIC1 subnet-PUBLIC2 \
  --security-groups sg-alb \
  --scheme internet-facing \
  --type application

# HTTPS Listener (port 443)
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=arn:aws:acm:... \
  --default-actions Type=forward,TargetGroupArn=arn:...

# HTTP → HTTPS redirect
aws elbv2 create-listener \
  --load-balancer-arn arn:... \
  --protocol HTTP --port 80 \
  --default-actions Type=redirect,RedirectConfig="{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}"
```

**Target Group** (EC2 or ECS):

```bash
aws elbv2 create-target-group \
  --name devloom-tg \
  --protocol HTTP \
  --port 80 \
  --vpc-id vpc-XXXXX \
  --health-check-path /devloom/index.php \
  --health-check-interval-seconds 30 \
  --healthy-threshold-count 2 \
  --unhealthy-threshold-count 3
```

---

## 7. EC2 Auto Scaling Group

**Launch Template** (Amazon Linux 2 + PHP 8.2 + Apache):

```bash
#!/bin/bash
# User Data Script
yum update -y
amazon-linux-extras enable php8.2
yum install -y httpd php php-mysqlnd php-pdo php-mbstring php-json
systemctl enable httpd && systemctl start httpd

# Pull app from S3 (deploy artifact)
aws s3 cp s3://devloom-deploys/latest.tar.gz /tmp/
tar -xzf /tmp/latest.tar.gz -C /var/www/html/

# Fetch config from SSM
DB_HOST=$(aws ssm get-parameter --name /devloom/db_host --with-decryption --query Parameter.Value --output text)
sed -i "s/localhost/$DB_HOST/" /var/www/html/devloom/config/db.php
```

**Auto Scaling Group:**

```bash
aws autoscaling create-auto-scaling-group \
  --auto-scaling-group-name devloom-asg \
  --launch-template LaunchTemplateId=lt-XXXXX,Version='$Latest' \
  --min-size 2 \
  --max-size 10 \
  --desired-capacity 2 \
  --target-group-arns arn:aws:elasticloadbalancing:... \
  --vpc-zone-identifier "subnet-PRIVATE1,subnet-PRIVATE2" \
  --health-check-type ELB \
  --health-check-grace-period 120
```

**Scaling Policies:**

```bash
# Scale out when CPU > 60% for 2 minutes
aws autoscaling put-scaling-policy \
  --auto-scaling-group-name devloom-asg \
  --policy-name scale-out \
  --policy-type TargetTrackingScaling \
  --target-tracking-configuration '{"PredefinedMetricSpecification":{"PredefinedMetricType":"ASGAverageCPUUtilization"},"TargetValue":60.0}'
```

---

## 8. Amazon ElastiCache (Redis) — Session Sharing

With multiple EC2 instances, PHP sessions must be shared. Use Redis:

```bash
aws elasticache create-replication-group \
  --replication-group-id devloom-redis \
  --description "Devloom PHP sessions" \
  --num-cache-clusters 2 \
  --cache-node-type cache.t3.micro \
  --engine redis \
  --cache-subnet-group-name devloom-cache-subnet \
  --security-group-ids sg-app
```

In `php.ini` or at runtime:

```php
ini_set('session.save_handler', 'redis');
ini_set('session.save_path', 'tcp://devloom-redis.XXXX.cache.amazonaws.com:6379');
```

---

## 9. Amazon CloudFront (CDN)

Serve static assets (`/assets/css/`, `/assets/js/`, `/uploads/`) from edge locations:

```bash
aws cloudfront create-distribution --distribution-config '{
  "Origins": {
    "Items": [{
      "Id": "devloom-alb",
      "DomainName": "devloom-alb-XXXX.ap-south-1.elb.amazonaws.com",
      "CustomOriginConfig": {"HTTPPort": 80, "HTTPSPort": 443, "OriginProtocolPolicy": "https-only"}
    }]
  },
  "DefaultCacheBehavior": {
    "TargetOriginId": "devloom-alb",
    "ViewerProtocolPolicy": "redirect-to-https",
    "CachePolicyId": "4135ea2d-6df8-44a3-9df3-4b5a84be39ad"
  }
}'
```

For S3 uploads (QR images, screenshots), use a separate CloudFront origin pointing to the S3 bucket with OAC (Origin Access Control) — clients get pre-signed URLs through CloudFront.

---

## 10. Route 53 + ACM SSL

```bash
# Request SSL certificate
aws acm request-certificate \
  --domain-name devloom.io \
  --subject-alternative-names "*.devloom.io" \
  --validation-method DNS \
  --region us-east-1  # CloudFront needs certs in us-east-1

# Create hosted zone
aws route53 create-hosted-zone --name devloom.io --caller-reference $(date +%s)

# A record → ALB
# Create alias record pointing devloom.io → ALB DNS name
```

---

## 11. CI/CD Pipeline (CodePipeline)

```
GitHub Push → CodePipeline → CodeBuild (tests) → S3 (artifact) → CodeDeploy (rolling update to ASG)
```

`appspec.yml` for CodeDeploy:

```yaml
version: 0.0
os: linux
files:
  - source: /
    destination: /var/www/html/devloom
hooks:
  AfterInstall:
    - location: scripts/restart_apache.sh
      timeout: 30
```

---

## 12. Monitoring & Alerts

```bash
# CloudWatch alarm: 5xx errors > 10/min
aws cloudwatch put-metric-alarm \
  --alarm-name devloom-5xx \
  --metric-name HTTPCode_Target_5XX_Count \
  --namespace AWS/ApplicationELB \
  --statistic Sum \
  --period 60 \
  --threshold 10 \
  --comparison-operator GreaterThanThreshold \
  --alarm-actions arn:aws:sns:...:devloom-alerts \
  --dimensions Name=LoadBalancer,Value=app/devloom-alb/XXXX

# RDS CPU alarm
aws cloudwatch put-metric-alarm \
  --alarm-name devloom-rds-cpu \
  --metric-name CPUUtilization \
  --namespace AWS/RDS \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --alarm-actions arn:aws:sns:...:devloom-alerts
```

---

## 13. Cost Estimate (ap-south-1 / Mumbai)

| Service                    | Config                       | ~Monthly Cost |
|----------------------------|------------------------------|---------------|
| EC2 (2× t3.small)          | Auto Scaling, min 2           | ~$25          |
| RDS MySQL (db.t3.medium)   | Multi-AZ, 20GB gp3            | ~$65          |
| ALB                        | 1 ALB + LCU hours             | ~$20          |
| S3                         | 10GB + requests               | ~$3           |
| SQS                        | 1M messages/month             | ~$0.40        |
| Lambda                     | 100K invocations              | ~$0.02        |
| ElastiCache (t3.micro)     | Redis, 1 node                 | ~$15          |
| CloudFront                 | 100GB transfer                | ~$9           |
| Route 53                   | 1 hosted zone                 | ~$0.50        |
| **Total**                  |                               | **~$138/mo**  |

---

## Quick-Start Checklist

- [ ] Create VPC + subnets + security groups
- [ ] Launch RDS Multi-AZ, import `devloom.sql` + `migrate.sql`
- [ ] Run UUID migration SQL on RDS
- [ ] Create S3 bucket `devloom-uploads`, configure IAM role
- [ ] Create SQS queues + Lambda consumer for notifications
- [ ] Launch EC2 with user-data script, create AMI
- [ ] Create ALB + target group + HTTPS listener (ACM cert)
- [ ] Create Auto Scaling Group (min 2)
- [ ] Set up ElastiCache Redis, update PHP session config
- [ ] Create CloudFront distribution → ALB
- [ ] Configure Route 53 A record → CloudFront
- [ ] Set up CodePipeline for automated deploys
- [ ] Configure CloudWatch alarms + SNS topic

---

*Built with PHP 8.2 · MySQL 8.0 · AWS (RDS, S3, SQS, Lambda, ALB, ASG, ElastiCache, CloudFront, Route 53)*
