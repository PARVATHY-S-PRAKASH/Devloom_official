<?php
// api_notify.php — lightweight polling endpoint for real-time notifications
require_once __DIR__ . '/config/db.php';
header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['count' => 0]);
    exit;
}

if (isAdmin()) {
    $count = (int)$pdo->query("SELECT COUNT(*) FROM user_messages WHERE sender='user' AND is_read=0")->fetchColumn();
} else {
    $uid   = currentUserId();
    $stmt  = $pdo->prepare("SELECT COUNT(*) FROM user_messages WHERE user_id=? AND sender='admin' AND is_read=0");
    $stmt->execute([$uid]);
    $count = (int)$stmt->fetchColumn();
}

echo json_encode(['count' => $count]);
