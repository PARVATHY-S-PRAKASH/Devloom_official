# Devloom — Web + Mobile Integration Guide

This explains what changed to attach the Android app (`devloom-mobile/`) to the
existing PHP/XAMPP web app (`devloom/`), so users can download and use it,
with push notifications working.

## What was added (nothing existing was changed in behavior)

**Web app (`devloom/`) — all brand new, additive files:**
- `mobile_api/` — a small PHP API just for the app (login, register, refresh
  token, forgot password, dashboard summary, profile, push-token registration).
  Reuses your existing `devloom` MySQL database and password hashing — a
  user's website account and app account are the same account.
- `get-app.php` — a public "Get the App" page with a download button and a
  QR code, linked from the navbar (📱 Get App).
- `downloads/` — where the built `devloom.apk` file goes (see below).
- `database/migrate_mobile.sql` — optional manual SQL for the two new tables
  (`mobile_tokens`, `device_tokens`); they're also auto-created the first
  time the app calls the API, same auto-migration style already used in
  `config/db.php`.

**Two small, additive edits to existing files:**
- `includes/header.php` — added one nav link ("📱 Get App"). Nothing else
  in the header changed.
- `admin/index.php` — added a couple of lines (wrapped in a file-exists
  check, so it's a safe no-op if `mobile_api/` is ever removed) that send a
  push notification when: an admin replies to a user's message, or an admin
  updates a project's status/payment.

**Mobile app (`devloom-mobile/`):**
- `lib/config.ts` — `API_BASE_URL` now points at `mobile_api/` instead of a
  placeholder NestJS URL.
- `lib/api.ts` / `lib/notifications.ts` — endpoint paths updated to match the
  new PHP files (`/login.php`, `/register.php`, etc.).
- `lib/auth-store.ts` — on app restart, it now re-fetches the real profile
  using the stored token, instead of only checking that a token exists.
- Everything else (screens, navigation, styling, demo mode) is unchanged.

## The one step you have to run yourself: building the actual .apk

I can hand you all the source code and the backend it talks to, but I can't
compile a `.apk` binary in this chat environment — that needs Android build
tooling (SDK, Gradle, signing keys) or Expo's cloud build service, neither of
which this sandboxed environment can reach.

```bash
cd devloom-mobile
npm install
npm install -g eas-cli
eas login              # free Expo account
eas build:configure
eas build -p android --profile preview
```

That last command builds on Expo's servers and gives you a download link for
a real, installable `.apk`. Download it, rename it to `devloom.apk`, and put
it in `devloom/downloads/devloom.apk` on your server. The `get-app.php` page
will automatically detect it and turn on the download button + QR code.

## Turning on real login + notifications (vs. demo mode)

The app ships with `DEMO_MODE = true` in `lib/config.ts` (mock data, no
backend needed) so it's safe and fully browsable right out of the box —
exactly like before. To connect it to your real PHP backend:

1. Make sure XAMPP (Apache + MySQL) is running and `http://localhost/devloom/`
   works normally.
2. In `devloom-mobile/lib/config.ts`, set:
   ```ts
   export const API_BASE_URL = 'http://<your-server-address>/devloom/mobile_api';
   export const DEMO_MODE = false;
   ```
   Use `10.0.2.2` instead of `localhost` if testing on the Android emulator;
   use your PC's LAN IP for a real phone on the same Wi-Fi; use your real
   domain once deployed.
3. Rebuild the APK (`eas build ...` above) so the change is baked in.
4. In `devloom-mobile/lib/notifications.ts`, replace `'YOUR_EAS_PROJECT_ID'`
   with the ID you get from `eas init` — required for push tokens to work.

## What's fully working vs. what's a placeholder

| Feature | Status |
|---|---|
| Login / Register / Forgot password | ✅ real, against your `users` table |
| Dashboard summary (projects, unread messages) | ✅ real |
| Profile | ✅ real |
| Push notifications (new admin message, project update) | ✅ real, via Expo's push API |
| App download page + QR code | ✅ real (once you upload the built APK) |
| Placement MCQs / Flashcards / Games / Resume / IDE / Viva | ⏳ still mock data on mobile — these features live entirely as client-side content in the PHP pages today, so there's no database table yet to serve them from. Each can be added the same way `dashboard_summary.php` was, whenever you're ready. |
