// Devloom PWA service worker.
// Handles: (1) making the app installable, (2) basic offline fallback,
// (3) receiving push notifications (once your backend sends them).

const CACHE_NAME = 'devloom-shell-v1';

// A minimal shell so the app doesn't show a browser error if opened
// while offline. Static assets are cached as they're visited (below),
// this list just covers the essentials up front.
const SHELL_ASSETS = [
  '/devloom/index.php',
  '/devloom/assets/css/style.css',
  '/devloom/assets/icons/icon-192.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Network-first for pages (so logged-in/dynamic content is always fresh),
// falling back to cache only when offline.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// Push notifications — fires when your backend sends a push message.
self.addEventListener('push', (event) => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'Devloom';
  const options = {
    body: data.body || 'You have a new update.',
    icon: '/devloom/assets/icons/icon-192.png',
    badge: '/devloom/assets/icons/icon-192.png',
    data: { url: data.url || '/devloom/dashboard.php' },
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(clients.openWindow(event.notification.data.url));
});
