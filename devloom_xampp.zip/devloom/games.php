<?php
require_once __DIR__ . '/config/db.php';
requireLogin();
$pageTitle  = 'Fun Zone — Games';
$activePage = 'features';
include __DIR__ . '/includes/header.php';
?>
<style>
.gz-wrap{max-width:960px;margin:0 auto;padding:36px 0 80px;}
.gz-header{text-align:center;margin-bottom:36px;padding:32px 24px;background:rgba(236,72,153,.04);border:1px solid rgba(236,72,153,.12);border-radius:20px;position:relative;overflow:hidden;}
.gz-header::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 50% 0%,rgba(236,72,153,.12),transparent 65%);pointer-events:none;}
.game-hub{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:14px;}
.game-card{background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.09);border-radius:20px;padding:24px 14px 20px;text-align:center;cursor:pointer;transition:all .28s cubic-bezier(.22,1,.36,1);text-decoration:none;display:flex;flex-direction:column;align-items:center;gap:8px;backdrop-filter:blur(8px);}
.game-card .gicon{font-size:2.6rem;line-height:1;transition:transform .35s cubic-bezier(.36,1.56,.64,1);}
.game-card .gname{font-size:13px;font-weight:800;color:#f1f5f9;}
.game-card .gdesc{font-size:10px;color:#64748b;line-height:1.4;}
.game-card .gbadge{font-size:10px;padding:3px 9px;border-radius:12px;background:rgba(236,72,153,.12);color:#f472b6;font-weight:700;border:1px solid rgba(236,72,153,.2);}
#game-area{display:none;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:24px;min-height:460px;box-shadow:0 8px 48px rgba(0,0,0,.3);}
#game-area.show{display:flex;flex-direction:column;align-items:center;}
.back-btn{display:flex;align-items:center;gap:6px;background:none;border:1px solid rgba(255,255,255,.12);border-radius:20px;color:#94a3b8;font-size:13px;padding:7px 16px;cursor:pointer;transition:all .22s cubic-bezier(.22,1,.36,1);margin-bottom:18px;align-self:flex-start;}
.back-btn:hover{border-color:rgba(236,72,153,.4);color:#f472b6;}
.g-info{display:flex;gap:16px;margin-bottom:14px;flex-wrap:wrap;justify-content:center;}
.ibox{background:rgba(0,0,0,.2);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:5px 14px;text-align:center;}
.ilabel{font-size:10px;color:#64748b;font-family:monospace;display:block;text-transform:uppercase;}
.ival{font-size:15px;font-weight:800;color:#e2e8f0;}
/* Mode selector */
.mode-sel{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;justify-content:center;}
.mode-btn{padding:7px 18px;border-radius:20px;border:1.5px solid rgba(255,255,255,.12);background:transparent;color:#94a3b8;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;}
.mode-btn.active{background:rgba(16,185,129,.15);border-color:#10b981;color:#10b981;}
.mode-btn.m-inter.active{background:rgba(245,158,11,.15);border-color:#f59e0b;color:#fbbf24;}
.mode-btn.m-hard.active{background:rgba(239,68,68,.15);border-color:#ef4444;color:#f87171;}
</style>

<div class="container">
<div class="gz-wrap">
  <div class="gz-header animate-up">
    <h1 class="gz-shimmer" style="font-size:2.4rem;font-weight:900;margin-bottom:8px;">🎮 Fun Zone</h1>
    <p style="color:#94a3b8;font-size:15px;">12 games to keep you entertained &amp; your mind sharp!</p>
    <div style="margin-top:14px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
      <span class="badge" style="background:rgba(236,72,153,.12);color:#f472b6;border-color:rgba(236,72,153,.3);">🕹️ Arcade</span>
      <span class="badge" style="background:rgba(96,165,250,.12);color:#60a5fa;border-color:rgba(96,165,250,.3);">🧠 Brain Games</span>
      <span class="badge" style="background:rgba(167,243,208,.1);color:#6ee7b7;border-color:rgba(16,185,129,.3);">⚡ Endless Run</span>

    </div>
  </div>

  <div class="game-hub animate-up-2" id="game-hub">
    <div class="game-card reveal delay-1" onclick="launchGame('snake')"><div class="gicon">🐍</div><div class="gname">Snake</div><div class="gdesc">Eat food, grow longer!</div><div class="gbadge">3 Modes</div></div>
    <div class="game-card reveal delay-2" onclick="launchGame('2048')"><div class="gicon">🔢</div><div class="gname">2048</div><div class="gdesc">Merge tiles to reach 2048!</div><div class="gbadge">Puzzle</div></div>
    <div class="game-card reveal delay-3" onclick="launchGame('jellyhole')"><div class="gicon">🕳️</div><div class="gname">Jelly Hole</div><div class="gdesc">Swallow objects, grow bigger!</div><div class="gbadge">Arcade</div></div>
    <div class="game-card reveal delay-4" onclick="launchGame('memory')"><div class="gicon">🃏</div><div class="gname">Memory Match</div><div class="gdesc">Find all pairs!</div><div class="gbadge">Brain Game</div></div>
    <div class="game-card reveal delay-5" onclick="launchGame('candycrush')"><div class="gicon">🍬</div><div class="gname">Candy Crush</div><div class="gdesc">Match 3 candies to crush!</div><div class="gbadge">Match-3</div></div>
    <div class="game-card reveal delay-6" onclick="launchGame('traffic')"><div class="gicon">🚗</div><div class="gname">Traffic Escape</div><div class="gdesc">Navigate through traffic!</div><div class="gbadge">Dodge</div></div>
    <div class="game-card reveal delay-6" onclick="launchGame('subwaysurfers')" style="transition-delay:.5s"><div class="gicon">🏄</div><div class="gname">Subway Surf</div><div class="gdesc">Run, dodge trains &amp; obstacles!</div><div class="gbadge">Endless Run</div></div>
    <div class="game-card reveal" onclick="launchGame('tetris')" style="transition-delay:.55s;"><div class="gicon">🟦</div><div class="gname">Tetris</div><div class="gdesc">Stack &amp; clear falling blocks!</div></div>
    <div class="game-card reveal" onclick="launchGame('breakout')" style="transition-delay:.6s;"><div class="gicon">🧱</div><div class="gname">Breakout</div><div class="gdesc">Smash all bricks with the ball!</div></div>
    <div class="game-card reveal" onclick="launchGame('flappy')" style="transition-delay:.65s;"><div class="gicon">🐦</div><div class="gname">Flappy Bird</div><div class="gdesc">Tap to fly, dodge the pipes!</div></div>
    <div class="game-card reveal" onclick="launchGame('minesweeper')" style="transition-delay:.7s;"><div class="gicon">💣</div><div class="gname">Minesweeper</div><div class="gdesc">Find all mines without exploding!</div></div>
    <div class="game-card reveal" onclick="launchGame('chess')" style="transition-delay:.75s;"><div class="gicon">♟️</div><div class="gname">Chess</div><div class="gdesc">Classic chess vs AI opponent!</div></div>
  </div>

  <div id="game-area">
    <button class="back-btn" onclick="backToHub()">← All Games</button>
    <div id="game-content" style="width:100%;display:flex;flex-direction:column;align-items:center;"></div>
  </div>
</div>
</div>

<script>
var activeGame=null, _cleanup=[];

function launchGame(name){
  doCleanup();
  activeGame=name;
  document.getElementById('game-hub').style.display='none';
  var area=document.getElementById('game-area');
  area.classList.add('show');
  document.getElementById('game-content').innerHTML='';
  ({snake:buildSnake,'2048':build2048,jellyhole:buildJellyHole,memory:buildMemory,candycrush:buildCandyCrush,traffic:buildTraffic,subwaysurfers:buildSubwaySurfers,tetris:buildTetris,breakout:buildBreakout,flappy:buildFlappy,minesweeper:buildMinesweeper,chess:buildChess})[name]?.();
}
function backToHub(){
  doCleanup();activeGame=null;
  document.getElementById('game-area').classList.remove('show');
  document.getElementById('game-hub').style.display='grid';
}
function doCleanup(){_cleanup.forEach(f=>{try{f();}catch(e){}});_cleanup=[];}
function reg(fn){_cleanup.push(fn);}

// ═══════════ SNAKE (with difficulty modes) ═══════════
var snakeMode='beginner';
function buildSnake(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="mode-sel">'+
    '<button class="mode-btn active" id="sn-m-b" onclick="setSnakeMode(\'beginner\',this)">🐣 Beginner</button>'+
    '<button class="mode-btn m-inter" id="sn-m-i" onclick="setSnakeMode(\'intermediate\',this)">🎯 Intermediate</button>'+
    '<button class="mode-btn m-hard" id="sn-m-h" onclick="setSnakeMode(\'expert\',this)">🔥 Expert</button>'+
    '</div>'+
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="sn-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Best</span><span class="ival" id="sn-best">'+(localStorage.getItem('snBest')||0)+'</span></div>'+
    '<div class="ibox"><span class="ilabel">Level</span><span class="ival" id="sn-lv">1</span></div>'+
    '</div>'+
    '<canvas id="sn-cv" width="360" height="360" style="background:#0d1117;border:1px solid rgba(16,185,129,.2);border-radius:8px;"></canvas>'+
    '<div style="margin-top:12px;display:flex;gap:10px;align-items:center;">'+
    '<button class="btn btn-primary btn-sm" id="sn-btn" onclick="snStart()">▶ Start</button>'+
    '<span style="font-size:12px;color:#64748b;">Arrow keys or WASD</span>'+
    '</div>';
  snakeMode='beginner';
}
function setSnakeMode(mode,btn){
  snakeMode=mode;
  document.querySelectorAll('.mode-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}
function snStart(){
  var cv=document.getElementById('sn-cv'); if(!cv)return;
  var ctx=cv.getContext('2d');
  var S=18,C=20,R=20;
  var speedMap={beginner:220,intermediate:150,expert:80};
  var baseSpeed=speedMap[snakeMode]||150;
  var snake=[{x:10,y:10}],dir={x:1,y:0},nd={x:1,y:0};
  var food=snFood(snake,C,R),score=0,speed=baseSpeed,iv,running=true,level=1;
  document.getElementById('sn-btn').textContent='⏹ Stop';
  document.getElementById('sn-btn').onclick=function(){running=false;clearInterval(iv);document.getElementById('sn-btn').textContent='▶ Restart';document.getElementById('sn-btn').onclick=snStart;};
  function kh(e){var k=e.key;if((k==='ArrowUp'||k==='w')&&dir.y===0)nd={x:0,y:-1};if((k==='ArrowDown'||k==='s')&&dir.y===0)nd={x:0,y:1};if((k==='ArrowLeft'||k==='a')&&dir.x===0)nd={x:-1,y:0};if((k==='ArrowRight'||k==='d')&&dir.x===0)nd={x:1,y:0};}
  document.addEventListener('keydown',kh);
  reg(function(){clearInterval(iv);document.removeEventListener('keydown',kh);running=false;});
  iv=setInterval(function(){
    if(!running)return;
    dir=nd;
    var head={x:(snake[0].x+dir.x+C)%C,y:(snake[0].y+dir.y+R)%R};
    if(snake.some(function(s){return s.x===head.x&&s.y===head.y;})){
      running=false;clearInterval(iv);
      var best=localStorage.getItem('snBest')||0;if(score>best){localStorage.setItem('snBest',score);document.getElementById('sn-best').textContent=score;}
      ctx.fillStyle='rgba(0,0,0,.75)';ctx.fillRect(0,0,360,360);
      ctx.fillStyle='#f472b6';ctx.font='bold 24px monospace';ctx.textAlign='center';ctx.fillText('GAME OVER',180,160);
      ctx.fillStyle='#94a3b8';ctx.font='14px monospace';ctx.fillText('Score: '+score,180,188);
      document.getElementById('sn-btn').textContent='🔄 Play Again';document.getElementById('sn-btn').onclick=snStart;
      return;
    }
    snake.unshift(head);
    if(head.x===food.x&&head.y===food.y){
      score+=10;document.getElementById('sn-sc').textContent=score;food=snFood(snake,C,R);
      if(score%(snakeMode==='beginner'?80:snakeMode==='intermediate'?50:30)===0){
        level++;document.getElementById('sn-lv').textContent=level;
        clearInterval(iv);
        var newSpeed=Math.max(snakeMode==='expert'?35:snakeMode==='intermediate'?60:100, speed-(snakeMode==='expert'?8:snakeMode==='intermediate'?12:10));
        speed=newSpeed;
        iv=setInterval(arguments.callee,newSpeed);
      }
    } else snake.pop();
    ctx.fillStyle='#0d1117';ctx.fillRect(0,0,360,360);
    snake.forEach(function(s,i){ctx.fillStyle=i===0?'#10b981':'#059669';ctx.beginPath();ctx.roundRect(s.x*S+1,s.y*S+1,S-2,S-2,3);ctx.fill();});
    ctx.fillStyle='#f43f5e';ctx.beginPath();ctx.arc(food.x*S+S/2,food.y*S+S/2,S/2-2,0,Math.PI*2);ctx.fill();
  },speed);
}
function snFood(s,C,R){var p;do{p={x:Math.floor(Math.random()*C),y:Math.floor(Math.random()*R)};}while(s.some(function(b){return b.x===p.x&&b.y===p.y;}));return p;}

// ═══════════ 2048 ═══════════
function build2048(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="t-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Best</span><span class="ival" id="t-best">'+(localStorage.getItem('t2048Best')||0)+'</span></div>'+
    '</div>'+
    '<div id="t-board" style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;background:#0f172a;padding:10px;border-radius:10px;width:280px;"></div>'+
    '<div style="margin-top:12px;display:flex;gap:10px;">'+
    '<button class="btn btn-ghost btn-sm" onclick="t2048New()">🔄 New Game</button>'+
    '<span style="font-size:12px;color:#64748b;">Arrow keys or swipe</span>'+
    '</div>';
  t2048New();
  // Keyboard
  function kh2(e){
    if(activeGame!=='2048')return;
    var map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down'};
    if(map[e.key]){e.preventDefault();t2048Move(map[e.key]);}
  }
  document.addEventListener('keydown',kh2);
  reg(function(){document.removeEventListener('keydown',kh2);});
  // Touch
  var tx2=0,ty2=0;
  function ts2(e){tx2=e.touches[0].clientX;ty2=e.touches[0].clientY;}
  function te2(e){
    if(activeGame!=='2048')return;
    var dx=e.changedTouches[0].clientX-tx2,dy=e.changedTouches[0].clientY-ty2;
    if(Math.abs(dx)>Math.abs(dy)){t2048Move(dx>0?'right':'left');}else{t2048Move(dy>0?'down':'up');}
  }
  document.addEventListener('touchstart',ts2,{passive:true});
  document.addEventListener('touchend',te2,{passive:true});
  reg(function(){document.removeEventListener('touchstart',ts2);document.removeEventListener('touchend',te2);});
}
var t2048Grid,t2048Score=0;
var tColors={'2':'#eee4da','4':'#ede0c8','8':'#f2b179','16':'#f59563','32':'#f67c5f','64':'#f65e3b','128':'#edcf72','256':'#edcc61','512':'#edc850','1024':'#edc53f','2048':'#edc22e'};
function t2048New(){
  t2048Grid=Array.from({length:4},()=>Array(4).fill(0));
  t2048Score=0;document.getElementById('t-sc').textContent=0;
  t2048AddTile();t2048AddTile();t2048Render();
}
function t2048AddTile(){
  var empty=[];
  for(var r=0;r<4;r++)for(var c=0;c<4;c++)if(!t2048Grid[r][c])empty.push([r,c]);
  if(!empty.length)return;
  var [r,c]=empty[Math.floor(Math.random()*empty.length)];
  t2048Grid[r][c]=Math.random()<0.9?2:4;
}
function t2048Render(){
  var b=document.getElementById('t-board');if(!b)return;
  b.innerHTML='';
  for(var r=0;r<4;r++)for(var c=0;c<4;c++){
    var v=t2048Grid[r][c];
    var cell=document.createElement('div');
    cell.style.cssText='width:58px;height:58px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:'+(v>99?v>999?'13px':'16px':'20px')+';font-weight:900;background:'+(v?tColors[v]||'#3b4c6e':'rgba(255,255,255,.05)')+';color:'+(v&&v<=4?'#776e65':v?'#f7f6f0':'transparent')+';transition:all .1s;';
    cell.textContent=v||'';
    b.appendChild(cell);
  }
}
function t2048Move(dir){
  var moved=false;
  var g=t2048Grid;
  function slideRow(row){
    var filtered=row.filter(x=>x);
    var merged=[];
    for(var i=0;i<filtered.length;i++){
      if(i+1<filtered.length&&filtered[i]===filtered[i+1]){
        var val=filtered[i]*2;merged.push(val);t2048Score+=val;i++;
      } else merged.push(filtered[i]);
    }
    while(merged.length<4)merged.push(0);
    return merged;
  }
  var orig=g.map(r=>[...r]);
  if(dir==='left'){for(var r=0;r<4;r++)g[r]=slideRow(g[r]);}
  else if(dir==='right'){for(var r=0;r<4;r++)g[r]=slideRow([...g[r]].reverse()).reverse();}
  else if(dir==='up'){
    for(var c=0;c<4;c++){var col=[g[0][c],g[1][c],g[2][c],g[3][c]];var s=slideRow(col);for(var r=0;r<4;r++)g[r][c]=s[r];}
  }
  else if(dir==='down'){
    for(var c=0;c<4;c++){var col=[g[0][c],g[1][c],g[2][c],g[3][c]];var s=slideRow(col.reverse()).reverse();for(var r=0;r<4;r++)g[r][c]=s[r];}
  }
  for(var r=0;r<4;r++)for(var c=0;c<4;c++)if(g[r][c]!==orig[r][c])moved=true;
  if(moved){
    t2048AddTile();
    var sc=document.getElementById('t-sc');if(sc)sc.textContent=t2048Score;
    var best=localStorage.getItem('t2048Best')||0;
    if(t2048Score>best){localStorage.setItem('t2048Best',t2048Score);var bs=document.getElementById('t-best');if(bs)bs.textContent=t2048Score;}
    t2048Render();
    // Check win/lose
    var hasEmpty=g.some(r=>r.some(c=>c===0));
    var has2048=g.some(r=>r.some(c=>c===2048));
    if(has2048){setTimeout(function(){alert('🎉 You reached 2048! Congrats!');},100);}
    else if(!hasEmpty){var canMove=false;for(var r=0;r<4;r++)for(var c=0;c<4;c++){if(c<3&&g[r][c]===g[r][c+1])canMove=true;if(r<3&&g[r][c]===g[r+1][c])canMove=true;}if(!canMove){setTimeout(function(){if(confirm('Game Over! Score: '+t2048Score+'\nPlay again?'))t2048New();},100);}}
  }
}


// ═══════════ JELLY HOLE ═══════════
function buildJellyHole(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="jh-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Size</span><span class="ival" id="jh-sz">1</span></div>'+
    '<div class="ibox"><span class="ilabel">Time</span><span class="ival" id="jh-tm">60</span></div>'+
    '</div>'+
    '<canvas id="jh-cv" width="380" height="380" style="background:#0f172a;border:1px solid rgba(99,102,241,.25);border-radius:12px;cursor:none;touch-action:none;"></canvas>'+
    '<div style="margin-top:10px;display:flex;gap:10px;align-items:center;">'+
    '<button class="btn btn-primary btn-sm" id="jh-btn" onclick="jhStart()">▶ Start</button>'+
    '<span style="font-size:12px;color:#64748b;">Move mouse / drag to swallow!</span>'+
    '</div>';
}
function jhStart(){
  var cv=document.getElementById('jh-cv');if(!cv)return;
  var ctx=cv.getContext('2d');
  var W=380,H=380;
  var hole={x:W/2,y:H/2,r:22};
  var score=0,timeLeft=60,running=true;
  var EMOJIS=['📦','🪑','🍎','🎁','🪴','🎮','🧸','🏀','🎯','🌟','🍕','🚗'];
  var objects=[];
  for(var i=0;i<18;i++){
    var sz=12+Math.random()*28;
    objects.push({x:30+Math.random()*(W-60),y:30+Math.random()*(H-60),r:sz,emoji:EMOJIS[Math.floor(Math.random()*EMOJIS.length)],eaten:false,vx:(Math.random()-.5)*1.2,vy:(Math.random()-.5)*1.2});
  }
  document.getElementById('jh-btn').textContent='⏹ Stop';
  document.getElementById('jh-btn').onclick=function(){running=false;document.getElementById('jh-btn').textContent='🔄 Restart';document.getElementById('jh-btn').onclick=jhStart;};
  function mm(e){var rect=cv.getBoundingClientRect();hole.x=(e.clientX-rect.left)*(W/rect.width);hole.y=(e.clientY-rect.top)*(H/rect.height);}
  function mt(e){e.preventDefault();var rect=cv.getBoundingClientRect();hole.x=(e.touches[0].clientX-rect.left)*(W/rect.width);hole.y=(e.touches[0].clientY-rect.top)*(H/rect.height);}
  cv.addEventListener('mousemove',mm);cv.addEventListener('touchmove',mt,{passive:false});
  reg(function(){running=false;clearInterval(tiv);cv.removeEventListener('mousemove',mm);cv.removeEventListener('touchmove',mt);cancelAnimationFrame(raf);});
  var tiv=setInterval(function(){
    if(!running)return;
    timeLeft--;var te=document.getElementById('jh-tm');if(te)te.textContent=timeLeft;
    if(timeLeft<=0){running=false;clearInterval(tiv);}
  },1000);
  var raf;
  function draw(){
    if(!running){
      ctx.fillStyle='rgba(0,0,0,.8)';ctx.fillRect(0,0,W,H);
      ctx.fillStyle='#818cf8';ctx.font='bold 22px monospace';ctx.textAlign='center';ctx.fillText('TIME UP!',W/2,H/2-10);
      ctx.fillStyle='#94a3b8';ctx.font='15px monospace';ctx.fillText('Score: '+score,W/2,H/2+18);
      document.getElementById('jh-btn').textContent='🔄 Play Again';document.getElementById('jh-btn').onclick=jhStart;
      return;
    }
    ctx.clearRect(0,0,W,H);
    ctx.fillStyle='#0f172a';ctx.fillRect(0,0,W,H);
    // Move objects
    objects.forEach(function(obj){
      if(obj.eaten)return;
      obj.x+=obj.vx;obj.y+=obj.vy;
      if(obj.x<obj.r||obj.x>W-obj.r)obj.vx*=-1;
      if(obj.y<obj.r||obj.y>H-obj.r)obj.vy*=-1;
      // Check eat
      var dist=Math.hypot(obj.x-hole.x,obj.y-hole.y);
      if(dist<hole.r-obj.r*0.4&&hole.r>obj.r*0.85){
        obj.eaten=true;score+=Math.ceil(obj.r);
        hole.r=Math.min(80,hole.r+obj.r*0.18);
        var sc=document.getElementById('jh-sc');if(sc)sc.textContent=score;
        var sz=document.getElementById('jh-sz');if(sz)sz.textContent=Math.round(hole.r/22*10)/10;
        // Respawn
        setTimeout(function(){
          var nz=12+Math.random()*28;
          obj.x=30+Math.random()*(W-60);obj.y=30+Math.random()*(H-60);obj.r=nz;obj.eaten=false;
          obj.emoji=EMOJIS[Math.floor(Math.random()*EMOJIS.length)];
        },1200);
      }
      ctx.font=(obj.r*1.6)+'px serif';ctx.textAlign='center';
      ctx.fillText(obj.emoji,obj.x,obj.y+obj.r*0.5);
    });
    // Draw hole (black circle with glow)
    var grad=ctx.createRadialGradient(hole.x,hole.y,hole.r*0.3,hole.x,hole.y,hole.r);
    grad.addColorStop(0,'rgba(0,0,0,1)');
    grad.addColorStop(0.7,'rgba(30,0,60,0.95)');
    grad.addColorStop(1,'rgba(99,102,241,0.3)');
    ctx.beginPath();ctx.arc(hole.x,hole.y,hole.r,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
    ctx.strokeStyle='rgba(139,92,246,0.7)';ctx.lineWidth=3;ctx.stroke();
    raf=requestAnimationFrame(draw);
  }
  draw();
}

// ═══════════ MEMORY MATCH ═══════════
var MEM_SETS=[
  ['🍎','🍊','🍋','🍇','🍓','🍑','🥝','🍉'],
  ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼'],
  ['🚀','🛸','🌙','⭐','🌟','☄️','🪐','🌍'],
  ['🎸','🎹','🎺','🎻','🥁','🎷','🪕','🎤'],
  ['🌸','🌺','🌻','🌹','🌷','💐','🌼','🪷'],
];
var memLevel=0;
function buildMemory(lvl){
  memLevel=(lvl||0);
  var gc=document.getElementById('game-content');
  var set=MEM_SETS[memLevel%MEM_SETS.length];
  var cards=[...set,...set].sort(()=>Math.random()-.5);
  var flipped=[],matched=0,locked=false,moves=0,timer=0,tiv;
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Level</span><span class="ival">'+(memLevel+1)+'</span></div>'+
    '<div class="ibox"><span class="ilabel">Moves</span><span class="ival" id="mem-mv">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Time</span><span class="ival" id="mem-tm">0s</span></div>'+
    '<div class="ibox"><span class="ilabel">Pairs</span><span class="ival" id="mem-pr">0/8</span></div>'+
    '</div>'+
    '<div id="mem-grid" style="display:grid;grid-template-columns:repeat(4,72px);gap:8px;"></div>';
  tiv=setInterval(function(){timer++;var el=document.getElementById('mem-tm');if(el)el.textContent=timer+'s';},1000);
  reg(function(){clearInterval(tiv);});
  var grid=document.getElementById('mem-grid');
  cards.forEach(function(emoji,i){
    var card=document.createElement('div');
    card.style.cssText='width:72px;height:72px;border-radius:12px;cursor:pointer;border:2px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;font-size:0;transition:all .3s;user-select:none;';
    card.dataset.idx=i; card.dataset.emoji=emoji;
    card.onclick=function(){
      if(locked||card.dataset.done||flipped.includes(card))return;
      card.textContent=emoji; card.style.fontSize='1.9rem'; card.style.background='rgba(16,185,129,.1)'; card.style.borderColor='rgba(16,185,129,.3)';
      flipped.push(card);
      if(flipped.length===2){
        moves++;var el=document.getElementById('mem-mv');if(el)el.textContent=moves;
        locked=true;
        if(flipped[0].dataset.emoji===flipped[1].dataset.emoji){
          flipped.forEach(function(c){c.dataset.done='1';c.style.opacity='.5';c.style.cursor='default';});
          matched++;var pr=document.getElementById('mem-pr');if(pr)pr.textContent=matched+'/8';
          flipped=[];locked=false;
          if(matched===8){
            clearInterval(tiv);
            setTimeout(function(){
              var gc2=document.getElementById('game-content');if(!gc2)return;
              gc2.innerHTML='<div style="text-align:center;padding:32px;">'
                +'<div style="font-size:3rem;margin-bottom:12px;">🎉</div>'
                +'<div style="font-size:1.4rem;font-weight:900;color:#10b981;margin-bottom:6px;">Level '+(memLevel+1)+' Complete!</div>'
                +'<div style="color:#94a3b8;margin-bottom:20px;">'+moves+' moves · '+timer+'s</div>'
                +'<button class="btn btn-primary" onclick="buildMemory('+(memLevel+1)+')">Next Level →</button> '
                +'<button class="btn btn-ghost" onclick="buildMemory(0)">Restart</button>'
                +'</div>';
            },600);
          }
        } else {
          setTimeout(function(){
            flipped.forEach(function(c){c.textContent='';c.style.fontSize='0';c.style.background='rgba(255,255,255,.05)';c.style.borderColor='rgba(255,255,255,.1)';});
            flipped=[];locked=false;
          },900);
        }
      }
    };
    grid.appendChild(card);
  });
}

// ═══════════ TRAFFIC ESCAPE ═══════════
function buildTraffic(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Distance</span><span class="ival" id="te-dist">0m</span></div>'+
    '<div class="ibox"><span class="ilabel">Lives</span><span class="ival" id="te-li">❤❤❤</span></div>'+
    '<div class="ibox"><span class="ilabel">Speed</span><span class="ival" id="te-spd">1x</span></div>'+
    '</div>'+
    '<canvas id="te-cv" width="300" height="420" style="background:#1a1a2e;border:1px solid rgba(99,102,241,.25);border-radius:8px;display:block;"></canvas>'+
    '<div style="margin-top:12px;display:flex;gap:10px;align-items:center;">'+
    '<button class="btn btn-primary btn-sm" id="te-btn" onclick="teStart()">▶ Start</button>'+
    '<span style="font-size:12px;color:#64748b;">← → to dodge</span>'+
    '</div>';
}
function teStart(){
  var cv=document.getElementById('te-cv');if(!cv)return;
  var ctx=cv.getContext('2d');
  var W=300,H=420,LANES=3,LW=W/LANES;
  var player={lane:1,x:LW*1+LW/2,y:H-70,w:44,h:60};
  var cars=[],dist=0,lives=3,running=true,spd=2,frame=0;
  var carColors=['#ef4444','#f59e0b','#3b82f6','#10b981','#a855f7'];
  document.getElementById('te-btn').textContent='⏹ Stop';
  document.getElementById('te-btn').onclick=function(){running=false;document.getElementById('te-btn').textContent='🔄 Restart';document.getElementById('te-btn').onclick=teStart;};
  function kh(e){if(!running)return;if(e.key==='ArrowLeft'&&player.lane>0){player.lane--;player.x=LW*player.lane+LW/2;}if(e.key==='ArrowRight'&&player.lane<2){player.lane++;player.x=LW*player.lane+LW/2;}}
  document.addEventListener('keydown',kh);
  reg(function(){running=false;document.removeEventListener('keydown',kh);cancelAnimationFrame(raf);});
  var raf;
  function draw(){
    if(!running)return;
    frame++;dist++;
    if(dist%200===0){spd=Math.min(7,spd+0.5);document.getElementById('te-spd').textContent=spd.toFixed(1)+'x';}
    if(dist%100===0)document.getElementById('te-dist').textContent=dist+'m';
    if(frame%Math.max(25,60-spd*5)===0){var lane=Math.floor(Math.random()*3);cars.push({x:LW*lane+LW/2,y:-70,lane:lane,color:carColors[Math.floor(Math.random()*5)],w:40,h:60});}
    ctx.fillStyle='#1a1a2e';ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='rgba(255,255,255,.07)';ctx.lineWidth=2;ctx.setLineDash([20,15]);
    for(var i=1;i<LANES;i++){ctx.beginPath();ctx.moveTo(i*LW,0);ctx.lineTo(i*LW,H);ctx.stroke();}
    ctx.setLineDash([]);
    cars=cars.filter(function(car){
      car.y+=spd*2;
      ctx.fillStyle=car.color;ctx.beginPath();ctx.roundRect(car.x-car.w/2,car.y,car.w,car.h,6);ctx.fill();
      ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(car.x-car.w/2+4,car.y+8,car.w-8,12);ctx.fillRect(car.x-car.w/2+4,car.y+car.h-20,car.w-8,12);
      ctx.fillStyle='#fbbf24';ctx.fillRect(car.x-car.w/2+2,car.y+2,8,6);ctx.fillRect(car.x+car.w/2-10,car.y+2,8,6);
      if(Math.abs(car.x-player.x)<(car.w+player.w)/2-8&&Math.abs(car.y+car.h/2-(player.y+player.h/2))<(car.h+player.h)/2-10){
        lives--;document.getElementById('te-li').textContent='❤'.repeat(Math.max(0,lives))+'🖤'.repeat(Math.max(0,3-lives));
        car.y=-200;
        if(lives<=0){running=false;ctx.fillStyle='rgba(0,0,0,.85)';ctx.fillRect(0,0,W,H);ctx.fillStyle='#f472b6';ctx.font='bold 22px monospace';ctx.textAlign='center';ctx.fillText('GAME OVER',W/2,H/2-8);ctx.fillStyle='#94a3b8';ctx.font='13px monospace';ctx.fillText('Distance: '+dist+'m',W/2,H/2+18);document.getElementById('te-btn').textContent='🔄 Play Again';document.getElementById('te-btn').onclick=teStart;return false;}
      }
      return car.y<H+80;
    });
    ctx.fillStyle='#6366f1';ctx.beginPath();ctx.roundRect(player.x-player.w/2,player.y,player.w,player.h,6);ctx.fill();
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(player.x-player.w/2+4,player.y+8,player.w-8,12);ctx.fillRect(player.x-player.w/2+4,player.y+player.h-20,player.w-8,12);
    ctx.fillStyle='#e2e8f0';ctx.fillRect(player.x-player.w/2+2,player.y+player.h-8,8,6);ctx.fillRect(player.x+player.w/2-10,player.y+player.h-8,8,6);
    raf=requestAnimationFrame(draw);
  }
  draw();
}


// ═══════════ CANDY CRUSH (Match-3) ═══════════
var CANDY_COLORS = ['🍬','🍭','🍫','🍡','🍩','🍪'];
var ccGrid, ccScore, ccMoves, ccSelected, ccLevel, CC_ROWS=8, CC_COLS=8;

function buildCandyCrush(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="cc-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Level</span><span class="ival" id="cc-lv">1</span></div>'+
    '<div class="ibox"><span class="ilabel">Moves</span><span class="ival" id="cc-mv">20</span></div>'+
    '<div class="ibox"><span class="ilabel">Target</span><span class="ival" id="cc-tg">500</span></div>'+
    '</div>'+
    '<div style="font-size:11px;color:#94a3b8;margin-bottom:8px;">Click a candy, then click an adjacent candy to swap! Match 3+ to crush!</div>'+
    '<div id="cc-board" style="display:inline-grid;grid-template-columns:repeat(8,44px);gap:3px;background:#1e0a3c;padding:8px;border-radius:12px;border:2px solid rgba(236,72,153,.3);"></div>'+
    '<div id="cc-msg" style="margin-top:10px;font-size:13px;color:#64748b;min-height:22px;"></div>'+
    '<button class="btn btn-ghost btn-sm" onclick="buildCandyCrush()" style="margin-top:8px;">🔄 New Game</button>';

  ccScore=0; ccMoves=20; ccLevel=1; ccSelected=null;
  ccGrid=[];
  for(var r=0;r<CC_ROWS;r++){ccGrid.push([]);for(var c=0;c<CC_COLS;c++)ccGrid[r].push(CANDY_COLORS[Math.floor(Math.random()*CANDY_COLORS.length)]);}
  // Clear initial matches
  for(var i=0;i<10;i++) ccBreakInitialMatches();
  ccRender();
}

function ccBreakInitialMatches(){
  for(var r=0;r<CC_ROWS;r++){
    for(var c=0;c<CC_COLS;c++){
      if(c>=2&&ccGrid[r][c]===ccGrid[r][c-1]&&ccGrid[r][c]===ccGrid[r][c-2])
        ccGrid[r][c]=CANDY_COLORS[(CANDY_COLORS.indexOf(ccGrid[r][c])+1)%CANDY_COLORS.length];
      if(r>=2&&ccGrid[r][c]===ccGrid[r-1][c]&&ccGrid[r][c]===ccGrid[r-2][c])
        ccGrid[r][c]=CANDY_COLORS[(CANDY_COLORS.indexOf(ccGrid[r][c])+2)%CANDY_COLORS.length];
    }
  }
}

function ccRender(){
  var board=document.getElementById('cc-board');if(!board)return;
  board.innerHTML='';
  for(var r=0;r<CC_ROWS;r++){
    for(var c=0;c<CC_COLS;c++){
      (function(rr,cc2){
        var cell=document.createElement('div');
        var isSel=ccSelected&&ccSelected.r===rr&&ccSelected.c===cc2;
        cell.style.cssText='width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;cursor:pointer;border:2.5px solid '+(isSel?'#fff':'rgba(255,255,255,.1)')+';background:'+(isSel?'rgba(255,255,255,.25)':'rgba(255,255,255,.07)')+';transition:all .15s;user-select:none;transform:'+(isSel?'scale(1.15)':'scale(1)')+';box-shadow:'+(isSel?'0 0 12px rgba(255,255,255,.5)':'none')+';';
        cell.textContent=ccGrid[rr][cc2];
        cell.onclick=function(){ccCellClick(rr,cc2);};
        board.appendChild(cell);
      })(r,c);
    }
  }
}

function ccCellClick(r,c){
  var msg=document.getElementById('cc-msg');
  if(!ccSelected){
    ccSelected={r:r,c:c};ccRender();
    if(msg)msg.textContent='Selected '+ccGrid[r][c]+' — now click an adjacent candy to swap!';
    return;
  }
  // Check adjacency
  var dr=Math.abs(r-ccSelected.r),dc=Math.abs(c-ccSelected.c);
  if((dr===1&&dc===0)||(dr===0&&dc===1)){
    // Swap
    var tmp=ccGrid[r][c];ccGrid[r][c]=ccGrid[ccSelected.r][ccSelected.c];ccGrid[ccSelected.r][ccSelected.c]=tmp;
    var matches=ccFindMatches();
    if(matches.length===0){
      // Swap back
      tmp=ccGrid[r][c];ccGrid[r][c]=ccGrid[ccSelected.r][ccSelected.c];ccGrid[ccSelected.r][ccSelected.c]=tmp;
      if(msg)msg.innerHTML='<span style="color:#f87171;">❌ No match! Try another swap.</span>';
    } else {
      ccMoves--;
      var movEl=document.getElementById('cc-mv');if(movEl)movEl.textContent=ccMoves;
      ccCrushMatches(matches);
      if(msg)msg.innerHTML='<span style="color:#10b981;">💥 Match! Keep going!</span>';
    }
    ccSelected=null;ccRender();
    // Check game state
    setTimeout(ccCheckState,200);
  } else if(r===ccSelected.r&&c===ccSelected.c){
    ccSelected=null;ccRender();if(msg)msg.textContent='';
  } else {
    ccSelected={r:r,c:c};ccRender();
    if(msg)msg.textContent='Selected '+ccGrid[r][c]+' — click adjacent candy!';
  }
}

function ccFindMatches(){
  var matches=[];
  // Horizontal
  for(var r=0;r<CC_ROWS;r++){
    for(var c=0;c<CC_COLS-2;c++){
      if(ccGrid[r][c]&&ccGrid[r][c]===ccGrid[r][c+1]&&ccGrid[r][c]===ccGrid[r][c+2]){
        var run=[{r:r,c:c},{r:r,c:c+1},{r:r,c:c+2}];
        var cc2=c+3;while(cc2<CC_COLS&&ccGrid[r][cc2]===ccGrid[r][c])run.push({r:r,c:cc2++});
        matches.push(...run);c=cc2-1;
      }
    }
  }
  // Vertical
  for(var c=0;c<CC_COLS;c++){
    for(var r=0;r<CC_ROWS-2;r++){
      if(ccGrid[r][c]&&ccGrid[r][c]===ccGrid[r+1][c]&&ccGrid[r][c]===ccGrid[r+2][c]){
        var run=[{r:r,c:c},{r:r+1,c:c},{r:r+2,c:c}];
        var rr=r+3;while(rr<CC_ROWS&&ccGrid[rr][c]===ccGrid[r][c])run.push({r:rr++,c:c});
        matches.push(...run);r=rr-1;
      }
    }
  }
  // Deduplicate
  var seen=new Set();
  return matches.filter(function(m){var k=m.r+','+m.c;if(seen.has(k))return false;seen.add(k);return true;});
}

function ccCrushMatches(matches){
  var pts=matches.length*10;
  if(matches.length>=5)pts*=2;
  ccScore+=pts;
  var scEl=document.getElementById('cc-sc');if(scEl)scEl.textContent=ccScore;
  matches.forEach(function(m){ccGrid[m.r][m.c]=null;});
  // Drop candies
  for(var c=0;c<CC_COLS;c++){
    var col=[];for(var r=CC_ROWS-1;r>=0;r--)if(ccGrid[r][c]!==null)col.push(ccGrid[r][c]);
    while(col.length<CC_ROWS)col.push(CANDY_COLORS[Math.floor(Math.random()*CANDY_COLORS.length)]);
    col.reverse();for(var r=0;r<CC_ROWS;r++)ccGrid[r][c]=col[r];
  }
  // Chain matches
  var more=ccFindMatches();
  if(more.length>0)setTimeout(function(){ccCrushMatches(more);ccRender();},300);
}

function ccCheckState(){
  var tg=ccLevel*500;
  var tgEl=document.getElementById('cc-tg');if(tgEl)tgEl.textContent=tg;
  var msg=document.getElementById('cc-msg');
  if(ccScore>=tg){
    ccLevel++;
    var lvEl=document.getElementById('cc-lv');if(lvEl)lvEl.textContent=ccLevel;
    ccMoves+=15;var mvEl=document.getElementById('cc-mv');if(mvEl)mvEl.textContent=ccMoves;
    if(msg)msg.innerHTML='<span style="color:#10b981;font-weight:700;">🎉 Level '+ccLevel+'! +15 bonus moves!</span>';
    var newTg=ccLevel*500;if(tgEl)tgEl.textContent=newTg;
  } else if(ccMoves<=0){
    if(msg)msg.innerHTML='<span style="color:#f87171;font-weight:700;">😔 Out of moves! Score: '+ccScore+'</span>';
    setTimeout(function(){
      var gc2=document.getElementById('game-content');if(!gc2)return;
      gc2.innerHTML='<div style="text-align:center;padding:32px;">'+
        '<div style="font-size:3rem;margin-bottom:12px;">🍬</div>'+
        '<div style="font-size:1.4rem;font-weight:900;color:#ec4899;margin-bottom:6px;">Game Over!</div>'+
        '<div style="color:#94a3b8;margin-bottom:20px;">Final Score: '+ccScore+' | Level: '+ccLevel+'</div>'+
        '<button class="btn btn-primary" onclick="buildCandyCrush()">Play Again</button></div>';
    },1500);
  }
}

// ═══════════ SUBWAY SURFERS (Endless Runner) ═══════════
function buildSubwaySurfers(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Distance</span><span class="ival" id="ss-dist">0m</span></div>'+
    '<div class="ibox"><span class="ilabel">Coins</span><span class="ival" id="ss-coins">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Lives</span><span class="ival" id="ss-lives">❤❤❤</span></div>'+
    '<div class="ibox"><span class="ilabel">Speed</span><span class="ival" id="ss-spd">1x</span></div>'+
    '</div>'+
    '<canvas id="ss-cv" width="380" height="460" style="background:#1a0a2e;border:2px solid rgba(99,102,241,.4);border-radius:12px;display:block;"></canvas>'+
    '<div style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">'+
    '<button class="btn btn-primary btn-sm" id="ss-btn" onclick="ssStart()">▶ Start</button>'+
    '<span style="font-size:12px;color:#64748b;">← → to switch lanes | ↑ to jump | ↓ to slide</span>'+
    '</div>';
}

function ssStart(){
  var cv=document.getElementById('ss-cv');if(!cv)return;
  var ctx=cv.getContext('2d');
  var W=380,H=460;
  var LANES=3,LW=W/LANES;
  var player={lane:1,x:LW*1+LW/2,y:H-100,w:36,h:56,vy:0,jumping:false,sliding:false,slideTimer:0,invincible:0};
  var obstacles=[],coins=[],dist=0,coinCount=0,lives=3,spd=3,frame=0,running=true;
  var TRAIN_COLORS=['#ef4444','#3b82f6','#10b981','#f59e0b'];
  var bgOffset=0;

  document.getElementById('ss-btn').textContent='⏹ Stop';
  document.getElementById('ss-btn').onclick=function(){running=false;document.getElementById('ss-btn').textContent='🔄 Restart';document.getElementById('ss-btn').onclick=ssStart;};

  function kh(e){
    if(!running)return;
    if(e.key==='ArrowLeft'&&player.lane>0){player.lane--;player.x=LW*player.lane+LW/2;}
    if(e.key==='ArrowRight'&&player.lane<2){player.lane++;player.x=LW*player.lane+LW/2;}
    if((e.key==='ArrowUp'||e.key===' ')&&!player.jumping&&!player.sliding){player.vy=-14;player.jumping=true;}
    if(e.key==='ArrowDown'&&!player.jumping){player.sliding=true;player.slideTimer=30;player.h=30;}
  }
  document.addEventListener('keydown',kh);
  // Touch swipe
  var tx0=0,ty0=0;
  function ts(e){tx0=e.touches[0].clientX;ty0=e.touches[0].clientY;}
  function te(e){
    if(!running)return;
    var dx=e.changedTouches[0].clientX-tx0,dy=e.changedTouches[0].clientY-ty0;
    if(Math.abs(dx)>Math.abs(dy)){
      if(dx<-30&&player.lane>0){player.lane--;player.x=LW*player.lane+LW/2;}
      if(dx>30&&player.lane<2){player.lane++;player.x=LW*player.lane+LW/2;}
    } else {
      if(dy<-30&&!player.jumping&&!player.sliding){player.vy=-14;player.jumping=true;}
      if(dy>30&&!player.jumping){player.sliding=true;player.slideTimer=30;player.h=30;}
    }
  }
  document.addEventListener('touchstart',ts,{passive:true});
  document.addEventListener('touchend',te,{passive:true});
  reg(function(){running=false;document.removeEventListener('keydown',kh);document.removeEventListener('touchstart',ts);document.removeEventListener('touchend',te);cancelAnimationFrame(raf);});

  var groundY=H-80;
  var raf;
  function draw(){
    if(!running)return;
    frame++;dist++;
    if(dist%300===0){spd=Math.min(10,spd+0.5);var sp=document.getElementById('ss-spd');if(sp)sp.textContent=spd.toFixed(1)+'x';}
    if(dist%60===0){var dd=document.getElementById('ss-dist');if(dd)dd.textContent=dist+'m';}

    // Background
    ctx.fillStyle='#1a0a2e';ctx.fillRect(0,0,W,H);
    // Animated track
    bgOffset=(bgOffset+spd)%(80);
    ctx.strokeStyle='rgba(255,255,255,.06)';ctx.lineWidth=2;
    for(var i=-1;i<LANES;i++){ctx.beginPath();ctx.moveTo((i+1)*LW,0);ctx.lineTo((i+1)*LW,H);ctx.stroke();}
    // Ground
    ctx.fillStyle='#2a1a5e';ctx.fillRect(0,groundY+55,W,H);
    // Track lines
    ctx.strokeStyle='rgba(255,255,255,.15)';ctx.lineWidth=3;ctx.setLineDash([30,20]);
    for(var l=1;l<LANES;l++){ctx.beginPath();ctx.moveTo(l*LW,0);ctx.lineTo(l*LW,groundY+55);ctx.stroke();}
    ctx.setLineDash([]);

    // Spawn obstacles
    if(frame%Math.max(30,80-spd*6)===0){
      var lane=Math.floor(Math.random()*3);
      var type=Math.random()<0.3?'barrier':'train';
      obstacles.push({x:LW*lane+LW/2,y:-60,lane:lane,type:type,color:TRAIN_COLORS[Math.floor(Math.random()*4)],w:type==='train'?44:38,h:type==='train'?80:36});
    }
    // Spawn coins
    if(frame%40===0){
      var lane=Math.floor(Math.random()*3);
      coins.push({x:LW*lane+LW/2,y:-20,lane:lane});
    }

    // Update & draw obstacles
    obstacles=obstacles.filter(function(ob){
      ob.y+=spd*2.5;
      if(ob.type==='train'){
        // Train body
        ctx.fillStyle=ob.color;ctx.beginPath();ctx.roundRect(ob.x-ob.w/2,ob.y,ob.w,ob.h,6);ctx.fill();
        ctx.fillStyle='rgba(0,0,0,.4)';ctx.fillRect(ob.x-ob.w/2+4,ob.y+6,ob.w-8,16);ctx.fillRect(ob.x-ob.w/2+4,ob.y+ob.h-22,ob.w-8,16);
        ctx.fillStyle='#ffd700';ctx.fillRect(ob.x-8,ob.y-4,16,8);
      } else {
        // Barrier
        ctx.fillStyle='#f59e0b';ctx.fillRect(ob.x-ob.w/2,ob.y+10,ob.w,ob.h-10);
        ctx.fillStyle='#dc2626';ctx.fillRect(ob.x-ob.w/2,ob.y,ob.w,12);
        ctx.strokeStyle='#fff';ctx.lineWidth=2;
        for(var i=0;i<3;i++){ctx.beginPath();ctx.moveTo(ob.x-ob.w/2+i*(ob.w/2),ob.y);ctx.lineTo(ob.x-ob.w/2+i*(ob.w/2)+ob.w/4,ob.y+14);ctx.stroke();}
      }
      // Collision
      var ph=player.h;
      if(player.invincible<=0&&Math.abs(ob.x-player.x)<(ob.w+player.w)/2-6&&ob.y+ob.h>player.y&&ob.y<player.y+ph-4){
        lives--;player.invincible=80;
        var ll=document.getElementById('ss-lives');if(ll)ll.textContent='❤'.repeat(Math.max(0,lives))+'🖤'.repeat(3-Math.max(0,lives));
        if(lives<=0){
          running=false;
          ctx.fillStyle='rgba(0,0,0,.85)';ctx.fillRect(0,0,W,H);
          ctx.fillStyle='#818cf8';ctx.font='bold 26px monospace';ctx.textAlign='center';ctx.fillText('GAME OVER',W/2,H/2-20);
          ctx.fillStyle='#94a3b8';ctx.font='14px monospace';ctx.fillText('Distance: '+dist+'m · Coins: '+coinCount,W/2,H/2+10);
          document.getElementById('ss-btn').textContent='🔄 Play Again';document.getElementById('ss-btn').onclick=ssStart;
          return false;
        }
        return false;
      }
      return ob.y<H+100;
    });

    // Update & draw coins
    coins=coins.filter(function(co){
      co.y+=spd*2;
      ctx.font='22px serif';ctx.textAlign='center';ctx.fillText('🪙',co.x,co.y+11);
      if(Math.abs(co.x-player.x)<28&&Math.abs(co.y-player.y)<32){
        coinCount++;var cl=document.getElementById('ss-coins');if(cl)cl.textContent=coinCount;
        return false;
      }
      return co.y<H+30;
    });

    // Player physics
    if(player.jumping){player.vy+=0.7;player.y+=player.vy;if(player.y>=groundY-player.h){player.y=groundY-player.h;player.jumping=false;player.vy=0;}}
    else{player.y=groundY-player.h;}
    if(player.sliding){player.slideTimer--;if(player.slideTimer<=0){player.sliding=false;player.h=56;}}
    if(player.invincible>0)player.invincible--;

    // Draw player (character)
    var alpha=player.invincible>0?(Math.floor(frame/5)%2===0?0.3:1):1;
    ctx.globalAlpha=alpha;
    // Body
    ctx.fillStyle='#6366f1';ctx.beginPath();ctx.roundRect(player.x-player.w/2,player.y+(player.sliding?26:10),player.w,player.h-(player.sliding?26:10),8);ctx.fill();
    // Head
    if(!player.sliding){ctx.fillStyle='#fde68a';ctx.beginPath();ctx.arc(player.x,player.y+8,12,0,Math.PI*2);ctx.fill();}
    // Legs (running animation)
    var legAnim=Math.sin(frame*0.3)*8;
    ctx.fillStyle='#4f46e5';
    ctx.fillRect(player.x-12,player.y+player.h-16,10,18+legAnim);
    ctx.fillRect(player.x+2,player.y+player.h-16,10,18-legAnim);
    ctx.globalAlpha=1;

    // HUD
    ctx.fillStyle='rgba(0,0,0,.4)';ctx.fillRect(0,0,W,28);
    ctx.fillStyle='#e2e8f0';ctx.font='bold 12px monospace';ctx.textAlign='left';ctx.fillText('🏃 '+dist+'m',8,18);
    ctx.textAlign='center';ctx.fillText('🪙 '+coinCount,W/2,18);
    ctx.textAlign='right';ctx.fillText(spd.toFixed(1)+'x 💨',W-8,18);

    raf=requestAnimationFrame(draw);
  }
  player.y=groundY-player.h;
  draw();
}


// ═══════════ TETRIS ═══════════
function buildTetris(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="tt-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Level</span><span class="ival" id="tt-lv">1</span></div>'+
    '<div class="ibox"><span class="ilabel">Lines</span><span class="ival" id="tt-ln">0</span></div>'+
    '</div>'+
    '<div style="display:flex;gap:12px;align-items:flex-start;">'+
    '<canvas id="tt-cv" width="200" height="400" style="background:#0d1117;border:1px solid rgba(168,85,247,.25);border-radius:8px;"></canvas>'+
    '<div style="display:flex;flex-direction:column;gap:8px;">'+
    '<div style="font-size:11px;color:#64748b;font-weight:700;text-transform:uppercase;">Next</div>'+
    '<canvas id="tt-nx" width="80" height="80" style="background:#0d1117;border:1px solid rgba(255,255,255,.08);border-radius:6px;"></canvas>'+
    '</div>'+
    '</div>'+
    '<div style="margin-top:10px;display:flex;gap:10px;align-items:center;">'+
    '<button class="btn btn-primary btn-sm" id="tt-btn" onclick="ttStart()">▶ Start</button>'+
    '<span style="font-size:11px;color:#64748b;">← → ↓ Drop · ↑/Z Rotate</span>'+
    '</div>';
}
var TT_PIECES=[
  {s:[[1,1,1,1]],c:'#06b6d4'},
  {s:[[1,1],[1,1]],c:'#f59e0b'},
  {s:[[0,1,0],[1,1,1]],c:'#a855f7'},
  {s:[[1,0],[1,0],[1,1]],c:'#f97316'},
  {s:[[0,1],[0,1],[1,1]],c:'#3b82f6'},
  {s:[[0,1,1],[1,1,0]],c:'#10b981'},
  {s:[[1,1,0],[0,1,1]],c:'#ef4444'},
];
function ttStart(){
  var cv=document.getElementById('tt-cv'),nx=document.getElementById('tt-nx');if(!cv)return;
  var ctx=cv.getContext('2d'),nxCtx=nx.getContext('2d');
  var C=10,R=20,BS=20;
  var board=Array.from({length:R},()=>Array(C).fill(0));
  var score=0,lines=0,level=1,running=true;
  var curPiece,curX,curY,nextPiece;
  document.getElementById('tt-btn').textContent='⏹ Stop';
  document.getElementById('tt-btn').onclick=function(){running=false;clearInterval(iv);document.getElementById('tt-btn').textContent='▶ Restart';document.getElementById('tt-btn').onclick=ttStart;};
  function randPiece(){return JSON.parse(JSON.stringify(TT_PIECES[Math.floor(Math.random()*TT_PIECES.length)]));}
  function spawn(){curPiece=nextPiece||randPiece();nextPiece=randPiece();curX=Math.floor((C-curPiece.s[0].length)/2);curY=0;if(!ttValid(curPiece.s,curX,curY)){running=false;clearInterval(iv);ctx.fillStyle='rgba(0,0,0,.8)';ctx.fillRect(0,0,200,400);ctx.fillStyle='#c084fc';ctx.font='bold 20px monospace';ctx.textAlign='center';ctx.fillText('GAME OVER',100,180);ctx.fillStyle='#94a3b8';ctx.font='14px monospace';ctx.fillText('Score: '+score,100,210);document.getElementById('tt-btn').textContent='🔄 Play Again';document.getElementById('tt-btn').onclick=ttStart;return;}drawNext();}
  function ttValid(shape,ox,oy){for(var r=0;r<shape.length;r++)for(var c=0;c<shape[r].length;c++){if(shape[r][c]){var nx2=ox+c,ny=oy+r;if(nx2<0||nx2>=C||ny>=R)return false;if(ny>=0&&board[ny][nx2])return false;}}return true;}
  function rotate(s){var rows=s.length,cols=s[0].length,out=Array.from({length:cols},()=>Array(rows).fill(0));for(var r=0;r<rows;r++)for(var c=0;c<cols;c++)out[c][rows-1-r]=s[r][c];return out;}
  function lock(){for(var r=0;r<curPiece.s.length;r++)for(var c=0;c<curPiece.s[r].length;c++)if(curPiece.s[r][c])board[curY+r][curX+c]=curPiece.c;var cleared=0;for(var r=R-1;r>=0;r--){if(board[r].every(c=>c)){board.splice(r,1);board.unshift(Array(C).fill(0));cleared++;r++;}}if(cleared){lines+=cleared;score+=cleared===4?800*level:cleared===3?500*level:cleared===2?300*level:100*level;level=Math.floor(lines/10)+1;document.getElementById('tt-sc').textContent=score;document.getElementById('tt-lv').textContent=level;document.getElementById('tt-ln').textContent=lines;clearInterval(iv);iv=setInterval(drop,Math.max(80,500-level*40));}spawn();}
  function drop(){if(!running)return;if(ttValid(curPiece.s,curX,curY+1))curY++;else lock();render();}
  function render(){
    ctx.fillStyle='#0d1117';ctx.fillRect(0,0,200,400);
    // Grid lines
    ctx.strokeStyle='rgba(255,255,255,.03)';ctx.lineWidth=1;
    for(var i=0;i<=C;i++){ctx.beginPath();ctx.moveTo(i*BS,0);ctx.lineTo(i*BS,400);ctx.stroke();}
    for(var j=0;j<=R;j++){ctx.beginPath();ctx.moveTo(0,j*BS);ctx.lineTo(200,j*BS);ctx.stroke();}
    // Board
    for(var r=0;r<R;r++)for(var c=0;c<C;c++){if(board[r][c]){ctx.fillStyle=board[r][c];ctx.fillRect(c*BS+1,r*BS+1,BS-2,BS-2);ctx.fillStyle='rgba(255,255,255,.15)';ctx.fillRect(c*BS+1,r*BS+1,BS-2,4);}}
    // Ghost piece
    var gy=curY;while(ttValid(curPiece.s,curX,gy+1))gy++;
    for(var r=0;r<curPiece.s.length;r++)for(var c=0;c<curPiece.s[r].length;c++)if(curPiece.s[r][c]){ctx.fillStyle='rgba(255,255,255,.08)';ctx.fillRect((curX+c)*BS+1,(gy+r)*BS+1,BS-2,BS-2);}
    // Current piece
    for(var r=0;r<curPiece.s.length;r++)for(var c=0;c<curPiece.s[r].length;c++)if(curPiece.s[r][c]){ctx.fillStyle=curPiece.c;ctx.fillRect((curX+c)*BS+1,(curY+r)*BS+1,BS-2,BS-2);ctx.fillStyle='rgba(255,255,255,.25)';ctx.fillRect((curX+c)*BS+1,(curY+r)*BS+1,BS-2,4);}
  }
  function drawNext(){if(!nxCtx||!nextPiece)return;nxCtx.fillStyle='#0d1117';nxCtx.fillRect(0,0,80,80);var s=nextPiece.s,ox=(4-s[0].length)/2*16,oy=(4-s.length)/2*16;for(var r=0;r<s.length;r++)for(var c=0;c<s[r].length;c++)if(s[r][c]){nxCtx.fillStyle=nextPiece.c;nxCtx.fillRect(ox+c*16+1,oy+r*16+1,14,14);}}
  function kh(e){if(!running||activeGame!=='tetris')return;if(e.key==='ArrowLeft'){if(ttValid(curPiece.s,curX-1,curY))curX--;render();}else if(e.key==='ArrowRight'){if(ttValid(curPiece.s,curX+1,curY))curX++;render();}else if(e.key==='ArrowDown'){drop();}else if(e.key==='ArrowUp'||e.key==='z'||e.key==='Z'){var rot=rotate(curPiece.s);if(ttValid(rot,curX,curY))curPiece.s=rot;render();}else if(e.key===' '){while(ttValid(curPiece.s,curX,curY+1))curY++;lock();render();e.preventDefault();}}
  document.addEventListener('keydown',kh);
  var iv=setInterval(drop,500);
  reg(function(){clearInterval(iv);document.removeEventListener('keydown',kh);running=false;});
  spawn();render();
}

// ═══════════ BREAKOUT ═══════════
function buildBreakout(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="bo-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Level</span><span class="ival" id="bo-lv">1</span></div>'+
    '<div class="ibox"><span class="ilabel">Lives</span><span class="ival" id="bo-li">❤❤❤</span></div>'+
    '</div>'+
    '<canvas id="bo-cv" width="360" height="400" style="background:#0d1117;border:1px solid rgba(251,146,60,.25);border-radius:8px;cursor:none;"></canvas>'+
    '<div style="margin-top:10px;display:flex;gap:10px;align-items:center;">'+
    '<button class="btn btn-primary btn-sm" id="bo-btn" onclick="boStart()">▶ Start</button>'+
    '<span style="font-size:11px;color:#64748b;">Mouse / ← → to move paddle</span>'+
    '</div>';
}
function boStart(){
  var cv=document.getElementById('bo-cv');if(!cv)return;
  var ctx=cv.getContext('2d');
  var W=360,H=400,ROWS=5,COLS=9,PW=70,PH=10;
  var level=1,score=0,lives=3,running=true;
  var paddle={x:W/2-PW/2,y:H-24,w:PW,h:PH,spd:6};
  var ball={x:W/2,y:H-60,vx:3,vy:-4,r:7};
  var keys={};
  function makeBricks(lv){
    var bricks=[];
    var colors=['#ef4444','#f97316','#f59e0b','#10b981','#3b82f6'];
    for(var r=0;r<ROWS;r++)for(var c=0;c<COLS;c++){
      var hp=lv>=3&&r<2?2:1;
      bricks.push({x:8+c*38,y:50+r*24,w:34,h:18,alive:true,hp:hp,color:colors[r%colors.length]});
    }
    return bricks;
  }
  var bricks=makeBricks(level);
  document.getElementById('bo-btn').textContent='⏹ Stop';
  document.getElementById('bo-btn').onclick=function(){running=false;cancelAnimationFrame(raf);document.getElementById('bo-btn').textContent='▶ Restart';document.getElementById('bo-btn').onclick=boStart;};
  function mm(e){var rect=cv.getBoundingClientRect();paddle.x=Math.min(W-paddle.w,(e.clientX-rect.left)*(W/rect.width)-paddle.w/2);}
  function mt(e){var rect=cv.getBoundingClientRect();paddle.x=Math.min(W-paddle.w,(e.touches[0].clientX-rect.left)*(W/rect.width)-paddle.w/2);}
  cv.addEventListener('mousemove',mm);cv.addEventListener('touchmove',mt,{passive:true});
  function kh(e){keys[e.key]=e.type==='keydown';}
  document.addEventListener('keydown',kh);document.addEventListener('keyup',kh);
  reg(function(){running=false;cancelAnimationFrame(raf);cv.removeEventListener('mousemove',mm);cv.removeEventListener('touchmove',mt);document.removeEventListener('keydown',kh);document.removeEventListener('keyup',kh);});
  var raf;
  function draw(){
    if(!running)return;
    if(keys['ArrowLeft']){paddle.x=Math.max(0,paddle.x-paddle.spd);}
    if(keys['ArrowRight']){paddle.x=Math.min(W-paddle.w,paddle.x+paddle.spd);}
    ctx.fillStyle='#0d1117';ctx.fillRect(0,0,W,H);
    // Bricks
    var alive=0;
    bricks.forEach(function(b){
      if(!b.alive)return;alive++;
      var alpha=b.hp>1?1:0.9;
      ctx.fillStyle=b.color;ctx.globalAlpha=alpha;
      ctx.beginPath();ctx.roundRect(b.x,b.y,b.w,b.h,3);ctx.fill();
      if(b.hp>1){ctx.strokeStyle='rgba(255,255,255,.5)';ctx.lineWidth=2;ctx.stroke();}
      ctx.globalAlpha=1;
      ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(b.x+2,b.y+2,b.w-4,4);
    });
    if(alive===0){
      level++;document.getElementById('bo-lv').textContent=level;
      bricks=makeBricks(level);
      ball={x:W/2,y:H-60,vx:3+level*0.4,vy:-(4+level*0.3),r:7};
      paddle.w=Math.max(45,PW-level*4);
    }
    // Ball physics
    ball.x+=ball.vx;ball.y+=ball.vy;
    if(ball.x-ball.r<0){ball.x=ball.r;ball.vx=Math.abs(ball.vx);}
    if(ball.x+ball.r>W){ball.x=W-ball.r;ball.vx=-Math.abs(ball.vx);}
    if(ball.y-ball.r<0){ball.y=ball.r;ball.vy=Math.abs(ball.vy);}
    // Paddle collision
    if(ball.y+ball.r>paddle.y&&ball.y+ball.r<paddle.y+paddle.h+8&&ball.x>paddle.x&&ball.x<paddle.x+paddle.w&&ball.vy>0){
      var rel=(ball.x-(paddle.x+paddle.w/2))/(paddle.w/2);
      ball.vx=rel*5;ball.vy=-Math.abs(ball.vy);
    }
    // Brick collision
    bricks.forEach(function(b){
      if(!b.alive)return;
      if(ball.x>b.x&&ball.x<b.x+b.w&&ball.y-ball.r<b.y+b.h&&ball.y+ball.r>b.y){
        b.hp--;if(b.hp<=0)b.alive=false;
        score+=b.hp<=0?10:5;document.getElementById('bo-sc').textContent=score;
        ball.vy*=-1;
      }
    });
    // Death
    if(ball.y-ball.r>H){
      lives--;document.getElementById('bo-li').textContent='❤'.repeat(Math.max(0,lives))+'🖤'.repeat(3-Math.max(0,lives));
      ball.x=W/2;ball.y=H-60;ball.vx=3*(Math.random()>.5?1:-1);ball.vy=-4;
      if(lives<=0){running=false;ctx.fillStyle='rgba(0,0,0,.85)';ctx.fillRect(0,0,W,H);ctx.fillStyle='#fb923c';ctx.font='bold 22px monospace';ctx.textAlign='center';ctx.fillText('GAME OVER',W/2,H/2-10);ctx.fillStyle='#94a3b8';ctx.font='14px monospace';ctx.fillText('Score: '+score,W/2,H/2+18);document.getElementById('bo-btn').textContent='🔄 Play Again';document.getElementById('bo-btn').onclick=boStart;return;}
    }
    // Draw paddle
    var pg=ctx.createLinearGradient(paddle.x,paddle.y,paddle.x,paddle.y+paddle.h);
    pg.addColorStop(0,'#fb923c');pg.addColorStop(1,'#ea580c');
    ctx.fillStyle=pg;ctx.beginPath();ctx.roundRect(paddle.x,paddle.y,paddle.w,paddle.h,5);ctx.fill();
    // Draw ball
    var bg=ctx.createRadialGradient(ball.x-2,ball.y-2,1,ball.x,ball.y,ball.r);
    bg.addColorStop(0,'#fef3c7');bg.addColorStop(1,'#f59e0b');
    ctx.beginPath();ctx.arc(ball.x,ball.y,ball.r,0,Math.PI*2);ctx.fillStyle=bg;ctx.fill();
    // Glow
    ctx.shadowColor='#f59e0b';ctx.shadowBlur=12;
    ctx.beginPath();ctx.arc(ball.x,ball.y,ball.r,0,Math.PI*2);ctx.fillStyle='transparent';ctx.strokeStyle='rgba(251,191,36,.4)';ctx.lineWidth=2;ctx.stroke();
    ctx.shadowBlur=0;
    raf=requestAnimationFrame(draw);
  }
  draw();
}

// ═══════════ FLAPPY BIRD ═══════════
function buildFlappy(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Score</span><span class="ival" id="fl-sc">0</span></div>'+
    '<div class="ibox"><span class="ilabel">Best</span><span class="ival" id="fl-best">0</span></div>'+
    '</div>'+
    '<canvas id="fl-cv" width="320" height="420" style="background:linear-gradient(180deg,#1e3a5f 0%,#2d6a4f 100%);border:1px solid rgba(168,85,247,.25);border-radius:12px;cursor:pointer;"></canvas>'+
    '<div style="margin-top:10px;display:flex;gap:10px;align-items:center;">'+
    '<span style="font-size:12px;color:#64748b;">Tap / Space / Click to flap</span>'+
    '</div>';
  flStart();
}
function flStart(){
  var cv=document.getElementById('cv_dummy')||document.getElementById('fl-cv');
  cv=document.getElementById('fl-cv');if(!cv)return;
  var ctx=cv.getContext('2d');
  var W=320,H=420,GV=0.38,JUMP=-7.5,PIPE_W=52,GAP=130,spd=2.2;
  var bird={x:72,y:H/2,vy:0,r:14};
  var pipes=[],score=0,best=parseInt(localStorage&&localStorage.flBest||0)||0,state='idle',frame=0;
  document.getElementById('fl-best').textContent=best;
  // Clouds
  var clouds=[{x:60,y:50,s:1},{x:180,y:90,s:.7},{x:280,y:35,s:.9}];
  // Stars
  var stars=[];for(var i=0;i<30;i++)stars.push({x:Math.random()*W,y:Math.random()*(H*.6),r:Math.random()*1.5});

  function addPipe(){pipes.push({x:W,top:80+Math.random()*(H-GAP-160)});}

  function flap(){
    if(state==='idle'){state='playing';addPipe();return;}
    if(state==='dead'){flStart();return;}
    bird.vy=JUMP;
  }

  var kh=function(e){if(e.code==='Space'){flap();e.preventDefault();}};
  cv.addEventListener('click',flap);
  document.addEventListener('keydown',kh);
  reg(function(){cancelAnimationFrame(raf);cv.removeEventListener('click',flap);document.removeEventListener('keydown',kh);});

  function drawBird(){
    // Body
    var bg=ctx.createRadialGradient(bird.x-3,bird.y-3,2,bird.x,bird.y,bird.r);
    bg.addColorStop(0,'#fde68a');bg.addColorStop(1,'#f59e0b');
    ctx.beginPath();ctx.arc(bird.x,bird.y,bird.r,0,Math.PI*2);ctx.fillStyle=bg;ctx.fill();
    // Wing flap
    var wingY=bird.y+5+Math.sin(frame*.25)*4;
    ctx.beginPath();ctx.ellipse(bird.x-6,wingY,8,5,-.4,0,Math.PI*2);ctx.fillStyle='#f97316';ctx.fill();
    // Eye
    ctx.beginPath();ctx.arc(bird.x+7,bird.y-4,4,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();
    ctx.beginPath();ctx.arc(bird.x+8,bird.y-4,2,0,Math.PI*2);ctx.fillStyle='#1e293b';ctx.fill();
    // Beak
    ctx.beginPath();ctx.moveTo(bird.x+bird.r,bird.y+1);ctx.lineTo(bird.x+bird.r+10,bird.y+4);ctx.lineTo(bird.x+bird.r,bird.y+7);ctx.closePath();ctx.fillStyle='#ea580c';ctx.fill();
    // Tilt based on velocity
    ctx.save();ctx.translate(bird.x,bird.y);ctx.rotate(Math.min(.5,Math.max(-.4,bird.vy*.04)));ctx.restore();
  }

  function drawPipe(p){
    // Top pipe
    var tg=ctx.createLinearGradient(p.x,0,p.x+PIPE_W,0);
    tg.addColorStop(0,'#166534');tg.addColorStop(.5,'#22c55e');tg.addColorStop(1,'#166534');
    ctx.fillStyle=tg;ctx.fillRect(p.x,0,PIPE_W,p.top);
    ctx.fillStyle='#15803d';ctx.fillRect(p.x-6,p.top-28,PIPE_W+12,28);
    ctx.fillStyle='rgba(255,255,255,.1)';ctx.fillRect(p.x+6,0,10,p.top-28);
    // Bottom pipe
    var bot=p.top+GAP;
    ctx.fillStyle=tg;ctx.fillRect(p.x,bot,PIPE_W,H-bot);
    ctx.fillStyle='#15803d';ctx.fillRect(p.x-6,bot,PIPE_W+12,28);
    ctx.fillStyle='rgba(255,255,255,.1)';ctx.fillRect(p.x+6,bot+28,10,H-bot-28);
  }

  var raf;
  function loop(){
    if(!document.getElementById('fl-cv')){return;}
    frame++;
    // BG gradient (day/night based on score)
    var sky=ctx.createLinearGradient(0,0,0,H);
    sky.addColorStop(0,'#0f172a');sky.addColorStop(.6,'#1e3a5f');sky.addColorStop(1,'#2d4a3e');
    ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
    // Stars
    stars.forEach(function(s){ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fillStyle='rgba(255,255,255,.6)';ctx.fill();});
    // Clouds
    clouds.forEach(function(c){
      c.x-=0.4;if(c.x<-100)c.x=W+60;
      ctx.globalAlpha=0.18*c.s;ctx.fillStyle='#fff';
      ctx.beginPath();ctx.arc(c.x,c.y,28*c.s,0,Math.PI*2);ctx.arc(c.x+22*c.s,c.y-8*c.s,20*c.s,0,Math.PI*2);ctx.arc(c.x+40*c.s,c.y,24*c.s,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=1;
    });
    // Ground
    ctx.fillStyle='#4ade80';ctx.fillRect(0,H-24,W,24);
    ctx.fillStyle='#166534';ctx.fillRect(0,H-24,W,6);

    if(state==='idle'){
      drawBird();
      ctx.fillStyle='rgba(168,85,247,.9)';ctx.font='bold 18px monospace';ctx.textAlign='center';
      ctx.fillText('TAP TO START',W/2,H/2-40);
      ctx.fillStyle='rgba(255,255,255,.5)';ctx.font='13px monospace';ctx.fillText('Avoid the pipes!',W/2,H/2-18);
      raf=requestAnimationFrame(loop);return;
    }
    if(state==='playing'){
      bird.vy+=GV;bird.y+=bird.vy;
      // Spawn pipes
      if(frame%Math.floor(95/spd*2)===0)addPipe();
      // Move pipes
      pipes=pipes.filter(function(p){
        p.x-=spd;
        // Score
        if(!p.scored&&p.x+PIPE_W<bird.x){p.scored=true;score++;spd=Math.min(4.5,2.2+score*.07);document.getElementById('fl-sc').textContent=score;}
        // Collision
        if(bird.x+bird.r>p.x&&bird.x-bird.r<p.x+PIPE_W&&(bird.y-bird.r<p.top||bird.y+bird.r>p.top+GAP)){state='dead';}
        return p.x>-PIPE_W;
      });
      if(bird.y+bird.r>H-24||bird.y-bird.r<0)state='dead';
    }
    pipes.forEach(drawPipe);
    drawBird();
    if(state==='dead'){
      if(score>best){best=score;document.getElementById('fl-best').textContent=best;try{localStorage.flBest=best;}catch(ex){}}
      ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillRect(0,0,W,H);
      ctx.fillStyle='#f87171';ctx.font='bold 26px monospace';ctx.textAlign='center';ctx.fillText('GAME OVER',W/2,H/2-30);
      ctx.fillStyle='#fde68a';ctx.font='18px monospace';ctx.fillText('Score: '+score,W/2,H/2+4);
      ctx.fillStyle='#94a3b8';ctx.font='13px monospace';ctx.fillText('Tap or Space to restart',W/2,H/2+30);
      raf=requestAnimationFrame(loop);return;
    }
    // HUD
    ctx.fillStyle='#fff';ctx.font='bold 22px monospace';ctx.textAlign='center';
    ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=3;ctx.strokeText(score,W/2,44);ctx.fillText(score,W/2,44);
    raf=requestAnimationFrame(loop);
  }
  loop();
}

// ═══════════ MINESWEEPER ═══════════
function buildMinesweeper(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Mines</span><span class="ival" id="ms-mines">💣 0</span></div>'+
    '<div class="ibox"><span class="ilabel">Time</span><span class="ival" id="ms-time">0s</span></div>'+
    '<div class="ibox"><span class="ilabel">Status</span><span class="ival" id="ms-status">Ready</span></div>'+
    '</div>'+
    '<div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap;">'+
    '<button class="btn btn-sm" onclick="msNew(&apos;easy&apos;)" style="background:rgba(16,185,129,.15);border-color:#10b981;color:#10b981;">Easy 9×9</button>'+
    '<button class="btn btn-sm" onclick="msNew(&apos;medium&apos;)" style="background:rgba(245,158,11,.12);border-color:#f59e0b;color:#f59e0b;">Medium 12×12</button>'+
    '<button class="btn btn-sm" onclick="msNew(&apos;hard&apos;)" style="background:rgba(239,68,68,.12);border-color:#ef4444;color:#ef4444;">Hard 16×16</button>'+
    '</div>'+
    '<canvas id="ms-cv" style="border:1px solid rgba(168,85,247,.2);border-radius:8px;cursor:pointer;max-width:100%;"></canvas>'+
    '<div style="font-size:11px;color:#64748b;margin-top:6px;">Left click: reveal · Right click: flag 🚩</div>';
  msNew('easy');
}
var MS={};
function msNew(diff){
  var configs={easy:{r:9,c:9,mines:10,cs:34},medium:{r:12,c:12,mines:25,cs:28},hard:{r:16,c:16,mines:51,cs:22}};
  var cfg=configs[diff];
  MS={r:cfg.r,c:cfg.c,mines:cfg.mines,cs:cfg.cs,board:[],revealed:[],flagged:[],started:false,over:false,won:false,timer:0,timerInt:null,firstClick:true};
  for(var i=0;i<MS.r;i++){MS.board.push(new Array(MS.c).fill(0));MS.revealed.push(new Array(MS.c).fill(false));MS.flagged.push(new Array(MS.c).fill(false));}
  var cv=document.getElementById('ms-cv');if(!cv)return;
  cv.width=MS.c*MS.cs;cv.height=MS.r*MS.cs;
  document.getElementById('ms-mines').textContent='💣 '+MS.mines;
  document.getElementById('ms-status').textContent='Ready';
  document.getElementById('ms-time').textContent='0s';
  cv.oncontextmenu=function(e){e.preventDefault();msFlag(e);};
  cv.onclick=msReveal;
  reg(function(){clearInterval(MS.timerInt);cv.onclick=null;cv.oncontextmenu=null;});
  msDraw();
}
function msPlace(avoidR,avoidC){
  var placed=0;
  while(placed<MS.mines){
    var r=Math.floor(Math.random()*MS.r),c=Math.floor(Math.random()*MS.c);
    if(Math.abs(r-avoidR)<=1&&Math.abs(c-avoidC)<=1)continue;
    if(MS.board[r][c]===-1)continue;
    MS.board[r][c]=-1;placed++;
  }
  for(var r=0;r<MS.r;r++)for(var c=0;c<MS.c;c++){
    if(MS.board[r][c]===-1)continue;
    var cnt=0;
    for(var dr=-1;dr<=1;dr++)for(var dc=-1;dc<=1;dc++){var nr=r+dr,nc=c+dc;if(nr>=0&&nr<MS.r&&nc>=0&&nc<MS.c&&MS.board[nr][nc]===-1)cnt++;}
    MS.board[r][c]=cnt;
  }
}
function msPos(e){
  var cv=document.getElementById('ms-cv');var rect=cv.getBoundingClientRect();
  var scaleX=cv.width/rect.width,scaleY=cv.height/rect.height;
  return{c:Math.floor((e.clientX-rect.left)*scaleX/MS.cs),r:Math.floor((e.clientY-rect.top)*scaleY/MS.cs)};
}
function msReveal(e){
  if(MS.over||MS.won)return;
  var p=msPos(e);var r=p.r,c=p.c;
  if(r<0||r>=MS.r||c<0||c>=MS.c||MS.revealed[r][c]||MS.flagged[r][c])return;
  if(MS.firstClick){MS.firstClick=false;msPlace(r,c);MS.timerInt=setInterval(function(){MS.timer++;var el=document.getElementById('ms-time');if(el)el.textContent=MS.timer+'s';},1000);}
  msFlood(r,c);
  if(MS.board[r][c]===-1){MS.over=true;clearInterval(MS.timerInt);document.getElementById('ms-status').textContent='💥 Boom!';for(var i=0;i<MS.r;i++)for(var j=0;j<MS.c;j++)if(MS.board[i][j]===-1)MS.revealed[i][j]=true;}
  else msCheckWin();
  msDraw();
}
function msFlood(r,c){
  if(r<0||r>=MS.r||c<0||c>=MS.c||MS.revealed[r][c]||MS.flagged[r][c])return;
  MS.revealed[r][c]=true;
  if(MS.board[r][c]===0)for(var dr=-1;dr<=1;dr++)for(var dc=-1;dc<=1;dc++)if(dr||dc)msFlood(r+dr,c+dc);
}
function msFlag(e){
  if(MS.over||MS.won||MS.firstClick)return;
  var p=msPos(e);var r=p.r,c=p.c;
  if(r<0||r>=MS.r||c<0||c>=MS.c||MS.revealed[r][c])return;
  MS.flagged[r][c]=!MS.flagged[r][c];
  var flags=MS.flagged.flat().filter(Boolean).length;
  var el=document.getElementById('ms-mines');if(el)el.textContent='💣 '+(MS.mines-flags);
  msDraw();
}
function msCheckWin(){
  var safe=0,rev=0;
  for(var r=0;r<MS.r;r++)for(var c=0;c<MS.c;c++){if(MS.board[r][c]!==-1)safe++;if(MS.revealed[r][c]&&MS.board[r][c]!==-1)rev++;}
  if(rev===safe){MS.won=true;clearInterval(MS.timerInt);document.getElementById('ms-status').textContent='🎉 You Win!';}
}
function msDraw(){
  var cv=document.getElementById('ms-cv');if(!cv)return;
  var ctx=cv.getContext('2d'),cs=MS.cs;
  var numColors=['','#3b82f6','#10b981','#ef4444','#7c3aed','#b45309','#0891b2','#374151','#6b7280'];
  for(var r=0;r<MS.r;r++)for(var c=0;c<MS.c;c++){
    var x=c*cs,y=r*cs;
    if(MS.revealed[r][c]){
      ctx.fillStyle=(r+c)%2===0?'#1e293b':'#0f172a';ctx.fillRect(x,y,cs,cs);
      ctx.strokeStyle='rgba(255,255,255,.04)';ctx.lineWidth=1;ctx.strokeRect(x,y,cs,cs);
      var v=MS.board[r][c];
      if(v===-1){
        // Mine
        ctx.font=(cs*.55)+'px serif';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillStyle='#ef4444';ctx.fillText('💣',x+cs/2,y+cs/2+1);
        if(MS.over){ctx.fillStyle='rgba(239,68,68,.2)';ctx.fillRect(x,y,cs,cs);}
      } else if(v>0){
        ctx.font='bold '+(cs*.55)+'px monospace';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillStyle=numColors[v]||'#94a3b8';ctx.fillText(v,x+cs/2,y+cs/2+1);
      }
    } else {
      // Unrevealed
      var base=(r+c)%2===0?'#334155':'#1e293b';
      ctx.fillStyle=base;ctx.fillRect(x,y,cs,cs);
      // 3D bevel
      ctx.fillStyle='rgba(255,255,255,.12)';ctx.fillRect(x,y,cs,2);ctx.fillRect(x,y,2,cs);
      ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(x,y+cs-2,cs,2);ctx.fillRect(x+cs-2,y,2,cs);
      if(MS.flagged[r][c]){
        ctx.font=(cs*.6)+'px serif';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillText('🚩',x+cs/2,y+cs/2+1);
      }
    }
  }
  // Win/Loss overlay
  if(MS.won){
    ctx.fillStyle='rgba(16,185,129,.15)';ctx.fillRect(0,0,cv.width,cv.height);
    ctx.fillStyle='#10b981';ctx.font='bold '+(cs*1.1)+'px monospace';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText('🎉',cv.width/2,cv.height/2);
  }
}


// ═══════════ CHESS ═══════════
function buildChess(){
  var gc=document.getElementById('game-content');
  gc.innerHTML=
    '<div class="g-info">'+
    '<div class="ibox"><span class="ilabel">Turn</span><span class="ival" id="ch-turn">White</span></div>'+
    '<div class="ibox"><span class="ilabel">Status</span><span class="ival" id="ch-status">Playing</span></div>'+
    '</div>'+
    '<canvas id="ch-cv" width="320" height="320" style="border:2px solid rgba(168,85,247,.3);border-radius:8px;cursor:pointer;"></canvas>'+
    '<div style="margin-top:10px;display:flex;gap:10px;align-items:center;">'+
    '<button class="btn btn-ghost btn-sm" onclick="chInit()">🔄 New Game</button>'+
    '<span style="font-size:11px;color:#64748b;">You are White · AI plays Black</span>'+
    '</div>';
  chInit();
}
var CH={board:null,selected:null,turn:'w',gameOver:false};
var CH_PIECES={'wK':'♔','wQ':'♕','wR':'♖','wB':'♗','wN':'♘','wP':'♙','bK':'♚','bQ':'♛','bR':'♜','bB':'♝','bN':'♞','bP':'♟'};
function chInit(){
  CH.turn='w';CH.selected=null;CH.gameOver=false;
  CH.board=[
    ['bR','bN','bB','bQ','bK','bB','bN','bR'],
    ['bP','bP','bP','bP','bP','bP','bP','bP'],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    ['wP','wP','wP','wP','wP','wP','wP','wP'],
    ['wR','wN','wB','wQ','wK','wB','wN','wR'],
  ];
  var cv=document.getElementById('ch-cv');if(!cv)return;
  cv.onclick=chClick;
  reg(function(){if(cv)cv.onclick=null;});
  chDraw();
}
function chDraw(highlights){
  var cv=document.getElementById('ch-cv');if(!cv)return;
  var ctx=cv.getContext('2d'),S=40;
  for(var r=0;r<8;r++)for(var c=0;c<8;c++){
    var light=(r+c)%2===0;
    var isSelected=CH.selected&&CH.selected[0]===r&&CH.selected[1]===c;
    var isHl=highlights&&highlights.some(function(h){return h[0]===r&&h[1]===c;});
    ctx.fillStyle=isSelected?'#a16207':isHl?'rgba(16,185,129,.5)':light?'#f0d9b5':'#b58863';
    ctx.fillRect(c*S,r*S,S,S);
    var p=CH.board[r][c];
    if(p){ctx.font='bold 26px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=p[0]==='w'?'#fff':'#1a1a1a';ctx.strokeStyle=p[0]==='w'?'#000':'#fff';ctx.lineWidth=0.5;ctx.strokeText(CH_PIECES[p],c*S+S/2,r*S+S/2+1);ctx.fillText(CH_PIECES[p],c*S+S/2,r*S+S/2+1);}
  }
  // Coords
  ctx.fillStyle='rgba(0,0,0,.4)';ctx.font='9px monospace';ctx.textAlign='left';ctx.textBaseline='top';
  var files='abcdefgh';
  for(var c=0;c<8;c++)ctx.fillText(files[c],c*S+2,7*S+30);
  for(var r=0;r<8;r++)ctx.fillText(8-r,2,r*S+2);
}
function chMoves(board,r,c){
  var p=board[r][c];if(!p)return[];
  var col=p[0],type=p[1],moves=[];
  function add(nr,nc){if(nr>=0&&nr<8&&nc>=0&&nc<8){var t=board[nr][nc];if(!t||t[0]!==col)moves.push([nr,nc]);}return nr>=0&&nr<8&&nc>=0&&nc<8&&!board[nr][nc];}
  function slide(dr,dc){for(var i=1;i<8;i++){var nr=r+dr*i,nc=c+dc*i;if(nr<0||nr>=8||nc<0||nc>=8)break;var t=board[nr][nc];if(t){if(t[0]!==col)moves.push([nr,nc]);break;}moves.push([nr,nc]);}}
  if(type==='P'){var dir=col==='w'?-1:1,start=col==='w'?6:1;if(!board[r+dir]?.[c])moves.push([r+dir,c]);if(r===start&&!board[r+dir][c]&&!board[r+dir*2][c])moves.push([r+dir*2,c]);[[r+dir,c-1],[r+dir,c+1]].forEach(function(m){if(m[0]>=0&&m[0]<8&&m[1]>=0&&m[1]<8&&board[m[0]][m[1]]&&board[m[0]][m[1]][0]!==col)moves.push(m);});}
  if(type==='N')[[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]].forEach(function(d){add(r+d[0],c+d[1]);});
  if(type==='B'||type==='Q')[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(function(d){slide(d[0],d[1]);});
  if(type==='R'||type==='Q')[[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){slide(d[0],d[1]);});
  if(type==='K')[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]].forEach(function(d){add(r+d[0],c+d[1]);});
  return moves;
}
function chClick(e){
  if(CH.gameOver||CH.turn!=='w')return;
  var cv=document.getElementById('ch-cv');var rect=cv.getBoundingClientRect(),S=40;
  var c=Math.floor((e.clientX-rect.left)*(320/rect.width)/S),r=Math.floor((e.clientY-rect.top)*(320/rect.height)/S);
  if(r<0||r>=8||c<0||c>=8)return;
  if(CH.selected){
    var moves=chMoves(CH.board,CH.selected[0],CH.selected[1]);
    var valid=moves.some(function(m){return m[0]===r&&m[1]===c;});
    if(valid){
      chApplyMove(CH.board,CH.selected[0],CH.selected[1],r,c);
      CH.selected=null;CH.turn='b';
      document.getElementById('ch-turn').textContent='Black (AI)';
      chDraw();
      if(!chKingAlive(CH.board,'w')){CH.gameOver=true;document.getElementById('ch-status').textContent='Black wins!';return;}
      setTimeout(chAIMove,400);
    } else {
      CH.selected=(CH.board[r][c]&&CH.board[r][c][0]==='w')?[r,c]:null;
      chDraw(CH.selected?chMoves(CH.board,CH.selected[0],CH.selected[1]):[]);
    }
  } else {
    if(CH.board[r][c]&&CH.board[r][c][0]==='w'){CH.selected=[r,c];chDraw(chMoves(CH.board,r,c));}
  }
}
function chApplyMove(board,fr,fc,tr,tc){
  var p=board[fr][fc];
  board[tr][tc]=p;board[fr][fc]=null;
  // Pawn promotion
  if(p==='wP'&&tr===0)board[tr][tc]='wQ';
  if(p==='bP'&&tr===7)board[tr][tc]='bQ';
}
function chKingAlive(board,col){return board.some(function(row){return row.some(function(c){return c===col+'K';});});}
function chAIMove(){
  if(CH.gameOver)return;
  // Simple AI: pick best scoring move
  var best=null,bestScore=-Infinity;
  var vals={P:1,N:3,B:3,R:5,Q:9,K:100};
  for(var r=0;r<8;r++)for(var c=0;c<8;c++){
    if(!CH.board[r][c]||CH.board[r][c][0]!=='b')continue;
    chMoves(CH.board,r,c).forEach(function(m){
      var target=CH.board[m[0]][m[1]];
      var captureVal=target?vals[target[1]]:0;
      // Add some positional heuristic for center control
      var centerBonus=(3.5-Math.abs(m[1]-3.5))+(3.5-Math.abs(m[0]-3.5));
      var s=captureVal*10+centerBonus+Math.random()*2;
      if(s>bestScore){bestScore=s;best={fr:r,fc:c,tr:m[0],tc:m[1]};}
    });
  }
  if(best){
    chApplyMove(CH.board,best.fr,best.fc,best.tr,best.tc);
    CH.turn='w';document.getElementById('ch-turn').textContent='White (You)';
    if(!chKingAlive(CH.board,'w')){CH.gameOver=true;document.getElementById('ch-status').textContent='Black wins!';}
    else if(!chKingAlive(CH.board,'b')){CH.gameOver=true;document.getElementById('ch-status').textContent='White wins!';}
  }
  chDraw();
}

/* ── Confetti celebration ── */
function celebrate(count) {
  count = count || 60;
  var colors = ['#10b981','#f59e0b','#f472b6','#60a5fa','#a855f7','#34d399','#fb923c'];
  for (var i = 0; i < count; i++) {
    (function(delay) {
      setTimeout(function() {
        var el = document.createElement('div');
        el.className = 'confetti-piece';
        el.style.cssText = [
          'left:' + (10 + Math.random()*80) + 'vw',
          'top:-10px',
          'background:' + colors[Math.floor(Math.random()*colors.length)],
          'border-radius:' + (Math.random()>.5?'50%':'2px'),
          'animation-duration:' + (1.2+Math.random()*1.6) + 's',
          'animation-delay:0s',
          'width:' + (6+Math.random()*6) + 'px',
          'height:' + (6+Math.random()*6) + 'px'
        ].join(';');
        document.body.appendChild(el);
        setTimeout(function(){ el.remove(); }, 3000);
      }, delay);
    })(i * 28);
  }
}

/* Patch game win hooks */
var _origBackToHub = backToHub;
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
